﻿var CIController = angular.module('CIController', ['ngMaterial', 'ngAnimate', 'ngAria', 'ngMessages', 'Alertify'])

.controller('childController', ['$scope', '$location', '$q', '$timeout', '$log', 'CIFactory', 'ClientConfig', 'Alertify', function ($scope, $location, $q, $timeout, $log, CIFactory, ClientConfig, Alertify) {
        
        
        
        $scope.$on('loggeduser', function (evnt, data) {
         $scope.loggeduser = data;
                 }); 
        

    }])

.controller('mainController', ['$scope', '$location', 'CIFactory', 'ClientConfig', 'ngDialog', '$filter', 'Alertify', function ($scope, $location, CIFactory, ClientConfig, ngDialog, $filter, Alertify) {
        //For ng-show 
        $scope.$on('loggeduser', function (evnt, data) {
            $scope.loggeduser = data;
        });
        
        $scope.$on(ClientConfig.GETINITIALINFO, function (event, obj) {
            $scope.GetInitialInfo();
        });
        
      
        $scope.homepage = true;
        
        $scope.$on(ClientConfig.ENVMAPPING, function (evnt, data) {
            
            $scope.envmapping(data);
        });

     
        $scope.ResetToolsData = function () {
        
        
            $scope.$broadcast('ResetToolsData');
        }

        $scope.envmapping = function (containerstack) {
            
            $location.path(ClientConfig.ENVPROVVMMAPPING);
            $scope.BuildModel.DisableControl = ClientConfig.BOOL_FALSE;
           
            //var selectedcontainerstack = containerstack;
            CIFactory.GetContainerStackData(containerstack, ClientConfig.BOOL_FALSE).then(function (result) {
                if (result == ClientConfig.EMPTY) {
                    Alertify.alert('error');
                } else {
                    $scope.containerStackName = containerstack;
                    
                    $scope.containerSourceControl = result.ContainerStackData[0].SourceControl;
                    $scope.containerBuildServer = result.ContainerStackData[0].BuildServer;
                    $scope.containerCompilerTool = result.ContainerStackData[0].CompilerTool;
                    $scope.containerCodeReviewTool = result.ContainerStackData[0].CodeReviewTool;
                    $scope.containerCodeArtifactory = result.ContainerStackData[0].CodeArtifactory;
                    $scope.containerstack = containerstack;
                    $scope.containerQualityTool = result.ContainerStackData[0].QualityTool;
                }
            });
           
        }
        
        
        $scope.EnvProvNavigation = function () {
            //var user = $scope.user;
            CIFactory.loginDetails($scope.loggeduser).then(function (result) {
                var userrole = result.role;
                
                if (userrole == 'Build&Release_Engineer') {
                    $scope.DashboardView();
                }
                else if (userrole == 'SysAdmin') {
                    $('#divServicesSelection').hide();
                    $('#trLevel2HomeHeader').hide();
                    $location.path(ClientConfig.ENVPROVTOOLSSTACK);
                    $scope.BuildModel.DisableControl = ClientConfig.BOOL_FALSE;
                }
            });
        }
        $scope.EnvProvToolsDetails = [];
        
        $scope.GetContainerStackData = function (SelectedItem) {
            
            $location.path(ClientConfig.ENVPROVTOOLSSTACK);
            
            var selectedcontainerstack = SelectedItem.EnvProvConfigApplication.ContainerStackName;
            
            
            CIFactory.GetContainerStackData(selectedcontainerstack, ClientConfig.BOOL_FALSE).then(function (result) {
                if (result == ClientConfig.EMPTY) {
                    Alertify.alert('error');
                } else {
                    
                    $scope.containerSourceControl = result.ContainerStackData[0].SourceControl;
                    $scope.containerBuildServer = result.ContainerStackData[0].BuildServer;
                    $scope.containerCompilerTool = result.ContainerStackData[0].CompilerTool;
                    $scope.containerCodeReviewTool = result.ContainerStackData[0].CodeReviewTool;
                    $scope.containerstack = selectedcontainerstack;
                    $scope.containerCodeArtifactory = result.ContainerStackData[0].CodeArtifactory;
                    $scope.containerQualityTool = result.ContainerStackData[0].QualityTool;
                    $scope.EnvProvToolsDetails.ContainerStackName = selectedcontainerstack;
                    $scope.$broadcast(ClientConfig.VIEWENVPROVTOOLS, selectedcontainerstack, result.ContainerStackData[0]);
                }
            });
         
        }
        
        //Getall tools need to be spplitted based on the CI-CD/Envprovisoning process
        $scope.GetInitialInfo = function () {
            $scope.buildTool = ClientConfig.BUILDSERVERTOOL;
            $scope.tool = ClientConfig.BUILDSERVERTOOL;
            CIFactory.GetAllTools().then(function (result) {
                
                $scope.BuildDefinitionNames = result.buildDefinitionDetails;
                $scope.DeployConfigDetails = result.deployConfigDetails;
                //$scope.GetCICDJobType();
                // }
                $scope.BuildTFSDetails = result.buildTFSDetails;
                $scope.BuildJenkinsDetails = result.buildJenkinsDetails;
                $scope.BuildServerTools = result.buildServerTools;
                $scope.DeployServerTools = result.deployServerTools;
                $scope.SourceControlTools = result.sourceControlTools;
                $scope.BinaryRepositoryTools = result.binaryRepositoryTools;
                $scope.UITierAppTypes = result.uiTierAppTypes;
                $scope.BusinessTierAppTypes = result.businessTierAppTypes;
                $scope.DataTierAppTypes = result.dataTierAppTypes;
                $scope.CoverageInputs = result.CodeCoverageInputs;
                $scope.MetricInputs = result.MetricInputs;
                $scope.BuildConfigiurations = result.BuildConfigurations
                $scope.BuildPlatforms = result.BuildPlatforms;
                $scope.ReportTypesList = result.RepotTypes
                
                $scope.UnitTestToolsJava = result.JavaUnitTestTools;
                $scope.UnitTestToolsDotNet = result.DotNetUnitTestTools;
                $scope.CoverageToolsJava = result.JavaCoverageTools;
                $scope.CoverageToolsDotNet = result.DotNetCoverageTools;
                $scope.CodeAnalysisToolsJava = result.JavaAnalysisTools;
                $scope.CodeAnalysisToolsDotNet = result.DotNetAnalysisTools;
                $scope.SecAnalysisToolsJava = result.JavaSecAnalysisTools;
                $scope.SecAnalysisToolsDotNet = result.DotNetSecAnalysisTools;
                
                $scope.CodeMetricsToolsJava = result.JavaCodeMetricsTools;
                $scope.CodeMetricsToolsDotNet = result.DotNetCodeMetricsTools;
                
                
                $scope.CIApplicationDeploy = result.CIApplicationDeploy;
                $scope.CDPipelineTrigger = result.CDPipelineTrigger;
                $scope.RespositoryTool = result.RespositoryTool;
                $scope.ConfigurationTool = result.ConfigurationTool;
                $scope.OperatingSystem = result.OperatingSystem;
                $scope.Platform = result.Platform;
                $scope.Artifactdeployed = result.Artifactdeployed;
                
                $scope.ActivitiesInfo = result.ActivitiesInfo;
                $scope.ResultsInfo = result.ResultsInfo;
                $scope.ReportsInfo = result.ReportsInfo;
                
                $scope.BuildDefinitionTemplates = result.BuildDefinitionTemplates;
                
                $scope.UpdateApplicationPanel();
                
                $scope.GetBuildConfigServer();
                
                $scope.GetDeployConfigServer();
                
                $scope.UpdateCDConfigServer();
                
                $scope.UpdateEnvProvConfigApplication();
                
                //$scope.GetEnvProvConfigApplication();
                //Environment provisioning tools
                
                $scope.EPAllSourceControls = result.EPAllSourceControls[0].SourceControl;
                $scope.EPAllBuildServers = result.EPAllBuildServers[0].BuildServer;
                $scope.EPAllCodeArtifactorys = result.EPAllCodeArtifactorys[0].CodeArtifactory;
                $scope.EPAllQualityTools = result.EPAllQualityTools[0].QualityTool;
                $scope.EPAllCodeReviewTools = result.EPAllCodeReviewTools[0].CodeReviewTool;
                $scope.EPAllCompilerTools = result.EPAllCompilerTools[0].CompilerTool;
                
                $scope.EPSourceControls = result.EPSourceControls[0].SourceControl;
                $scope.EPBuildServers = result.EPBuildServers[0].BuildServer;
                $scope.EPCodeArtifactorys = result.EPCodeArtifactorys[0].CodeArtifactory;
                $scope.EPQualityTools = result.EPQualityTools[0].QualityTool;
                $scope.EPCodeReviewTools = result.EPCodeReviewTools[0].CodeReviewTool;
                $scope.EPCompilerTools = result.EPCompilerTools[0].CompilerTool;
                $scope.EPToolsInfo = result.EPToolsInfo[0];
                
               

            }, function (error) {
                console.log(error);
            });
        }
        
        $scope.logout = function () {
            $('#leftMenu').hide();
            $('#EnvProvleftMenu').hide();
            CIFactory.logout().then(function (result) {
                $scope.$broadcast(ClientConfig.CALL_TIMER, {
                    buildTimerFlag: ClientConfig.BOOL_FALSE,
                    buildTimeInterval: 0
                });
                $location.path(ClientConfig.LOGIN_PATH);
            }, function (error) {
                console.log(error);
            });
        }
        debugger;
        //for approval status
       
        
        $scope.$on(ClientConfig.UPDATEAPPLICATIONS, function (event, obj) {
            $scope.UpdateApplicationPanel();

        });
        
        $scope.UpdateApplicationPanel = function () {
            var selectedBuildServerTool = ClientConfig.BUILDSERVERTOOL;
            $scope.CDApplicationsMapping = [];
            CIFactory.GetApplications().then(function (result) {
                
                $scope.Applications = result.ApplicationNames;
                $scope.ApplicationsMapping = result.ApplicationType;
                $scope.ApplicationsCount = $scope.Applications.length;
                $scope.BuildDefnName = result.BuildDefnNames;
                
                $scope.ApplicationsType = result.ApplicationType;
                for (i = 0; i < $scope.ApplicationsCount; i++) {
                    if ($scope.ApplicationsType[i].UITierAppType == 'Java') {
                        if ($scope.CDApplicationsMapping.indexOf($scope.Applications[i]) == -1) {
                            $scope.CDApplicationsMapping.push($scope.Applications[i]);
                        }
                    }
                }

            }, function (error) {                            
            });


        }
        
        $scope.$on(ClientConfig.UPDATEBUILDCONFIGSERVER, function (event, obj) {
            $scope.UpdateBuildConfigServer();

        });
        
        $scope.UpdateBuildConfigServer = function () {
            //var selectedBuildServerTool = ClientConfig.BUILDSERVERTOOL;
            
            CIFactory.GetBuildServers().then(function (result) {
                
                
                $scope.BuildConfigServers = result.BuildServerConfigNames;
                $scope.BuildConfigServersCount = $scope.BuildConfigServers.length;
                $scope.SourceTools = result.SourceControlTools;
                
                if ($scope.BuildConfigServersCount == 0) {
                    $scope.loadDashboard();
                }
                //$scope.BuildServersCount = $scope.BuildServers.length;
                console.log(result);
            // $scope.BuildDefnName = result.BuildDefnNames;

            }, function (error) {
            });


        }
        
        
        $scope.GetBuildConfigServer = function () {
            
            CIFactory.GetBuildServers().then(function (result) {
                $scope.BuildConfigServers = result.BuildServerConfigNames;
                $scope.SourceTools = result.SourceControlTools;
                $scope.BuildConfigServersCount = $scope.BuildConfigServers.length;
               
            }, function (error) {     
            });

        }
        
        $scope.$on(ClientConfig.UPDATEENVPROVCONFIGAPPLICATION, function (event, obj) {
            $scope.UpdateEnvProvConfigApplication();

        });
        
        $scope.UpdateEnvProvConfigApplication = function () {
            
            CIFactory.GetEnvProvApplications().then(function (result) {
                
                $scope.EnvProvConfigApplications = result.EnvProvConfigNames;
                $scope.EnvProvConfigApplicationsCount = $scope.EnvProvConfigApplications.length;
                
            // $scope.BuildDefnName = result.BuildDefnNames;

            }, function (error) {     
            });


        }
        
        
        //$scope.GetEnvProvConfigApplication = function () {
        
        //    CIFactory.GetEnvProvApplications().then(function (result) {
        
        //        $scope.EnvProvConfigApplications = result.EnvProvConfigNames;
        //        $scope.EnvProvConfigApplicationsCount = $scope.EnvProvConfigApplications.length;
        
        //    }, function (error) {     
        //    });
        
        //}
        
        
        $scope.$on(ClientConfig.UPDATEDEPLOYCONFIGSERVER, function (event, obj) {
            $scope.UpdateDeployConfigServer();
              
        });
        
        
        $scope.UpdateDeployConfigServer = function () {
            //var selectedBuildServerTool = ClientConfig.BUILDSERVERTOOL;
            
            CIFactory.GetDeployServers().then(function (result) {
                
                
                $scope.DeployConfigServers = result.DeployServerConfigNames;
                $scope.DeployServersCount = $scope.DeployConfigServers.length;
                
                if ($scope.DeployServersCount == 0) {
                    $scope.loadDashboard();
                }
                console.log(result);
               
            }, function (error) {
            });


        }
        
        
        
        
        
        
        $scope.GetDeployConfigServer = function () {
            
            CIFactory.GetDeployServers().then(function (result) {
                $scope.DeployConfigServers = result.DeployServerConfigNames;
                $scope.DeployServersCount = $scope.DeployConfigServers.length;
            }, function (error) {              
            });
        }
        
        $scope.$on(ClientConfig.UPDATECDCONFIGSERVER, function (event, obj) {
            $scope.UpdateCDConfigServer();
           
        });
        
        $scope.UpdateCDConfigServer = function () {
            CIFactory.GetCDConfigNames().then(function (result) {
                $scope.CDConfigurations = result.CDConfigNames;
                $scope.CDServersCount = $scope.CDConfigurations.length;
            }, function (error) {       
            });
        }
        
        
        
        $scope.init = function () {
            $location.path(ClientConfig.EMPTY);
            $scope.SourceTools = ClientConfig.EMPTY;
            var selectedBuildServerTool = ClientConfig.BUILDSERVERTOOL;
            $scope.tool = selectedBuildServerTool;
            $scope.NoOfApplications = ClientConfig.NO_OF_APPLICATIONS;
            
            $scope.CDApplicationsMapping = [];
            $scope.loadLogin();
            
            //CIFactory.loginDetails().then(function (result) {
              

               
                
               
            //    }, function (error) {
            //    Alertify.alert('error');
            //    });
                    
        };
        
      
        $scope.loadLogin = function () {
            $('#trCIServices').show();
            $('#leftMenu').hide();
            
            $('#trHome').hide();
            $('#lblFindService').text("CI");
            $('.menu_2level_index_header').hide();
            $('#divServicesSelection').hide();
            $('#search_strip').hide();
            $scope.PreviousSelected = ClientConfig.EMPTY;
            $scope.showApplicationpage = false;
            $("#ApplicationConfiguration").hide();
            $location.path(ClientConfig.LOGIN_PATH);
        };
        //Confirm message validation for dashboard   
      
        
        $scope.AddEnvProvision = function () {
            $location.path(ClientConfig.ENVPROVTOOLSSTACK);
        }
    }])

.controller('loginController', ['$scope', '$location', 'CIFactory', 'ClientConfig', 'ngDialog', '$filter', 'Alertify', function ($scope, $location, CIFactory, ClientConfig, ngDialog, $filter, Alertify) {
        
        $scope.initLogin = function () {
            $scope.$emit('loggeduser', null);
            $scope.errormessage = "";
        }
        
        
        $scope.doCheck = function () {
            var user = $scope.user;
            CIFactory.loginDetails(user).then(function (result) {
                
                if (typeof (result.username) != ClientConfig.UNDEFINED) {
                    
                    
                    $scope.$emit(ClientConfig.GETINITIALINFO, {});
                    
                    $scope.$emit('loggeduser', $scope.user);
                    
                    var userrole = result.role;
                    
                    // if (userrole == 'Devops') {
                    $location.path(ClientConfig.SLASH);
                    $('#loginid').hide();
                    $('#divServicesSelection').show();
                    $('#trLevel2HomeHeader').show();
                    //}
                    //else if (userrole == 'SysAdmin') {
                    //    $location.path(ClientConfig.ENVPROVTOOLSSTACK);
                    //}
                    
                   
                  //  }
                } else {
                    
                    $scope.errormessage = result.message + "!! Please fill in correct details"
                }

            }, function (error) {
                console.log(error);
            });
        
                   
                   
        }

    }])
    
.controller('EnvProvisionController', ['$scope', '$location', 'CIFactory', 'ClientConfig', 'ngDialog', '$filter', 'Alertify', function ($scope, $location, CIFactory, ClientConfig, ngDialog, $filter, Alertify) {
        
        var selectedContainer = null, containerId = null, currentSection = null, selectedToolType = null, toolInfo = [], countSonar = 1, countGIT = 1, EPvalidcount = 1;
        var countNexus = 1, countJenkins = 1, countFindBug = 1, countANT = 1, choosenListofCont = [], currentIcon = null;
        $scope.sourceControl = [];
        $scope.buildServer = [];
        $scope.compilerTool = [];
        $scope.codeArtifactory = [];
        $scope.qualityTool = [];
        $scope.codeReviewTool = [];
        $scope.toolsIconSelected = ClientConfig.BOOL_FALSE;
        $scope.BuildModel.DisableControls = ClientConfig.BOOL_TRUE;
        $scope.selectedtools = [];
        $scope.showproperties = ClientConfig.BOOL_FALSE;
        $scope.TabCount = 1;
       // $scope.Version = [];
        var counttab = 2;
        $scope.Viewdata = [];
        /*Function for individual tool View  for Environmental Provisioning screen
         * @param  {string}  Tooltype
         * @param  {string}  container
         */
        $scope.IndividualToolView = function (ToolType, Tool) {
            debugger;
            if ($scope.BuildModel.DisableControl) {
                debugger;
                switch (Tool) {
                    case $scope.Viewdata.BuildServer[0].Type:
                        $scope.EnvProvToolsDetails.Tool.Name = $scope.Viewdata.BuildServer[0].Name;
                        $scope.EnvProvToolsDetails.Tool.Password = $scope.Viewdata.BuildServer[0].Password;
                        $scope.EnvProvToolsDetails.Tool.UserName = $scope.Viewdata.BuildServer[0].UserName;
                       // debugger;
                        $scope.EnvProvToolsDetails.Tool.Version = $scope.Viewdata.BuildServer[0].Version;
                        
                                
                         
                        
                        $scope.EnvProvToolsDetails.Tool.PortNumber = $scope.Viewdata.BuildServer[0].PortNumber;
                        break;
                        debugger;
                    case $scope.Viewdata.SourceControl[0].Type:
                        $scope.EnvProvToolsDetails.Tool.Name = $scope.Viewdata.SourceControl[0].Name;
                        $scope.EnvProvToolsDetails.Tool.Password = $scope.Viewdata.SourceControl[0].Password;
                        $scope.EnvProvToolsDetails.Tool.UserName = $scope.Viewdata.SourceControl[0].UserName;
                        $scope.EnvProvToolsDetails.Tool.Version = $scope.Viewdata.SourceControl[0].Version;
                        $scope.EnvProvToolsDetails.Tool.PortNumber = $scope.Viewdata.SourceControl[0].PortNumber;
                        break;
                        debugger;
                    case $scope.Viewdata.CompilerTool[0].Type:
                        $scope.EnvProvToolsDetails.Tool.Name = $scope.Viewdata.CompilerTool[0].Name;
                        $scope.EnvProvToolsDetails.Tool.Password = $scope.Viewdata.CompilerTool[0].Password;
                        $scope.EnvProvToolsDetails.Tool.UserName = $scope.Viewdata.CompilerTool[0].UserName;
                        $scope.EnvProvToolsDetails.Tool.Version = $scope.Viewdata.CompilerTool[0].Version;
                        $scope.EnvProvToolsDetails.Tool.PortNumber = $scope.Viewdata.CompilerTool[0].PortNumber;
                        break;
                    case $scope.Viewdata.QualityTool[0].Type:
                        $scope.EnvProvToolsDetails.Tool.Name = $scope.Viewdata.QualityTool[0].Name;
                        $scope.EnvProvToolsDetails.Tool.Password = $scope.Viewdata.QualityTool[0].Password;
                        $scope.EnvProvToolsDetails.Tool.UserName = $scope.Viewdata.QualityTool[0].UserName;
                        $scope.EnvProvToolsDetails.Tool.Version = $scope.Viewdata.QualityTool[0].Version;
                        $scope.EnvProvToolsDetails.Tool.PortNumber = $scope.Viewdata.QualityTool[0].PortNumber;
                        break;
                    case $scope.Viewdata.CodeReviewTool[0].Type:
                        $scope.EnvProvToolsDetails.Tool.Name = $scope.Viewdata.CodeReviewTool[0].Name;
                        $scope.EnvProvToolsDetails.Tool.Password = $scope.Viewdata.CodeReviewTool[0].Password;
                        $scope.EnvProvToolsDetails.Tool.UserName = $scope.Viewdata.CodeReviewTool[0].UserName;
                        $scope.EnvProvToolsDetails.Tool.Version = $scope.Viewdata.CodeReviewTool[0].Version;
                        $scope.EnvProvToolsDetails.Tool.PortNumber = $scope.Viewdata.CodeReviewTool[0].PortNumber;
                        break;
                    case $scope.Viewdata.CodeArtifactory[0].Type:
                        $scope.EnvProvToolsDetails.Tool.Name = $scope.Viewdata.CodeArtifactory[0].Name;
                        $scope.EnvProvToolsDetails.Tool.Password = $scope.Viewdata.CodeArtifactory[0].Password;
                        $scope.EnvProvToolsDetails.Tool.UserName = $scope.Viewdata.CodeArtifactory[0].UserName;
                        $scope.EnvProvToolsDetails.Tool.Version = $scope.Viewdata.CodeArtifactory[0].Version;
                        $scope.EnvProvToolsDetails.Tool.PortNumber = $scope.Viewdata.CodeArtifactory[0].PortNumber;
                        break;


                }
               
            }
        }
        
        /*Function for View mode for Environmental Provisioning screen*/
        $scope.ViewEnvProvTools = function (Containername, Containerdetails) {
            
            $scope.BuildModel.DisableControl = ClientConfig.BOOL_TRUE;
            $scope.EnvProvToolsDetails.Tool = [];
            $('#divButton').hide();
            $scope.Viewdata = Containerdetails;
            $scope.EnvProvToolsDetails.ContainerStackName = Containername;
            $scope.containerStackName = Containername;
            
            $scope.showproperties = ClientConfig.BOOL_TRUE;
            $scope.VMMappingLink = ClientConfig.BOOL_TRUE;
            $scope.EnvProvToolsDetails.Tool.Name = Containerdetails.SourceControl[0].Name;
            $scope.EnvProvToolsDetails.Tool.Password = Containerdetails.SourceControl[0].Password;
            $scope.EnvProvToolsDetails.Tool.UserName = Containerdetails.SourceControl[0].UserName;
            $scope.EnvProvToolsDetails.Tool.Version = Containerdetails.SourceControl[0].Version;
            $scope.EnvProvToolsDetails.Tool.PortNumber = Containerdetails.SourceControl[0].PortNumber;
            //Full Json for the Containers
            $scope.envProvToolsDetails = ({
                ContainerStackName : $scope.containerStackName,
                SourceControl   : $scope.Viewdata.SourceControl,
                BuildServer     : $scope.Viewdata.BuildServer,
                CompilerTool    : $scope.Viewdata.CompilerTool,
                CodeArtifactory : $scope.Viewdata.CodeArtifactory,
                QualityTool     : $scope.Viewdata.QualityTool,
                CodeReviewTool  : $scope.Viewdata.CodeReviewTool
            });
            
            
            
            $scope.Toolgroups = [
                {
                    title: 'Source Control',
                    content: {
                        image: '../Images/' + Containerdetails.SourceControl[0].Type + 'ICON.png ' ,
                        text: Containerdetails.SourceControl[0].Type
                    }
                },
                {
                    title: 'Build Server',
                    content: {
                        image: '../Images/' + Containerdetails.BuildServer[0].Type + 'ICON.png',
                        text: Containerdetails.BuildServer[0].Type
                    }
                },
                {
                    title: 'Compiler Tool',
                    content: {
                        image: '../Images/' + Containerdetails.CompilerTool[0].Type + 'ICON.png',
                        text: Containerdetails.CompilerTool[0].Type
                    }
                },
                {
                    title: 'Quality Tool',
                    content: {
                        image: '../Images/' + Containerdetails.QualityTool[0].Type + 'ICON.png',
                        text: Containerdetails.QualityTool[0].Type
                    }
                },
                {
                    title: 'Code Review Tool',
                    content: {
                        image: '../Images/' + Containerdetails.CodeReviewTool[0].Type + 'ICON.png',
                        text: Containerdetails.CodeReviewTool[0].Type
                    }
                }, 
                {
                    title: 'Code Artifactory',
                    content: {
                        image: '../Images/' + Containerdetails.CodeArtifactory[0].Type + 'ICON.png',
                        text: Containerdetails.CodeArtifactory[0].Type
                    }
                }
            ];
            $scope.Toolgroups.map(function (Toolgroup) {
                if (Toolgroup.title == "Source Control") {
                    Toolgroup.open = true;
                }
            });
        }
        
        /*Function for Navigation of VM mapping screen*/
        $scope.Viewenvmapping = function (containerstack) {
            //alert('Viewenvmapping');
            $scope.EnvProvVMDetails = [];
            $location.path(ClientConfig.ENVPROVVMMAPPING);
            $scope.BuildModel.DisableControl = ClientConfig.BOOL_FALSE;
            var selectedcontainerstack = containerstack;
            $scope.containerStackName = containerstack;
            CIFactory.GetContainerStackData(selectedcontainerstack, ClientConfig.BOOL_FALSE).then(function (result) {
                if (result == ClientConfig.EMPTY) {
                    Alertify.alert('error');
                } else {
                    $scope.containerStackName = selectedcontainerstack;
                    
                    $scope.containerSourceControl = result.ContainerStackData[0].SourceControl;
                    $scope.containerBuildServer = result.ContainerStackData[0].BuildServer;
                    $scope.containerCompilerTool = result.ContainerStackData[0].CompilerTool;
                    $scope.containerstack = selectedcontainerstack;
                    $scope.containerCodeReviewTool = result.ContainerStackData[0].CodeReviewTool;
                    $scope.containerCodeArtifactory = result.ContainerStackData[0].CodeArtifactory;
                    $scope.containerQualityTool = result.ContainerStackData[0].QualityTool;
                   
                }
            });
           
        }
        
        
        $scope.$on(ClientConfig.VIEWENVPROVTOOLS, function (e, Containername, Containerdetails) {
            $scope.ViewEnvProvTools(Containername, Containerdetails);

        });
        
        /*Function for Adding VM tab */
        $scope.AddTab = function () {
            
            var container = '<button id="Button' + counttab + 'VM" class="tablinks" onclick="angular.element(this).scope().TabData(event)">VM ' + counttab + '</button>';
            // $(".tab").append(container);
            var tabcontainer = ' <div id="' + counttab + 'VM" class="tabcontent"><h3>VM ' + counttab + '</h3>  <table style="margin:auto;" class="imgtab"> <tbody style="margin:25px;" id="tbody1"> <tr><td ondrop="angular.element(this).scope().drop(event)" ondragover="angular.element(this).scope().allowDrop(event)"   class="tdstyle">   </td><td ondrop="angular.element(this).scope().drop(event)" ondragover="angular.element(this).scope().allowDrop(event)"   class="tdstyle">   </td><td ondrop="angular.element(this).scope().drop(event)" ondragover="angular.element(this).scope().allowDrop(event)"   class="tdstyle">   </td></tr><tr><td ondrop="angular.element(this).scope().drop(event)" ondragover="angular.element(this).scope().allowDrop(event)"   class="tdstyle">   </td><td ondrop="angular.element(this).scope().drop(event)" ondragover="angular.element(this).scope().allowDrop(event)"   class="tdstyle">   </td><td ondrop="angular.element(this).scope().drop(event)" ondragover="angular.element(this).scope().allowDrop(event)"   class="tdstyle">   </td></tr> </tbody> </table>  </div>';
            $("#tabdata").append(tabcontainer);
            $(container).insertBefore('.tablinks:last');
            counttab++;
            $scope.TabCount++;
            
        }
        
        $scope.allowDrop = function (ev) {
            ev.preventDefault();
        }
        // var parent;
        $scope.drag = function (ev) {
            ev.dataTransfer.setData("text", ev.target.id);
            parent = $("#" + ev.target.id).parent('div').attr('id');
        }
        
        $scope.drop = function (ev) {
            ev.preventDefault();
            var data = ev.dataTransfer.getData("text");
            if ($(ev.target).find('div').length == 0) {
                ev.target.appendChild(document.getElementById(data));
                var cln = document.getElementById(data).cloneNode(true);
                //cln.setAttribute('draggable', false);
                $('#' + parent).append(cln).css({ 'opacity': '0.5' });

            }
            var elements = document.getElementsByClassName("Ecard");
            for (var i = 0, len = elements.length; i < len; i++) {
                var stylew = (elements[i]).style;
                //alert(stylew.opacity);
                if (stylew.opacity != "0.5") {
                    $('#ButtonVMSave').prop('disabled', true);
                    break;
                } else {
                    $('#ButtonVMSave').prop('disabled', false);
            }
        }
        }
        
        $scope.VMDetails = [];
        $scope.VMContainerDetails = [];
        $scope.VMContainerMapping = [];
        $scope.VMNumber = 1;
        
        
        /*Function for saving VM details in mongodb*/
        
        $scope.InsertVMContainerDetails = function () {
            
            var invalid = $scope.ValidationsCheck(ClientConfig.ENVIRONMENTMAPPING);
            if (invalid == ClientConfig.BOOL_TRUE) {
                
                // $scope.FormVMDetails.shift();
                
                $scope.FormVMDetails[$scope.VMNumber - 1] = $scope.EnvProvVMDetails;
                $scope.VMDetail = [];
                var no_of_VM = $("#tabdata > div").length;
                //alert(no_of_VM);
                for (i = 0; i < no_of_VM; i++) {
                    //var VMid = "#" + (i + 1) + "VM > div";
                    var VMid = "#" + (i + 1) + "VM";
                    $scope.VMDetail = [];
                    //$(VMid).map(function () {
                    
                    //    $scope.VMDetail.push(this.id);
                    //});
                    $(VMid).find('div').each(function () {
                        var innerDivId = $(this).attr('id');
                        $scope.VMDetail.push(innerDivId)
                    });
                    $scope.VMContainerDetails = [];
                    for (j = 0; j < $scope.VMDetail.length; j++) {
                        //$scope.VMContainers
                        var containerid = "#" + $scope.VMDetail[j] + " > img";
                        $(containerid).map(function () {
                            
                            $scope.ContainerTypeDetail = this.id;
                        });
                        var containerid1 = "#" + $scope.VMDetail[j] + " > p";
                        $(containerid1).map(function () {
                            
                            $scope.ContainerNameDetail = this.id;
                        });
                        
                        var VMContainers = ({
                            Tag         : $scope.VMDetail[j].substring(0, ($scope.VMDetail[j].length - 11)),
                            Name        : $scope.ContainerTypeDetail.substring(6, $scope.ContainerTypeDetail.length),
                            Type        : $scope.ContainerNameDetail.substring(6, $scope.ContainerNameDetail.length),
                            Status      : ""
                        });
                        
                        $scope.VMContainerDetails.push(VMContainers)
                       
                    }
                    
                    var VMContainerMapping = ({
                        
                        Containers : $scope.VMContainerDetails,
                        VMName : $scope.FormVMDetails[i].VMName,
                        UserName: $scope.FormVMDetails[i].UserName,
                        Password: $scope.FormVMDetails[i].Password
    
                    });
                    $scope.VMContainerMapping.push(VMContainerMapping)
                    
                    $scope.vmHostingDetails = ({
                        ContainerStackName: $scope.containerstack,
                        VMContainerMapping: $scope.VMContainerMapping

                    });

                }
                
                //Full Json for the Containers
                $scope.envProvToolsDetails = ({
                    ContainerStackName : $scope.containerstack,
                    SourceControl   : $scope.containerSourceControl ,
                    BuildServer     : $scope.containerBuildServer,
                    CompilerTool    : $scope.containerCompilerTool,
                    CodeArtifactory : $scope.containerCodeArtifactory,
                    QualityTool     : $scope.containerQualityTool ,
                    CodeReviewTool  : $scope.containerCodeReviewTool
                });
                
                $scope.FormVMDetails = [];
                CIFactory.InsertVMContainerMappingDetails($scope.vmHostingDetails).then(function (result) {
                    if (result == ClientConfig.SUCCESS_MSG) {
                        //On success status call the function
                        Alertify.alert(ClientConfig.ADD_ENV_MAPPING_SUCCESS_MSG);
                        $scope.ResetVMDetails();
                        
                        $scope.ResetToolsData();
                        $location.path(ClientConfig.ENVPROVTOOLSSTACK);
                        CIFactory.CreateEnvProvisioning($scope.envProvToolsDetails, $scope.vmHostingDetails, $scope.EPToolsInfo).then(function (result) {
                            if (result != ClientConfig.UNDEFINED) {
                                //On success status call the function
                                //Alertify.alert(ClientConfig.CREATE_ENV_VMCONTAINERS_SUCCESS_MSG);
                               
                            }
                           

                        }, function (error) {
                            
                        });
                        
                    }

                }, function (error) {
                    Alertify.alert(ClientConfig.ADD_ENV_MAPPING_ERROR_MSG);
                });
            }
          
        }
        $scope.FormVMDetails = [];
        var prevvm = 1;
        
        /*Function for tab functionality
         * @param event
         */
        $scope.TabData = function (event) {
            
            
            var invalid = $scope.ValidationsCheck(ClientConfig.ENVIRONMENTMAPPING)
            if (invalid == ClientConfig.BOOL_TRUE) {
                
                // Declare all variables
                var i, tabcontent, tablinks;
                var VMButton = $(event.target).attr("id");
                
                var VM = VMButton.substring(6, VMButton.length);
                
                $scope.VMNumber = VM.substring(0, 1);
                
                content = document.getElementsByClassName("tab");
                tabButtons = content[0].getElementsByTagName("button");
                
                if ($scope.VMNumber <= $scope.TabCount) {
                    $scope.FormVMDetails[prevvm - 1] = $scope.EnvProvVMDetails;
                    $scope.EnvProvVMDetails = $scope.FormVMDetails[$scope.VMNumber - 1];
                    prevvm = $scope.VMNumber;
                }
                //else if ($scope.VMNumber = $scope.TabCount) {
                //    $scope.FormVMDetails[prevvm - 1] = $scope.EnvProvVMDetails;
                //    $scope.EnvProvVMDetails = $scope.FormVMDetails[$scope.VMNumber - 1];
                //    prevvm = $scope.VMNumber;
                //}
                else {
                    $scope.FormVMDetails[prevvm - 1] = $scope.EnvProvVMDetails;
                    $scope.EnvProvVMDetails = ClientConfig.EMPTY;
                    prevvm = $scope.VMNumber;
                }
                
                // Get all elements with class="tabcontent" and hide them
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                
                // Get all elements with class="tablinks" and remove the class "active"
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                
                // Show the current tab, and add an "active" class to the button that opened the tab
                document.getElementById(VM).style.display = "block";
                event.currentTarget.className += " active";
            }
        }
        
        /* Function to enable/ disable for save button in Environment Mapping */
        $scope.enableSaveButton = function (VMcontainer) {
            if ($scope.Ecard.indexOf(VMcontainer) == -1) {
                $scope.Ecard.push(VMcontainer);
                if ($scope.Ecard.length > 5) {
                    $scope.BuildModel.DisableControls = ClientConfig.BOOL_FALSE;
                }
              
            }
        }
       

        /*
        * Function to load the containers for each section
        * @param {string} container 
        * @param {bool} onload
        */
        $scope.AvailableTools = function (container, onload) {
            
            //On loadeventshouldn't call the validations
            if (($("#divEnvprovConfig").is(':visible')) && (onload == 'false')) {
                var IsValid = $scope.ValidationsCheck(ClientConfig.ENVIRONMENTCONFIGURATION);
                
            }
            
            //Diasbling on click of images load if any mandatory fields are not filled up
            //Every click event count will increase,Except the first load all the sections will be disabled if valid data is not provided
            
            var loadContent = ClientConfig.BOOL_TRUE;
            if ((onload == 'false') && $scope.toolsIconSelected) {
                loadContent = ClientConfig.BOOL_FALSE;
                $scope.showproperties = ClientConfig.BOOL_TRUE;
                if ($scope.EnvProvToolsDetails != undefined) {
                    if (($scope.EnvProvToolsDetails.Tool.Version != null && $scope.EnvProvToolsDetails.Tool.PortNumber != null && $scope.EnvProvToolsDetails.Tool.Name != null && $scope.EnvProvToolsDetails.ContainerStackName != null)) {
                        loadContent = ClientConfig.BOOL_TRUE;
                        $scope.showproperties = ClientConfig.BOOL_FALSE;
                    }
                }
                
            }
            
            
            //Check for the required field validations,if all fields are filled up ,Proceed with loading images
            if (loadContent) {
                switch (container) {
                    case 'Source Control':
                        $("#EPcornerstable").empty()
                        var length = $scope.EPAllSourceControls.length;
                        for (i = 0; i < length; i++) {
                            var container = '<td> <div class="shadow colelem" <table style="width:80%"><tr > <td id="ID_' + $scope.EPAllSourceControls[i].name + '" class="TFSStack1">  <img src="Images/' + $scope.EPAllSourceControls[i].name + 'ICON.png" style="padding-top: 18px; margin-left: 30%;" /><br /><label style=" margin-left: 35%;margin-top:5%"> ' + $scope.EPAllSourceControls[i].name + '</label></td></tr></table></div></td>';
                            $("#EPcornerstable").append(container);
                            $('#EPTitle').text('Source Control');
                            $('#ID_TFS,#ID_SVN').css({
                                'opacity': '0.25',
                                'cursor': 'default',
                            });
                        }
                        break;
                    case 'Build Server':
                        $("#EPcornerstable").empty();
                        var length = $scope.EPAllBuildServers.length;
                        for (i = 0; i < length; i++) {
                            var container = '<td> <div class="shadow colelem" <table style="width:80%"><tr > <td  id="ID_' + $scope.EPAllBuildServers[i].name + '"  class="TFSStack1">  <img src="Images/' + $scope.EPAllBuildServers[i].name + 'ICON.png" style="padding-top: 18px; margin-left: 30%;" /><br /><label style=" margin-left: 35%;margin-top:5%"> ' + $scope.EPAllBuildServers[i].name + '</label></td></tr></table></div></td>';
                            $("#EPcornerstable").append(container);
                            $('#EPTitle').text('Build Server');
                            $('#ID_TFS').css({
                                'opacity': '0.25',
                                'cursor': 'default',
                            });
                        }
                        break;
                    case 'Code Artifactory':
                        $("#EPcornerstable").empty();
                        var length = $scope.EPAllCodeArtifactorys.length;
                        for (i = 0; i < length; i++) {
                            var container = '<td> <div class="shadow colelem" <table style="width:80%"><tr > <td id="ID_' + $scope.EPAllCodeArtifactorys[i].name + '" class="TFSStack1" style="margin-left:35%" >  <img src="Images/' + $scope.EPAllCodeArtifactorys[i].name + 'ICON.png" style="padding-top: 18px; margin-left: 30%;" /><br /><label style=" margin-left: 35%;margin-top:5%">' + $scope.EPAllCodeArtifactorys[i].name + '</label></td></tr></table></div></td>';
                            $("#EPcornerstable").append(container);
                            $('#EPTitle').text('Code Artifactory')
                        }
                        break;
                    case 'Quality Tool':
                        $("#EPcornerstable").empty();
                        var length = $scope.EPAllQualityTools.length;
                        for (i = 0; i < length; i++) {
                            var container = '<td> <div class="shadow colelem" <table style="width:80%"><tr > <td id="ID_' + $scope.EPAllQualityTools[i].name + '"class="TFSStack1" style="margin-left:35%" >  <img src="Images/' + $scope.EPAllQualityTools[i].name + 'ICON.png" style="padding-top: 18px; margin-left: 30%;" /><br /><label style=" margin-left: 35%;margin-top:5%"> ' + $scope.EPAllQualityTools[i].name + '</label></td></tr></table></div></td>';
                            $("#EPcornerstable").append(container);
                            $('#EPTitle').text('Quality Tools');
                        }
                        break;
                    case 'Code Review Tool':
                        $("#EPcornerstable").empty();
                        var length = $scope.EPAllCodeReviewTools.length;
                        for (i = 0; i < length; i++) {
                            var container = '<td> <div class="shadow colelem" <table style="width:80%"><tr > <td id="ID_' + $scope.EPAllCodeReviewTools[i].name + '" class="TFSStack1" >  <img src="Images/' + $scope.EPAllCodeReviewTools[i].name + 'ICON.png" style="padding-top: 18px; margin-left: 30%;" /><br /><label style=" margin-left: 35%;margin-top:5%">' + $scope.EPAllCodeReviewTools[i].name + '</label></td></tr></table></div></td>';
                            $("#EPcornerstable").append(container);
                            $('#EPTitle').text('Code Review Tools');
                            
                            $('#ID_CheckStyle,#ID_Corbertura').css({
                                'opacity': '0.25',
                                'cursor': 'default',
                            });
                        }
                        break;
                    case 'Compiler Tool':
                        $("#EPcornerstable").empty();
                        var length = $scope.EPAllCompilerTools.length;
                        for (i = 0; i < length; i++) {
                            var container = '<td> <div class="shadow colelem" <table style="width:80%"><tr > <td style="margin-left:35%" id="ID_' + $scope.EPAllCompilerTools[i].name + '" class="TFSStack1">  <img src="Images/' + $scope.EPAllCompilerTools[i].name + 'ICON.png" style="padding-top: 18px; margin-left: 30%;" /><br /><label style=" margin-left: 35%;margin-top:5%"> ' + $scope.EPAllCompilerTools[i].name + '</label></td></tr></table></div></td>';
                            $("#EPcornerstable").append(container);
                            $('#EPTitle').text('Compiler Tools');
                        }
                        break;
               
                 
                }
                
                $('#ID_Sonar').unbind('click').click(function () {
                    var toolcontainer = '<td id="TDTool_Sonar_' + countSonar + '"  class="removetoolclass"><a  style="outline:none;margin:auto;align-self:center!important" class="shadow colelem  " ng-disabled="isDisabled1"><img id="IDTool_Sonar_' + countSonar + '" src="../Images/SonarICON.png" style="padding-top: 0px; padding-left: 0px;" /><div id="IDTool_Sonar_' + countSonar + '" style="padding-top: 0px; padding-left: 6px; font-size: 17px; ">Sonar</div></a></td>';
                    $("#Tool1_Sonar").append(toolcontainer);
                    countSonar++;
                });
                
                $('#ID_GIT').unbind('click').click(function () {
                    var toolcontainer = '<td id="TDTool_GIT_' + countGIT + '"   class="removetoolclass Gitdata" style="padding:5px"><a style="outline:none;align-self:center!important" class="shadow colelem  " ng-disabled="isDisabled1"><img  id="IDTool_GIT_' + countGIT + '" src="../Images/GITICON.png" style="padding-top: 0px; padding-left: 0px;" /><div  id="IDTool_GIT_' + countGIT + '" style="padding-top: 0px; padding-left: 6px; font-size: 17px; ">GIT</div></a></td>';
                    $("#Tool1_GIT").append(toolcontainer);
                    countGIT++;
                });
                $('#ID_Jenkins').unbind('click').click(function () {
                    var toolcontainer = '<td id="TDTool_Jenkins_' + countJenkins + '"   class="removetoolclass"><a  style="outline:none;margin:auto;align-self:center!important" class="shadow colelem  " ng-disabled="isDisabled1"><img id="IDTool_Jenkins_' + countJenkins + '" src="../Images/JenkinsICON.png" style="padding-top: 0px; padding-left: 0px;" /><div onclick="angular.element(this).scope().abfunc()"  id="IDTool_Jenkins_' + countJenkins + '" style="padding-top: 0px; padding-left: 6px; font-size: 17px; ">Jenkins</div></a></td>';
                    $("#Tool1_Jenkins").append(toolcontainer);
                    countJenkins++;
                });
                
                $('#ID_Nexus').unbind('click').click(function () {
                    var toolcontainer = '<td id="TDTool_Nexus_' + countNexus + '"    class="removetoolclass"><a  style="outline:none;margin:auto;align-self:center!important" class="shadow colelem  " ng-disabled="isDisabled1"><img id="IDTool_Nexus_' + countNexus + '" src="../Images/NexusICON.png" style="padding-top: 0px; padding-left: 0px;" /><div id="IDTool_Nexus_' + countNexus + '" style="padding-top: 0px; padding-left: 6px; font-size: 17px; ">Nexus</div></a></td>';
                    $("#Tool1_Nexus").append(toolcontainer);
                    countNexus++;
                });
                
                $('#ID_FindBugs').unbind('click').click(function () {
                    var toolcontainer = '<td id="TDTool_FindBugs_' + countFindBug + '"   class="removetoolclass"><a style="outline:none;margin:auto;align-self:center!important" class="shadow colelem  " ng-disabled="isDisabled1"><img id="IDTool_FindBugs_' + countFindBug + '"  src="../Images/FindBugsICON.png" style="padding-top: 0px; padding-left:0px;" /><div id="IDTool_FindBugs_' + countFindBug + '"  style="padding-top:0px; padding-left:6px; font-size: 17px; ">FindBugs</div></a></td>';
                    $("#Tool1_FindBugs").append(toolcontainer);
                    countFindBug++;
                });
                
                $('#ID_ANT').unbind('click').click(function () {
                    var toolcontainer = '<td id="TDTool_ANT_' + countANT + '"   class="removetoolclass"><a style="outline:none;margin:auto;align-self:center!important" class="shadow colelem  " ng-disabled="isDisabled1"><img id="IDTool_ANT_' + countANT + '" src="../Images/ANTICON.png" style="padding-top: 0px; padding-left: 0px;" /><div id="IDTool_ANT_' + countANT + '"  style="padding-top: 0px; padding-left: 6px; font-size: 17px; ">ANT</div></a></td>';
                    $("#Tool1_ANT").append(toolcontainer);
                    countANT++;
                });
                
                
                $(".removetoolclass").unbind('dblclick').dblclick(function () {
                    
                    var antid = $(event.target).attr("id");
                    var antid1 = "#" + antid;
                    var tdid = antid.substring(1, antid.length);
                    
                    var tdid1 = "#T" + tdid;
                    var tableid = antid.substring(7, antid.length - 2);
                    var tableid1 = "#Table_" + tableid;
                    var countTD = $("#Table_" + tableid + " tr:first > td").length;
                    //alert(countTD);
                    if (countTD > 1) {
                        //$(antid1).remove();
                        //$(antid1).remove();
                        $(tdid1).remove();
                    }
                });
        
            }
        }
        
        /*
        * Search a specific key value pair index availability
        * @param  {array} arraytosearch 
        * @param  {string} key
        * @param  {string} valuetosearch
        * @return {Number} index value
        */
        $scope.searcharray = function (arraytosearch, key, valuetosearch) {
            
            for (var i = 0; i < arraytosearch.length; i++) {
                
                if (arraytosearch[i][key] == valuetosearch) {
                    return i;
                }
            }
            return null;
        }
        
        /*function to fill version dropdown according the tool user selects
         * @param {string} ToolType
        */
        $scope.VersionData = function (container, ToolType) {
            
            debugger;            
            CIFactory.GetversionByToolName(container, ToolType).then(function (result) {
                debugger;
                
            switch (ToolType) {
                
                case 'Jenkins':
                        //$scope.Versions = ["1.554", "2.19.3", "2.46.3"];
                        $scope.Versions = result;
                        debugger;
                    break;
                case 'GIT':
                        //$scope.Versions = ["2.9.5"];
                        $scope.Versions = result;
                    break;
                case 'SVN':
                        // $scope.Versions = ["1.9.5"];
                        $scope.Versions = result;
                    break;
                case 'Sonar':
                        //$scope.Versions = ["6.4"];
                        $scope.Versions = result;
                    break;
                case 'Nexus':
                       // $scope.Versions = ["3.3.1"];
                        $scope.Versions = result;
                    break;
                case 'FindBugs':
                        //$scope.Versions = ["3.0.1"];
                        $scope.Versions = result;
                    break;
                case 'ANT':
                       // $scope.Versions = ["1.9.6"];
                        $scope.Versions = result;
                    break;

            }

            }, function (error) {
                debugger;
                return null;
            });

            

        }
        
        /*
        * Function to save the data for each conatiner and fetch the data to be shown to user
        * @param  {string} container 
        * @param  {string} toolType
        * @param  {string} event
        */
            debugger;
        $scope.LoadToolsInfo = function (container, toolType, event) {
            debugger;
            if (!$scope.BuildModel.DisableControl) {
                
                var noValidationErrors = true;
                if (($("#divEnvprovConfig").is(':visible'))) {
                    noValidationErrors = $scope.ValidationsCheck(ClientConfig.ENVIRONMENTCONFIGURATION);
                }
                
                //if no errors appear proceed with the click event
                if (noValidationErrors) {
                    
                    event.stopPropagation();
                    event.preventDefault();
                    
                        $scope.VersionData(container, toolType);
                    //eabling Save button functionality
                    $scope.enableSaveButton(container);
                    
                    $scope.toolsIconSelected = ClientConfig.BOOL_TRUE;
                    $scope.showproperties = ClientConfig.BOOL_TRUE;
                    
                    //get the div ID of the Selected Icon
                    containerId = $(event.target).attr("id");
                    
                    //push the selected containers to a list
                    
                    var toolDetails = ({
                        container       : container.replace(/\s/g, ''),
                        toolType        : toolType,
                        containerId     : containerId
                    });
                    
                    toolInfo.push(toolDetails);
                    //Fetch the last selected value from the list to be saved in Mongo
                    selectedToolType = toolInfo[0].toolType;
                    selectedContainer = toolInfo[0].container;
                    containerId = toolInfo[0].containerId;
                    
                    if (toolInfo.length > 1) {
                        currentIcon = toolInfo[1].containerId;
                        currentSection = toolInfo[1].container;
                        currentType = toolInfo[1].toolType;
                        //Remove and replace  the firstelement with second
                        toolInfo.shift();
                    }
                    
                    //Check for the availability if the choosen image in the list
                    var availableinList = choosenListofCont.indexOf(selectedContainer + containerId) > -1;
                    if (toolType != null && toolType != undefined && !availableinList) {
                        $scope.getContainersDetails();
                    }
                    else {
                        $scope.EnvProvToolsDetails.Tool = ClientConfig.EMPTY;
                    }
                    
                    //Check to disable/enable the save button
                    if (choosenListofCont.length > 0) {
                        $scope.BuildModel.DisableStaticControls = ClientConfig.BOOL_FALSE;
                    }
                    else {
                        $scope.BuildModel.DisableStaticControls = ClientConfig.BOOL_TRUE;
                    }
                    //Clear the build model data on click of icon
                    
                    var currentlyViewedCont = container.replace(/\s/g, '');
                    if (currentlyViewedCont == ClientConfig.SOURCECONTROL) {
                        var index = $scope.searcharray($scope.sourceControl, "containerId", currentIcon);
                        if (index != null && index != undefined) {
                            $scope.EnvProvToolsDetails.Tool = $scope.sourceControl[index];
                            $scope.sourceControl[index] = $scope.EnvProvToolsDetails.Tool;
                        }
            
            
                    }
                    if (currentlyViewedCont == ClientConfig.BUILDSERVER) {
                        var index = $scope.searcharray($scope.buildServer, "containerId", currentIcon);
                        if (index != null && index != undefined) {
                            $scope.EnvProvToolsDetails.Tool = $scope.buildServer[index];
                            $scope.buildServer[index] = $scope.EnvProvToolsDetails.Tool;
                        }
                    }
                    if (currentlyViewedCont == ClientConfig.COMPILERTOOL) {
                        var index = $scope.searcharray($scope.compilerTool, "containerId", currentIcon);
                        if (index != null && index != undefined) {
                            $scope.EnvProvToolsDetails.Tool = $scope.compilerTool[index];
                            $scope.compilerTool[index] = $scope.EnvProvToolsDetails.Tool;
                        }
                    }
                    if (currentlyViewedCont == ClientConfig.CODEARTIFACTORY) {
                        var index = $scope.searcharray($scope.codeArtifactory, "containerId", currentIcon);
                        if (index != null && index != undefined) {
                            $scope.EnvProvToolsDetails.Tool = $scope.codeArtifactory[index];
                            $scope.codeArtifactory[index] = $scope.EnvProvToolsDetails.Tool;
                        }
                    }
                    if (currentlyViewedCont == ClientConfig.QUALITYTOOL) {
                        var index = $scope.searcharray($scope.qualityTool, "containerId", currentIcon);
                        if (index != null && index != undefined) {
                            $scope.EnvProvToolsDetails.Tool = $scope.qualityTool[index];
                            $scope.qualityTool[index] = $scope.EnvProvToolsDetails.Tool;
                        }
                    }
                    if (currentlyViewedCont == ClientConfig.CODEREVIEWTOOl) {
                        var index = $scope.searcharray($scope.codeReviewTool, "containerId", currentIcon);
                        if (index != null && index != undefined) {
                            $scope.EnvProvToolsDetails.Tool = $scope.codeReviewTool[index];
                            $scope.codeReviewTool[index] = $scope.EnvProvToolsDetails.Tool;
                        }
                    }
                }
           
            }
            
        }
        
        
        /*
        * Functon to Save container details to Array
        * @param  {bool} data 
        */
        $scope.getContainersDetails = function (data) {
            
            //CHeck of the availability of id name in the list
            var availableinList = ClientConfig.BOOL_FALSE;
            if (data) {
                if (currentSection != null) {
                    selectedContainer = currentSection;
                    selectedToolType = currentType;
                }
                if (choosenListofCont.indexOf(currentSection + currentIcon) > -1) {
                    availableinList = ClientConfig.BOOL_TRUE;
                }
            }
            else if (choosenListofCont.indexOf(selectedContainer + containerId) > -1) {
                availableinList = ClientConfig.BOOL_TRUE;
            }
            
            
            if (!availableinList) {
                
                if ($scope.EnvProvToolsDetails.Tool != undefined && $scope.EnvProvToolsDetails.Tool != ClientConfig.EMPTY) {
                    
                    //push the combined name of sourcecontrol and Container name
                    choosenListofCont.push(selectedContainer + containerId);
                    $scope.containersInfo = ({
                        Type         : selectedToolType,
                        Name         : $scope.EnvProvToolsDetails.Tool.Name != null? $scope.EnvProvToolsDetails.Tool.Name:ClientConfig.EMPTY,
                        Version      : $scope.EnvProvToolsDetails.Tool.Version != null? $scope.EnvProvToolsDetails.Tool.Version:ClientConfig.EMPTY,
                        UserName     : $scope.EnvProvToolsDetails.Tool.UserName != null? $scope.EnvProvToolsDetails.Tool.UserName:ClientConfig.EMPTY,
                        Password     : $scope.EnvProvToolsDetails.Tool.Password != null? $scope.EnvProvToolsDetails.Tool.Password:ClientConfig.EMPTY,
                        PortNumber   : $scope.EnvProvToolsDetails.Tool.PortNumber != null? $scope.EnvProvToolsDetails.Tool.PortNumber:ClientConfig.EMPTY,
                        containerId  : containerId
                    });
                    
                    //Check for SOURCECONTROL
                    if (selectedContainer == ClientConfig.SOURCECONTROL) {
                        $scope.sourceControl.push($scope.containersInfo);
                    
                    }
                    //Check for BUILDSERVER
                    if (selectedContainer == ClientConfig.BUILDSERVER) {
                        $scope.buildServer.push($scope.containersInfo);
                    
                    }
                    //Check for COMPILERTOOL
                    if (selectedContainer == ClientConfig.COMPILERTOOL) {
                        $scope.compilerTool.push($scope.containersInfo);
                    
                    }
                    //Check for CODEARTIFACTORY
                    if (selectedContainer == ClientConfig.CODEARTIFACTORY) {
                        $scope.codeArtifactory.push($scope.containersInfo);
                    
                    }
                    //Check for QUALITYTOOL
                    if (selectedContainer == ClientConfig.QUALITYTOOL) {
                        $scope.qualityTool.push($scope.containersInfo);
                   
                    }
                    //Check for CODEREVIEWTOOl
                    if (selectedContainer == ClientConfig.CODEREVIEWTOOl) {
                        $scope.codeReviewTool.push($scope.containersInfo);
                    
                    }
                    $scope.EnvProvToolsDetails.Tool = ClientConfig.EMPTY;
                
                }
            }
        }
        
        
        /*
        * Function to save container data in Mongo Db
        */
        $scope.InsertToolDetails = function () {
            
            var IsValid = $scope.ValidationsCheck(ClientConfig.ENVIRONMENTCONFIGURATION);
            if (IsValid == ClientConfig.BOOL_TRUE) {
                
                //to load the user inout data
                $scope.getContainersDetails(true);
                
                
                //Removal of additional parameter containerId from all the objects
                
                $scope.sourceControl.forEach(function (info) { delete info.containerId });
                $scope.buildServer.forEach(function (info) { delete info.containerId });
                $scope.compilerTool.forEach(function (info) { delete info.containerId });
                $scope.codeArtifactory.forEach(function (info) { delete info.containerId });
                $scope.qualityTool.forEach(function (info) { delete info.containerId });
                $scope.codeReviewTool.forEach(function (info) { delete info.containerId });
                
                //Full Json for the Containers
                $scope.envProvToolsDetails = ({
                    ContainerStackName : $scope.EnvProvToolsDetails.ContainerStackName,
                    SourceControl   : $scope.sourceControl,
                    BuildServer     : $scope.buildServer,
                    CompilerTool    : $scope.compilerTool,
                    CodeArtifactory : $scope.codeArtifactory,
                    QualityTool     : $scope.qualityTool,
                    CodeReviewTool  : $scope.codeReviewTool
                });
                
                //Clear Containrs list before saving data in Mongo Db
                choosenListofCont = [];
                
                //Service Calls to insert the tools Details
                
                CIFactory.InsertToolDetails($scope.envProvToolsDetails).then(function (result) {
                    if (result == ClientConfig.SUCCESS_MSG) {
                        
                        //On success status call the function
                        Alertify.confirm(ClientConfig.ADD_ENV_PROV_SUCCESS_MSG).then(
                            function onOk() {
                                $scope.$emit(ClientConfig.ENVMAPPING, $scope.EnvProvToolsDetails.ContainerStackName);
                            },
                        function onCancel() {
                                $scope.ResetToolsData();

                            }
                        );
                        $scope.EnvProvToolsDetails.Tool = ClientConfig.EMPTY;
                        //$scope.InsertVMContainerMappingDetails($scope.envProvToolsDetails);

                    }

                }, function (error) {
                    Alertify.alert(ClientConfig.ADD_ENV_MAPPING_ERROR_MSG);
                });
            }
        }
        
        
        
        
        
        
        /*
        * Function to enable/Disale the Save button
        * @param  {string} container 
        */
         $scope.checkboxClick = function (group, $event) {
            $event.stopPropagation();
        }
        
        $scope.enableSaveButton = function (container) {
            if ($scope.selectedtools.indexOf(container) == -1) {
                $scope.selectedtools.push(container);
                if ($scope.selectedtools.length > 5) {
                    $scope.BuildModel.DisableControls = ClientConfig.BOOL_FALSE;
                }
              
            }
        }
        
        
        $scope.Toolgroups = [
            {
                title: 'Source Control',
                content: {
                    image: '../Images/' + $scope.EPSourceControls[0].name + 'ICON.png ' ,
                    text: $scope.EPSourceControls[0].name
                }
            },
            {
                title: 'Build Server',
                content: {
                    image: '../Images/' + $scope.EPBuildServers[0].name + 'ICON.png',
                    text: $scope.EPBuildServers[0].name
                }
            },
            {
                title: 'Compiler Tool',
                content: {
                    image: '../Images/' + $scope.EPCompilerTools[0].name + 'ICON.png',
                    text: $scope.EPCompilerTools[0].name
                }
            },
            {
                title: 'Quality Tool',
                content: {
                    image: '../Images/' + $scope.EPQualityTools[0].name + 'ICON.png',
                    text: $scope.EPQualityTools[0].name
                }
            },
            {
                title: 'Code Review Tool',
                content: {
                    image: '../Images/' + $scope.EPCodeReviewTools[0].name + 'ICON.png',
                    text: $scope.EPCodeReviewTools[0].name
                }
            }, 
            {
                title: 'Code Artifactory',
                content: {
                    image: '../Images/' + $scope.EPCodeArtifactorys[0].name + 'ICON.png',
                    text: $scope.EPCodeArtifactorys[0].name
                }
            }
        ];
        
        
        /*
        * UI Selection toggling
        */ 
        $scope.status = {
            isCustomHeaderOpen: ClientConfig.BOOL_FALSE,
            isFirstOpen: true,
            isFirstDisabled: ClientConfig.BOOL_FALSE
        };
        
        /*
        * Function to Save Environment Provisioning data to Mongo Db
        * @param  {Array} toolsDetails 
        */  
        //$scope.InsertVMContainerMappingDetails = function (toolsDetails) {
            
        //    $scope.availableContainers = [];
        //    $scope.vmContainerMapping = [];
        //    $scope.vmHostingDetails = [];
        //    var minvalue = incrementvalue = 0;
            
        //    //push the available containers to the list after lenght check
        //    //Check for SOURCECONTROL
        //    if (toolsDetails.SourceControl.length > 0) {
        //        $scope.toolsRemaping = ({
        //            Tag: ClientConfig.SOURCECONTROL,
        //            toolsDetails: toolsDetails.SourceControl
        //        });
        //        $scope.availableContainers.push($scope.toolsRemaping);
        //    }
        //    //Check for BUILDSERVER
        //    if (toolsDetails.BuildServer.length > 0) {
        //        $scope.toolsRemaping = ({
        //            Tag: ClientConfig.BUILDSERVER,
        //            toolsDetails: toolsDetails.BuildServer
        //        });
        //        $scope.availableContainers.push($scope.toolsRemaping);
        //    }
        //    //Check for COMPILERTOOL
        //    if (toolsDetails.CompilerTool.length > 0) {
        //        $scope.toolsRemaping = ({
        //            Tag: ClientConfig.COMPILERTOOL,
        //            toolsDetails: toolsDetails.CompilerTool
        //        });
        //        $scope.availableContainers.push($scope.toolsRemaping);
        //    }
        //    //Check for CODEARTIFACTORY
        //    if (toolsDetails.CodeArtifactory.length > 0) {
        //        $scope.toolsRemaping = ({
        //            Tag: ClientConfig.CODEARTIFACTORY,
        //            toolsDetails: toolsDetails.CodeArtifactory
        //        });
        //        $scope.availableContainers.push($scope.toolsRemaping);
        //    }
        //    //Check for QUALITYTOOL
        //    if (toolsDetails.QualityTool.length > 0) {
        //        $scope.toolsRemaping = ({
        //            Tag: ClientConfig.QUALITYTOOL,
        //            toolsDetails: toolsDetails.QualityTool
        //        });
        //        $scope.availableContainers.push($scope.toolsRemaping);
        //    }
        //    //Check for CODEREVIEWTOOl
        //    if (toolsDetails.CodeReviewTool.length > 0) {
        //        $scope.toolsRemaping = ({
        //            Tag: ClientConfig.CODEREVIEWTOOl,
        //            toolsDetails: toolsDetails.CodeReviewTool
        //        });
        //        $scope.availableContainers.push($scope.toolsRemaping);
        //    }
            
            
        //    //To be replaced with dynamic data
        //    //List down the static VM Details 
            
        //    var vmDetails = JSON.parse(ClientConfig.VIRTUALMACHINES).VirtualMachine;
            
        //    //Loop each vm from the list to get VM details
        //    //flow will be need of atleast one container for each vmand a maximum of two.If containers are not available then Vm need not be inserted in the mongo
        //    for (i = 0; i < vmDetails.length; i++) {
        //        $scope.vmContainers = [];
        //        $scope.containers = [];
        //        $scope.containersInfo = [];
        //        var containerExists = ClientConfig.BOOL_FALSE;
                
        //        //Get Container details for each VM and Map a maximum of two cntainers for each VM.
                
        //        for (j = minvalue; j < minvalue + 2 ; j++) {
                    
                    
        //            //Check for length 
        //            if ($scope.availableContainers[j] !== undefined) {
                        
        //                containerExists = ClientConfig.BOOL_TRUE;
        //                //List of sub objects in availableContainers container
        //                for (k = 0; k < $scope.availableContainers[j].toolsDetails.length; k++) {
                            
        //                    $scope.containersInfo = ({
        //                        Tag: $scope.availableContainers[j].Tag,
        //                        Name: $scope.availableContainers[j].toolsDetails[k].Name,
        //                        Type: $scope.availableContainers[j].toolsDetails[k].Type,
        //                        Status: ""
        //                    });
        //                    $scope.containers.push($scope.containersInfo);
        //                }
                        
        //                //Every time incerement a value for each container process
        //                incrementvalue = incrementvalue + 1;
        //            }
                        
        //        }
        //        //Limit of Max 2 containers for each VM
        //        if ((incrementvalue == minvalue + 2) || ($scope.availableContainers.length < 2)) {
        //            minvalue = incrementvalue;
                        
        //        }
                
                
        //        //Check if container exists
        //        if (containerExists) {
        //            //Framing array based on the info parsed
        //            $scope.vmContainers = ({
        //                VMName: vmDetails[i].vmName,
        //                UserName: vmDetails[i].userName,
        //                Password: vmDetails[i].password,
        //                Containers  : $scope.containers

        //            });
                    
        //            //Pushing data to VmContainers array for each mapping
        //            $scope.vmContainerMapping.push($scope.vmContainers);
        //        }
        //    }
            
        //    //final model framed based on the data
            
        //    $scope.vmHostingDetails = ({
        //        ApplicationName: toolsDetails.ApplicationName,
        //        VMContainerMapping: $scope.vmContainerMapping

        //    });
            
        //    if ($scope.availableContainers.length > 0) {
                
        //        //save containermapping data to mongodb and call function for containerization on success data                      
        //        CIFactory.InsertVMContainerMappingDetails($scope.vmHostingDetails).then(function (result) {
        //            if (result == ClientConfig.SUCCESS_MSG) {
        //                //On success status call the function
        //                Alertify.alert(ClientConfig.ADD_ENV_MAPPING_SUCCESS_MSG);
        //                $scope.ResetToolsData();
                        
                        
        //                CIFactory.CreateEnvProvisioning(toolsDetails, $scope.vmHostingDetails, $scope.EPToolsInfo).then(function (result) {
        //                    if (result != ClientConfig.UNDEFINED) {
        //                        //On success status call the function
        //                        //Alertify.alert(ClientConfig.CREATE_ENV_VMCONTAINERS_SUCCESS_MSG);
                               
        //                    }
                           

        //                }, function (error) {
                            
        //                });
                        
                        
        //                $scope.$emit(ClientConfig.UPDATEENVPROVCONFIGAPPLICATION, {

        //                });
                        

        //            }

        //        }, function (error) {
        //            Alertify.alert(ClientConfig.ADD_ENV_MAPPING_ERROR_MSG);
        //        });
        //    }
        //}
        


        
        /* Already exists application validation */

        $scope.IsContainerExists = function () {
            
            var SelectedContainerStackName = $scope.EnvProvToolsDetails.ContainerStackName;
            
            var SelectedObject = $.grep($scope.EnvProvConfigApplications, function (item) {
                return item.ContainerStackName.toUpperCase() == SelectedContainerStackName.toUpperCase();
            })[0]
            if (SelectedObject != undefined) {
                Alertify.alert(SelectedContainerStackName + ClientConfig.IS_ALREADY_EXIST);
                $scope.EnvProvToolsDetails.ContainerStackName = ClientConfig.EMPTY;
            }
        }
        
        //$scope.GetApprove = function () {
        //    alert('Hi Friends');
        //    //CIFactory.UpdateApprovalStatusMongo(applicationname).then(function (result) {
        //    //    if (result == ClientConfig.UPDATE) {
        //    //        Alertify.alert(ClientConfig.UPDATE_APPROVAL_STATUS_MSG);
        //    //        $scope.loadDashboard();
        //    //    }
        //    //});
        //}
        

        /*
        * Function to Reset the form/User Selection
        * @param  {Array} toolsDetails 
        */ 

          $scope.$on('ResetToolsData', function (e) {
            $scope.ResetToolsData();
        });
      
        $scope.ResetToolsData = function () {
            
            $scope.BuildModel.DisableControl = ClientConfig.BOOL_FALSE;
            selectedContainer = null, containerId = null, currentSection = null, selectedToolType = null, toolInfo = [], countSonar = 1, countGIT = 1, EPvalidcount = 1;
            countNexus = 1, countJenkins = 1, countFindBug = 1, countANT = 1, choosenListofCont = [], currentIcon = currentType = null;
            $scope.sourceControl = []; $scope.buildServer = []; $scope.compilerTool = [];
            $scope.codeArtifactory = []; $scope.qualityTool = []; $scope.codeReviewTool = [];
            $scope.EnvProvToolsDetails.ContainerStackName = ClientConfig.EMPTY;
            $scope.toolsIconSelected = ClientConfig.BOOL_FALSE;
            $scope.showproperties = ClientConfig.BOOL_FALSE;
            $scope.selectedtools = [];
            if ($scope.EnvProvToolsDetails.Tool.Name != ClientConfig.UNDEFINED) {
            $scope.EnvProvToolsDetails.Tool.Name = ClientConfig.EMPTY;
            $scope.EnvProvToolsDetails.Tool.Version = ClientConfig.EMPTY;
            $scope.EnvProvToolsDetails.Tool.UserName = ClientConfig.EMPTY;
            $scope.EnvProvToolsDetails.Tool.Password = ClientConfig.EMPTY;
                $scope.EnvProvToolsDetails.Tool.PortNumber = ClientConfig.EMPTY;
            }
            
            $scope.EnvironmentConfigurationErrors = ClientConfig.BOOL_FALSE;
            $scope.BuildModel.DisableControls = ClientConfig.BOOL_FALSE;
            // for accordion close
            $scope.Toolgroups.map(function (Toolgroup) {
                Toolgroup.open = false;
            });
             
             $location.path(ClientConfig.ENVPROVTOOLSSTACK);
        }
        
        /* Function to reset the VM Details */
        
        $scope.ResetVMDetails = function () {
            
            
            $('.tdstyle').empty();
            $('.Ecard').css({ 'opacity': '1' });
            // //$('.Ecard1').removeAttribute('dragabble');
            
            $('.Ecard1').attr('draggable', 'true');
            if (!$('#EcardSourceControl').find('#SourceControlContainerid').length) {
                $('#EcardSourceControl').append(' <div id="SourceControlContainerid" style="width: 80px; height: 68px; outline:auto; outline-color: grey; outline-width: thin; margin:auto; box-sizing: border-box;" draggable="true" ondragstart="drag(event)"><img id="Typeid' + $scope.containerSourceControl[0].Type + '"  src="../Images/' + $scope.containerSourceControl[0].Type + 'ICON.png" alt="Source Control" style="height: 40px; width: 40px;margin-left:20px;margin-top:3px;"><p id="Nameid' + $scope.containerSourceControl[0].Name + '" class="title">' + $scope.containerSourceControl[0].Name + '</p></div>');
            }
            if (!$('#EcardBuildServer').find('#BuildServerContainerid').length) {
                $('#EcardBuildServer').append(' <div id="BuildServerContainerid" style="width: 80px; height: 68px; outline:auto; outline-color: grey; outline-width: thin;  margin:auto; box-sizing: border-box;" draggable="true" ondragstart="drag(event)"><img id="Typeid' + $scope.containerBuildServer[0].Type + '"  src="../Images/' + $scope.containerBuildServer[0].Type + 'ICON.png" alt="Source Control" style="height: 40px; width: 40px;margin-left:20px;margin-top:3px;"><p id="Nameid' + $scope.containerBuildServer[0].Name + '" class="title">' + $scope.containerBuildServer[0].Name + '</p></div>')
            }
            if (!$('#EcardCompilerTool').find('#CompilerToolContainerid').length) {
                $('#EcardCompilerTool').append(' <div id="CompilerToolContainerid" style="width: 80px; height: 68px; outline:auto; outline-color: grey; outline-width: thin;  margin:auto; box-sizing: border-box;" draggable="true" ondragstart="drag(event)"><img id="Typeid' + $scope.containerCompilerTool[0].Type + '"  src="../Images/' + $scope.containerCompilerTool[0].Type + 'ICON.png" alt="Source Control" style="height: 40px; width: 40px;margin-left:20px;margin-top:3px;"><p id="Nameid' + $scope.containerCompilerTool[0].Name + '" class="title">' + $scope.containerCompilerTool[0].Name + '</p></div>');
            }
            if (!$('#EcardQualityTool').find('#QualityToolContainerid').length) {
                $('#EcardQualityTool').append(' <div id="QualityToolContainerid" style="width: 80px; height: 68px; outline:auto; outline-color: grey; outline-width: thin;  margin:auto; box-sizing: border-box;" draggable="true" ondragstart="drag(event)"><img id="Typeid' + $scope.containerQualityTool[0].Type + '"  src="../Images/' + $scope.containerQualityTool[0].Type + 'ICON.png" alt="Source Control" style="height: 40px; width: 40px;margin-left:20px;margin-top:3px;"><p id="Nameid' + $scope.containerQualityTool[0].Name + '" class="title">' + $scope.containerQualityTool[0].Name + '</p></div>');
            }
            if (!$('#EcardCodeReviewTool').find('#CodeReviewToolContainerid').length) {
                $('#EcardCodeReviewTool').append(' <div id="CodeReviewToolContainerid" style="width: 80px; height: 68px; outline:auto; outline-color: grey; outline-width: thin;  margin:auto;box-sizing: border-box;" draggable="true" ondragstart="drag(event)"><img id="Typeid' + $scope.containerCodeReviewTool[0].Type + '"  src="../Images/' + $scope.containerCodeReviewTool[0].Type + 'ICON.png" alt="Source Control" style="height: 40px; width: 40px;margin-left:20px;margin-top:3px;"><p id="Nameid' + $scope.containerCodeReviewTool[0].Name + '" class="title">' + $scope.containerCodeReviewTool[0].Name + '</p></div>');
            }
            if (!$('#EcardCodeArtifactory').find('#CodeArtifactoryContainerid').length) {
                $('#EcardCodeArtifactory').append(' <div id="CodeArtifactoryContainerid" style="width: 80px; height: 68px; outline:auto; outline-color: grey; outline-width: thin; margin:auto; box-sizing: border-box;" draggable="true" ondragstart="drag(event)"><img id="Typeid' + $scope.containerCodeArtifactory[0].Type + '"  src="../Images/' + $scope.containerCodeArtifactory[0].Type + 'ICON.png" alt="Source Control" style="height: 40px; width: 40px;margin-left:20px;margin-top:3px;"><p id="Nameid' + $scope.containerCodeArtifactory[0].Name + '" class="title">' + $scope.containerCodeArtifactory[0].Name + '</p></div>');
            }
            if ($scope.EnvProvVMDetails != ClientConfig.UNDEFINED) {
            $scope.EnvProvVMDetails.VMName = ClientConfig.EMPTY;
            $scope.EnvProvVMDetails.UserName = ClientConfig.EMPTY;
            $scope.EnvProvVMDetails.Password = ClientConfig.EMPTY;
            }
            $scope.EnvironmentMappingErrors = ClientConfig.BOOL_FALSE;
            $scope.FormVMDetails = [];
              
          
            //$('this').closest('containerstack');
            //$('#Button1VM').closest('#1VM').show();
           
        }
        
     /* Getting Approval Status */
        
        $scope.GetApprove = function () {
            alert('HI FRIEDNS');
            //CIFactory.UpdateApprStatus(applicationname).then(function (result) {
            //    if (result == ClientConfig.UPDATE) {
            //        Alertify.alert(ClientConfig.UPDATE_APPROVAL_STATUS_MSG);
            //        $scope.loadDashboard();
            //    }
            //});
        }
        /*
        * Check for the form Validations
        * @param  {string} DivID 
        */ 

           

        $scope.ValidationsCheck = function (DivID) {
            var elements = $("#" + DivID + " :input");
            var invalidFields = [];
            for (var i = 0; i < elements.length; i++) {
                if (elements[i].tagName == 'INPUT') {
                    var elementName = elements[i].name;
                    if (elementName != ClientConfig.EMPTY && elementName != undefined && $scope.indexForm[elementName].$invalid) {
                        // debugger;
                        invalidFields.push(elementName);
                    }
                    
                }
               
            }
            if (invalidFields.length == 0) {
                
                return ClientConfig.BOOL_TRUE;
            } else {
                $scope[DivID + ClientConfig.ERRORS] = ClientConfig.BOOL_TRUE;
            }
            return ClientConfig.BOOL_FALSE;
        }
        

    }])


.directive('knob', function () {
    function link(scope, element, attr) {
        
        function draw() {
            
            element.empty();
            
            var tmpl = $('<input type="hidden">');
            var val = "100";
            var readonly = attr.readonly == "true" ? true : false;
            var sign = attr.sign ? attr.sign : "";
            var fgColor = scope.knobColor;
            
            
            element.append(tmpl);
            
            var options = {
                dynamicDraw: true,
                fgColor: fgColor,
                readOnly: readonly,
                rtl: (attr.dir == 'rtl' ? true : false),
                draw: function () {
                    $(this.i).val(this.cv + sign);
                }
            };
            tmpl.knob(options);
            
            tmpl.animate({
                value: 100
            }, {
                duration: 1000,
                easing: 'swing',
                progress: function () {
                    $(this).val(Math.round(this.value / 100 * val)).trigger('change');
                }
            })
        }
        
        scope.$watch(function () {
            attr.fgColor = scope.knobColor;
            return [attr.fgColor, attr.readonly];
        }, draw, true);

    }    ;
    
    return {
        priority: 99,
        restrict: 'A',
        link: link
    };
})


.directive('deployknob', function () {
    function link(scope, element, attr) {
        
        function draw() {
            
            element.empty();
            
            var tmpl = $('<input type="hidden">');
            var val = "100";
            var readonly = attr.readonly == "true" ? true : false;
            var sign = attr.sign ? attr.sign : "";
            var fgColor = scope.deployknobColor;
            
            
            element.append(tmpl);
            
            var options = {
                dynamicDraw: true,
                fgColor: fgColor,
                readOnly: readonly,
                rtl: (attr.dir == 'rtl' ? true : false),
                draw: function () {
                    $(this.i).val(this.cv + sign);
                }
            };
            tmpl.knob(options);
            
            tmpl.animate({
                value: 100
            }, {
                duration: 1000,
                easing: 'swing',
                progress: function () {
                    $(this).val(Math.round(this.value / 100 * val)).trigger('change');
                }
            })
        }
        
        scope.$watch(function () {
            attr.fgColor = scope.deployknobColor;
            return [attr.fgColor, attr.readonly];
        }, draw, true);

    }    ;
    
    return {
        priority: 99,
        restrict: 'A',
        link: link
    };
})


.directive("fileread", [function () {
        return {
            scope: {
                fileread: "="
            },
            link: function (scope, element, attributes) {
                element.bind("change", function (changeEvent) {
                    scope.$apply(function () {
                        scope.fileread = changeEvent.target.files[0];
                    // or all selected files:
                    // scope.fileread = changeEvent.target.files;
                    });
                });
            }
        }
    }])

.directive('modal', function () {
    return {
        template: '<div class="modal fade">' +
                '<div class="modal-dialog" style="margin-top: 250px;">' +
                '<div class="modal-content" style="height: 150px">' +
                '<div class="modal-header">' +
                '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
                //  '<h4 class="modal-title">Please enter the Stage Name</h4>' + 
                '</div>' +
                '<div class="modal-body" ng-transclude></div>' +
                '</div>' +
                '</div>' +
                '</div>',
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.visible, function (value) {
                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });
            
            $(element).on('shown.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = true;
                });
            });
            
            $(element).on('hidden.bs.modal', function () {
                scope.$apply(function () {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
})
    .directive('invalidfieldfocus', function () {
    return {
        restrict: 'A',
        link: function (scope, elem) {
            
            // set up event handler on the form element
            elem.on('submit', function () {
                
                
                // find the first invalid element
                var firstInvalid = elem[0].querySelector('.ng-invalid');
                
                // if we find one, set focus
                
                if (firstInvalid) {
                    
                    firstInvalid.focus();

                }
            });
        }
    };
})

.directive('disallowSpaces', function () {
    return {
        restrict: 'A',
        
        link: function ($scope, $element) {
            $element.bind('input', function () {
                $(this).val($(this).val().replace(/ /g, ''));
            });
        }
    };
})

.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });
                
                event.preventDefault();
            }
        });
    };
})


    .directive("validateAlphanumeric", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.alphanumeric = function (modelValue) {
                var validateAlphanumericpattern = /^[0-9a-zA-Z]+$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateAlphanumericpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateNumbers", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.numbers = function (modelValue) {
                var validateNumberspattern = /^[0-9]+$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateNumberspattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype1", function () {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype1 = function (modelValue) {
                var validateSctype1pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-_])*[a-zA-Z0-9]+$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    var result = validateSctype1pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype2", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype2 = function (modelValue) {
                var validateSctype2pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-.@\s])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype2pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype3", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype3 = function (modelValue) {
                var validateSctype3pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-_.@\s])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype3pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype4", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype4 = function (modelValue) {
                var validateSctype4pattern = /^([a-zA-Z0-9-$_./@])*[a-zA-Z0-9]+\.(sln)$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype4pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype5", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype5 = function (modelValue) {
                var validateSctype5pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-_.])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype5pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype6", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype6 = function (modelValue) {
                var validateSctype6pattern = /^[a-zA-Z0-9-/$_.@]*$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype6pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype7", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype7 = function (modelValue) {
                var validateSctype7pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-_.@])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype7pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype8", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype8 = function (modelValue) {
                var validateSctype8pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-\\\\_.@])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype8pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype9", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype9 = function (modelValue) {
                var validateSctype9pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9*.])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype9pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype10", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype10 = function (modelValue) {
                var validateSctype10pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-\\\\_.])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype10pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSctype11", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype11 = function (modelValue) {
                var validateSctype11pattern = /^[a-zA-Z0-9]+[a-zA-Z0-9-_]*\.(testsettings)$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype11pattern.test(value);
                }
                return result;

            };
        }
    };
})
.directive("validateSctype12", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.sctype12 = function (modelValue) {
                var validateSctype12pattern = /^[a-zA-Z0-9]+([a-zA-Z0-9-/_.@\s])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSctype12pattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateRuleset", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.ruleset = function (modelValue) {
                var validateRulesetpattern = /^(?:[a-zA-Z0-9]\:|\\)(\\[a-z_\-\s0-9\.]+)+\.(ruleset)$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateRulesetpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateFolder", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.folder = function (modelValue) {
                var validateFolderpattern = /^(\\\\[\w-.]+\\[^\\/:*?<>|]+)((?:\\[^\\/:*?<>|]+)*\\?)+[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    var result = validateFolderpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateUrl", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.url = function (modelValue) {
                var validateUrlpattern = /^(https?):\/\/+[a-zA-Z0-9]+([a-zA-Z0-9-_:\/\.])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateUrlpattern.test(value);
                }
                return result;

            };
        }
    };
})
.directive("validateUrlat", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.urlat = function (modelValue) {
                var validateUrlatpattern = /^(https?):\/\/+[a-zA-Z0-9]+([a-zA-Z0-9-@_:\/\.])*[a-zA-Z0-9]$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateUrlatpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateVirtualdirectorypath", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.virtualdirectorypath = function (modelValue) {
                var validateVirtualdirectorypathpattern = /^[a-zA-Z]\:\\.*|^(\\\\[\w-.]+\\[^\\/:*?<>|]+)((?:\\[^\\/:*?<>|]+)*\\?)$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    var result = validateVirtualdirectorypathpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateToolreportpath", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.toolreportpath = function (modelValue) {
                var validateToolreportpathpattern = /^[a-zA-Z]\:\\.*|^(\\\\[\w-.]+\\[^\\/:*?<>|]+)((?:\\[^\\/:*?<>|]+)*\\?)$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    var result = validateToolreportpathpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateSmtpserver", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.smtpserver = function (modelValue) {
                var validateSmtpserverpattern = /^\w+[\-a-zA-Z]{0,}\.\w+\.[a-zA-z]{1,3}$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateSmtpserverpattern.test(value);
                }
                return result;

            };
        }
    };
})
    .directive("validateThreshold", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.threshold = function (modelValue) {
                var validateThresholdpattern = /^(?:\b)([0-9]{1,2}|100|0)\b$/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateThresholdpattern.test(value);
                }
                return result;

            };
        }
    };
})

.directive("validateToolinstalledpath", function () {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attributes, ngModel) {
            ngModel.$validators.toolinstalledpath = function (modelValue) {
                var validateToolinstalledpathpattern = /^[a-zA-Z]\:\\.*/;
                var value = modelValue;
                if (!value || value.length == 0) {
                    result = true;
                } else {
                    result = validateToolinstalledpathpattern.test(value);
                }
                return result;

            };
        }
    };
})


.filter('activityFilter', function () {
    return function (activity, index) {
        return activityArrInfo[index];
    };
})

.filter('deploymentFilter', function () {
    return function (deploy, index) {
        return deploymentArrInfo[index];
    };

});

$(window, document, undefined).ready(function () {
    
    $('input').blur(function () {
        var $this = $(this);
        if ($this.val())
            $this.addClass('used');
        else
            $this.removeClass('used');
    });
    
    var $ripples = $('.ripples');
    
    $ripples.on('click.Ripples', function (e) {
        
        var $this = $(this);
        var $offset = $this.parent().offset();
        var $circle = $this.find('.ripplesCircle');
        
        var x = e.pageX - $offset.left;
        var y = e.pageY - $offset.top;
        
        $circle.css({
            top: y + 'px',
            left: x + 'px'
        });
        
        $this.addClass('is-active');

    });
    
    $ripples.on('animationend webkitAnimationEnd mozAnimationEnd oanimationend MSAnimationEnd', function (e) {
        $(this).removeClass('is-active');
    });

});
