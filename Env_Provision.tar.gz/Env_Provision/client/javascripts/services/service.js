﻿angular.module('CIService', [])
 .factory('CIFactory', ['$http', '$q', 'ClientConfig', function ($http, $q, ClientConfig) {
      
           
        //addition of pipelinetransaction
        function AddPipelineTransaction(buildDefinitionData) {
            var deferred = $q.defer();
            
            // change input json object to json object string        
            var PipelineTransaction = JSON.stringify(buildDefinitionData);
            
            //will call route.js     
            $http.post('/api/addPipelineTransaction', { PipelineTransaction: PipelineTransaction }).success(function (result) {
                deferred.resolve(result);
            })
             .error(function (err) {
                deferred.reject(err);
            });
            
            return deferred.promise;
        }
        function GetversionByToolName(container, ToolType) {
            var deferred = $q.defer();

            $http.get('/api/GetversionByToolName/' + ToolType + "/" + container).success(function (result) {
                debugger;
                deferred.resolve(result);
            })
                .error(function () {
                debugger;
                deferred.reject(error);
            });
            
            return deferred.promise;
        }

        
        function GetApplications() {
            var deferred = $q.defer();
            //will call route.js        
            $http.get('/api/GetApplications').success(function (result) {
                
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        function GetBuildServers() {
            var deferred = $q.defer();
            //  var buildServTool = JSON.stringify(selectedBuildServerTool);
            //will call route.js        
            $http.get('/api/getBuildServersConfig/').success(function (result) {
                
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        function GetDeployServers() {
            var deferred = $q.defer();
            //  var buildServTool = JSON.stringify(selectedBuildServerTool);
            //will call route.js        
            $http.get('/api/getDeployServersConfig/').success(function (result) {
                
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        function GetCDConfigNames() {
            var deferred = $q.defer();
            
            //will call route.js        
            $http.get('/api/getCDConfigNames/').success(function (result) {
                
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        function GetEnvProvApplications() {
            var deferred = $q.defer();
            
            //will call route.js        
            $http.get('/api/GetEnvProvApplications/').success(function (result) {
                
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        function GetAllTools() {
            var deferred = $q.defer();
            //var inputData = JSON.stringify(input);
            
            //will call route.js        
            $http.get('/api/getalltools').success(function (result) {
                
                if (typeof (result.DotNetUnitTestTools) != ClientConfig.UNDEFINED) {
                    DotNetUnitTestTools = result.DotNetUnitTestTools;
                }
                if (typeof (result.EPSourceControls) != ClientConfig.UNDEFINED) {
                    EPSourceControls = result.EPSourceControls;
                }
                if (typeof (result.EPBuildServers) != ClientConfig.UNDEFINED) {
                    EPBuildServers = result.EPBuildServers;
                }
                if (typeof (result.CIApplicationDeploy) != ClientConfig.UNDEFINED) {
                    CIApplicationDeploy = result.CIApplicationDeploy;
                }
                
                if (typeof (result.ConfigurationTool) != ClientConfig.UNDEFINED) {
                    ConfigurationTool = result.ConfigurationTool;
                }
                
                if (typeof (result.OperatingSystem) != ClientConfig.UNDEFINED) {
                    OperatingSystem = result.OperatingSystem;
                }
                
                if (typeof (result.Platform) != ClientConfig.UNDEFINED) {
                    Platform = result.Platform;
                }
                
                if (typeof (result.Artifactdeployed) != ClientConfig.UNDEFINED) {
                    Artifactdeployed = result.Artifactdeployed;
                }
                if (typeof (result.RespositoryTool) != ClientConfig.UNDEFINED) {
                    RespositoryTool = result.RespositoryTool;
                }
                if (typeof (result.CDPipelineTrigger) != ClientConfig.UNDEFINED) {
                    CDPipelineTrigger = result.CDPipelineTrigger;
                }
                if (typeof (result.JavaUnitTestTools) != ClientConfig.UNDEFINED) {
                    JavaUnitTestTools = result.JavaUnitTestTools;
                }
                if (typeof (result.DotNetCoverageTools) != ClientConfig.UNDEFINED) {
                    DotNetCoverageTools = result.DotNetCoverageTools;
                }
                if (typeof (result.JavaCoverageTools) != ClientConfig.UNDEFINED) {
                    JavaCoverageTools = result.JavaCoverageTools;
                }
                if (typeof (result.DotNetAnalysisTools) != ClientConfig.UNDEFINED) {
                    DotNetAnalysisTools = result.DotNetAnalysisTools;
                }
                if (typeof (result.JavaAnalysisTools) != ClientConfig.UNDEFINED) {
                    JavaAnalysisTools = result.JavaAnalysisTools;
                }
                if (typeof (result.DotNetSecAnalysisTools) != ClientConfig.UNDEFINED) {
                    DotNetSecAnalysisTools = result.DotNetSecAnalysisTools;
                }
                if (typeof (result.JavaSecAnalysisTools) != ClientConfig.UNDEFINED) {
                    JavaSecAnalysisTools = result.JavaSecAnalysisTools;
                }
                if (typeof (result.DotNetCodeMetricsTools) != ClientConfig.UNDEFINED) {
                    DotNetCodeMetricsTools = result.DotNetCodeMetricsTools;
                }
                if (typeof (result.JavaCodeMetricsTools) != ClientConfig.UNDEFINED) {
                    JavaCodeMetricsTools = result.JavaCodeMetricsTools;
                }
                if (typeof (result.DotNetPackagingFormats) != ClientConfig.UNDEFINED) {
                    DotNetPackagingFormat = result.DotNetPackagingFormats;
                }
                if (typeof (result.JavaPackagingFormats) != ClientConfig.UNDEFINED) {
                    JavaPackagingFormat = result.JavaPackagingFormats;
                }
                if (typeof (result.SPPackagingFormats) != ClientConfig.UNDEFINED) {
                    SAPPackagingFormat = result.SPPackagingFormats;
                }
                if (typeof (result.DotNetDeployPackageTools) != ClientConfig.UNDEFINED) {
                    DotNetDeployPackageTools = result.DotNetDeployPackageTools;
                }
                if (typeof (result.JavaDeployPackageTools) != ClientConfig.UNDEFINED) {
                    JavaDeployPackageTools = result.JavaDeployPackageTools;
                }
                if (typeof (result.RepotTypes) != ClientConfig.UNDEFINED) {
                    reportType = result.RepotTypes;
                }
                if (typeof (result.ActivitiesInfo) != ClientConfig.UNDEFINED) {
                    ActivitiesInfo = result.ActivitiesInfo;
                }
                if (typeof (result.ReportsInfo) != ClientConfig.UNDEFINED) {
                    ReportsInfo = result.ReportsInfo;
                }
                if (typeof (result.ResultsInfo) != ClientConfig.UNDEFINED) {
                    ResultsInfo = result.ResultsInfo;
                }
                
                
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        //login checking  
        function loginDetails(user) {
            var deferred = $q.defer();
            //will call route.js
            $http.post('/api/login', user).success(function (result) {
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            return deferred.promise;
        }
        
        function logout() {
            var deferred = $q.defer();
            //will call route.js
            $http.post("/api/logout").success(function (result) {
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            return deferred.promise;
        }
        
        function GetApplicationData(SelectedApplication, BuildDefinitionAction) {
            
            var deferred = $q.defer();
            BuildDefinitionEditMode = BuildDefinitionAction;
            //will call route.js    
            
            var ApplicationName = JSON.stringify(SelectedApplication);
            $http.get('/api/getApplicationData/' + ApplicationName).success(function (resultdata, status) {
                
                deferred.resolve(resultdata);
            })
             .error(function () {
                
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        function GetContainerStackData(SelectedContainerStack) {
            
            var deferred = $q.defer();
           
            //will call route.js    
            
            var ContainerStackName = JSON.stringify(SelectedContainerStack);

            $http.get('/api/GetContainerStackData/' + ContainerStackName).success(function (resultdata, status) {
                
                deferred.resolve(resultdata);
            })
             .error(function () {
                
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
        //get users by roles 
        function GetUserByRole(Role) {
            var deferred = $q.defer();
            var Role = JSON.stringify(Role);
            //will call route.js
            $http.get('/api/GetUserByRole/' + Role).success(function (resultdata, status) {
                
                deferred.resolve(resultdata);
            })
        .error(function () {
                deferred.reject(error);
            });
            return deferred.promise;
        }

        function LogData(loginfo) {
            var deferred = $q.defer();
            var logdetails = JSON.stringify(loginfo);
            //will call route.js        
            $http.get('/api/LogData/' + logdetails).success(function (result) {
                deferred.resolve(result);
            })
        .error(function () {
                deferred.reject(error);
            });
            
            return deferred.promise;
        }
        
          
        function InsertVMContainerMappingDetails(vmMappingData) {
            
            var deferred = $q.defer();
            
            // change input json object to json object string        
            var containerMapping = JSON.stringify(vmMappingData);
            
            //will call route.js     
            $http.post('/api/PutVMContainerMappingDetails', {
                containerMapping: containerMapping
            }).success(function (result) {
                deferred.resolve(result);
            })
                .error(function (err) {
                deferred.reject(err);
            });
            
            return deferred.promise;
        }
        
        function InsertToolDetails(toolsStackInfo) {
            
            var deferred = $q.defer();
            
            // change input json object to json object string        
            var toolsStackDetails = JSON.stringify(toolsStackInfo);
            
            //will call route.js     
            $http.post('/api/PutToolsStackDetails', {
                toolsStackDetails: toolsStackDetails
            }).success(function (result) {
                deferred.resolve(result);
            })
                .error(function (err) {
                deferred.reject(err);
            });
            
            return deferred.promise;
        }
     

        function CreateEnvProvisioning(envProvToolsDetails, envProvVMDetails, provToolDetails) {
            
            var deferred = $q.defer();
            
            // change input json object to json object string        
            var envProvToolsDetailsParam = JSON.stringify(envProvToolsDetails);
            var envProvVMDetailsParam = JSON.stringify(envProvVMDetails);
            var provToolDetailsParam = JSON.stringify(provToolDetails);
            
            //will call route.js     
            $http.post('/api/CreateEnvProvisioning', { envProvToolsDetails: envProvToolsDetailsParam , envProvVMDetails : envProvVMDetailsParam , provToolDetails : provToolDetailsParam }).success(function (result) {                
                deferred.resolve(result);
            })
                .error(function (err) {
                deferred.reject(err);
            });
            
            return deferred.promise;
        }
     

        return {
            GetAllTools: GetAllTools,
            loginDetails: loginDetails,
            logout: logout,
            GetApplications: GetApplications,
            GetApplicationData: GetApplicationData,
            GetContainerStackData: GetContainerStackData,
            GetBuildServers: GetBuildServers,
            GetDeployServers: GetDeployServers,
            GetCDConfigNames: GetCDConfigNames,
            GetUserByRole: GetUserByRole,
            GetEnvProvApplications: GetEnvProvApplications,
            LogData: LogData,
            InsertVMContainerMappingDetails: InsertVMContainerMappingDetails,
            InsertToolDetails: InsertToolDetails,
            CreateEnvProvisioning: CreateEnvProvisioning,
            GetversionByToolName: GetversionByToolName,
            AddPipelineTransaction: AddPipelineTransaction,  
        };
    }]);


