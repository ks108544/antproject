﻿//Inject controller , service and ngroute
angular.module('CIServiceApp', ['CIController', 'CIService', 'ngRoute', 'ngAnimate', 'ui.bootstrap', 'ngDialog'])
// Define routing logic
 .config(['$routeProvider', '$locationProvider','$httpProvider',function ($routeProvider, $locationProvider, $httpProvider) {
    $routeProvider.when('/', {
        templateUrl : 'views/home.html'
        })
        $routeProvider.when('/login', {
            templateUrl : '/views/login.html' ,
            controller: 'loginController'   
        })
        $routeProvider.when('/TFSServer', {
            templateUrl : '/views/TFSServer.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }  
        })
        $routeProvider.when('/JenkinsScm', {
            templateUrl : '/views/JenkinsScm.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }  
        })
        $routeProvider.when('/DeployServerDetails', {
            templateUrl : '/views/DeployServerDetails.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }  
        })
           $routeProvider.when('/DeployServerSetting', {
            templateUrl : '/views/DeployServerSetting.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }  
        })
        $routeProvider.when('/applicationConfig', {
            templateUrl : '/views/applicationConfig.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }
        })
        $routeProvider.when('/JenkinsConfig', {
            templateUrl : '/views/jenkinsAppConfig.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }  
        })
        $routeProvider.when('/TfsConfig', {
            templateUrl : '/views/tfsAppConfig.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }
        })  
        $routeProvider.when('/Dashboard', {
            templateUrl : '/views/Dashboard.html',
            controller: 'mainController',
            resolve: {
                logincheck: checkLoggedin
            }
        })       
   
        $routeProvider.when('/EnvProvToolsStack', {
            templateUrl : '/views/EnvProvToolsStack.html',
            controller: 'EnvProvisionController',
            resolve: {
                logincheck: checkLoggedin
            }
        }) 
        
        $routeProvider.when('/EnvProvVMMapping', {
            templateUrl : '/views/EnvironmentMapping.html',
            controller: 'EnvProvisionController',
            resolve: {
                logincheck: checkLoggedin
            }
        })


    $routeProvider.otherwise({
        redirectTo : '/'
    });
    
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });

    if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};
    }
    //disable IE ajax request caching
    $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
    // extra
    $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
    $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
 
}]);

var checkLoggedin = function ($q, $timeout, $http, $location) {
    var deferred = $q.defer();
    
    $http.get('/api/loggedin').success(function (user) {
        //If User is Authenticated
        if (user !== '0') {
            deferred.resolve();
        } 
        //If User is not Authenticated 
        else {
            deferred.reject();
            $location.path('/login');
        }
    })
     .error(function () {
        deferred.reject(error);
    });
    return deferred.promise;
}
