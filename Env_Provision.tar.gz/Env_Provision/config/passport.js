// load all the things we need 
var localStrategy = require('passport-local').Strategy;
var env = require('get-env')();

if (env === 'dev' || env === 'development' || env === '') {
    var User = require('../app/models/user.js');
    var constants = require('./serviceconstants.js');
    
} else if (env === 'prod' || env === 'production') {
    var User = require('../app/models/user.min.js');
    var constants = require('./serviceconstants.min.js');
}
// expose this function to our app using module.exports
module.exports = function (passport) {
    
    passport.serializeUser(function (user, done) {
        done(null, user);
    });
    
    passport.deserializeUser(function (user, done) {
        done(null, user);
    });
    
    passport.use('local-login', new localStrategy(
        function (username, password, done) {
            User.findOne({
                username: username.toLowerCase()
            }, function (err, user) {
                // if there are any errors, return the error before anything else
                if (err)      
                return done(err, false, err);
                
                // if no user is found or password is wrong, return the message
                if (!user || !user.validPassword(password))
                  return done(null, false, { message: constants.INVALID_LOGIN });             
                     
                // all is well, return successful user        
                return done(null, user);
            });
        }
    ));  
};
