﻿var path = require('path');

var env = require('get-env')();
var date = new Date();
//Imports from routedata.js

if (env === 'dev' || env === 'development' || env === '') {
    var routeData = require('./routedata.js');
    var constants = require('../../config/serviceconstants.js');
    
    
} else if (env === 'prod' || env === 'production') {
    var routeData = require('./routedata.min.js');
    var constants = require('../../config/serviceconstants.min.js');
}




module.exports = function (app,passport) {
    
    //Get tools
    app.get('/api/getalltools', routeData.GetAllTools);
    app.get('/api/GetApplications', routeData.GetApplications);  
    app.get('/api/GetTFSBuildDefinitions', routeData.GetTFSBuildDefinitions);
    app.get('/api/GetMetadataTemplate', routeData.GetMetadataTemplate);
    app.post('/api/EditBuildDefinitionMongo/', routeData.EditBuildDefinitionMongo);    //Create build definition
    //app.post('', routeData.CreateBuildDefinition);

    app.get('/api/getBuildDefinitionDetails/:buildModelParam/:buildServTool', routeData.GetBuildDefinitionDetails);
    app.get('/api/getBuildTemplateData/:buildTemplate/:buildServTool', routeData.GetBuildTemplateData);
    


    app.get('/api/getBuildDefinitionDetailsCM/:buildModelParam', routeData.GetBuildDefinitionDetailsCM);
    
    app.get('/api/getApplicationData/:ApplicationName', routeData.GetApplicationData);

    app.get('/api/getCDConfigDataFromCDConfigName/:CDApplicationName', routeData.GetCDConfigDataFromCDConfigName);
    
    app.get('/api/getCDConfigDataFromCIName/:CIApplicationName', routeData.GetCDConfigDataFromCIName);
    
    app.get('/api/getCDServerDetailsFromName/:DeployServerConfigName', routeData.GetCDServerDetailsFromName);
    
    app.get('/api/getCDServerFromCDConfigName/:CDApplicationName', routeData.GetCDServerFromCDConfigName);

    app.get('/api/GetApplicationsByBuildServer/:buildServerConfigName', routeData.GetApplicationsByBuildServer);

    app.post('/api/DeleteBuildServerConfigData/:buildServerConfigName/:buildServerTool', routeData.DeleteBuildServerConfigData);

    app.post('/api/DeleteDeployServer/:DeployServerName', routeData.DeleteDeployServer);

    app.get('/api/getBuildServerConfigData/:buildServerConfigName', routeData.GetBuildServerConfigData);
    
    app.get('/api/getDeployServerConfigData/:deployServerConfigName', routeData.GetDeployServerConfigData);

    app.post('/api/createbuilddefinition', routeData.CreateBuildDefinition);
    
    app.post('/api/editBuildDefinition', routeData.EditBuildDefinition);
    
    app.post('/api/TriggerBuild', routeData.TriggerBuild);

    app.post('/api/CheckBuildDefinition', routeData.CheckBuildDefinition);
    
    app.post('/api/DeleteBuildDefinition', routeData.DeleteBuildDefinition);
    
    app.post('/api/DeleteCDApplication', routeData.DeleteCDApplication);
    
    app.post('/api/SaveCMConfiguration', routeData.SaveCMConfiguration);
    
    app.post('/api/SaveCMConfigurationMongo', routeData.SaveCMConfigurationMongo);
    
    app.post('/api/SaveBuildDefinition', routeData.SaveBuildDefinition);

    app.post('/api/addDeployServer', routeData.AddDeployServer);

    app.post('/api/addDeployServerConfig', routeData.AddDeployServerConfig);
    
    app.post('/api/saveDeployServerConfig', routeData.SaveDeployServerConfig);

    app.post('/api/addbuildserver', routeData.AddBuildServer);
    
    app.post('/api/editBuildServerConfig', routeData.EditBuildServerConfig);

    app.get('/api/getBuildServersConfig', routeData.GetBuildServers);

    app.get('/api/getDeployServersConfig', routeData.GetDeployServers);

    app.get('/api/getCDConfigNames', routeData.GetCDConfigs);

    app.post('/api/SaveBuildDefinitionTemplate', routeData.SaveBuildDefinitionTemplate);
    
    app.get('/api/GetInReleaseData/:buildNumber/', routeData.GetInReleaseData);
    //Get Build Details
    app.get('/api/getBuilDefinitions', routeData.GetBuildDefinitions);
    //app.get('/api/getBuilDefinitions/:buildModelParam', routeData.GetBuildDefinitions);

    //app.get('/api/getStageStatus/:buildModelParam/:pipeLineModelParam', routeData.GetStageStatus);
    //app.get('/api/getBuildActivities/:buildModelParam/:pipeLineModelParam', routeData.GetBuildActivities);
    //app.get('/api/getStageActivities/:buildModelParam/:pipeLineModelParam', routeData.GetStageActivities);
    //app.get('/api/getBuildReports/:stage/:buildModelParam/:pipeLineModelParam', routeData.GetBuildReports);
    //app.get('/api/GetActivityDetails/:stage/:buildModelParam/:pipeLineModelParam', routeData.GetActivityDetails);
    //app.get('/api/getRiskAnalysisDetails/:stage/:buildModelParam/:pipeLineModelParam', routeData.GetRiskAnalysisDetails);
    //app.get('/api/getBuildTestResults/:buildModelParam/:pipeLineModelParam', routeData.GetBuildTestResults);
    //app.get('/api/getCMConfigurationDetails/:ApplicationName', routeData.GetCMConfigurationDetails);
    //app.get('/api/getInReleaseActivities/:buildModelParam', routeData.GetInReleaseActivities);
    //app.get('/api/getInReleasePackages/:buildModelParam', routeData.GetInReleasePackages);
    //app.get('/api/getStageStatusCM/:buildModelParam', routeData.GetStageStatusCM);
    //app.get('/api/getInReleaseDeployInfo/:buildModelParam', routeData.GetInReleaseDeployInfo);
    //app.get('/api/GetUdeployApplications/:buildModelParam', routeData.GetUdeployApplications);
    //app.get('/api/GetUdeployEnvironments/:buildModelParam', routeData.GetUdeployEnvironments);
    //app.get('/api/GetUdeployApplProcesses/:buildModelParam', routeData.GetUdeployApplProcesses);
    //app.get('/api/GetUdeployResources/:buildModelParam', routeData.GetUdeployResources);
    //app.get('/api/GetUdeployComponents/:buildModelParam', routeData.GetUdeployComponents);
    //app.get('/api/GetUdeployComponentProcesses/:buildModelParam', routeData.GetUdeployComponentProcesses);
    //app.get('/api/GetComputerNameByAgent/:agentId/:buildModelParam', routeData.GetComputerNameByAgent);

    app.get('/api/getBuildActivities', routeData.GetBuildActivities);
    
    app.get('/api/getStageActivities', routeData.GetStageActivities);
    
    app.get('/api/getStageStatus', routeData.GetStageStatus);
    
    
    app.get('/api/getBuildReports', routeData.GetBuildReports);
    
    app.get('/api/GetActivityDetails', routeData.GetActivityDetails);
    
    app.get('/api/getRiskAnalysisDetails', routeData.GetRiskAnalysisDetails);
    
    app.get('/api/getBuildTestResults', routeData.GetBuildTestResults);
    
    //Get CMDetails
    app.get('/api/getCMDetails', routeData.GetCMDetails);
    
    app.get('/api/getCMConfigurationDetails', routeData.GetCMConfigurationDetails);

    app.get('/api/getCMConfigurations', routeData.GetCMConfigurations);
    
    app.post('/api/ModifyCMConfiguration', routeData.ModifyCMConfiguration);
    
    app.post('/api/DeleteCMConfiguration', routeData.DeleteCMConfiguration);
    
    app.post('/api/DeleteCMConfigurationDetailsMongo', routeData.DeleteCMConfigurationDetailsMongo);
    
    app.post('/api/editCMConfigurationMongo/', routeData.EditCMConfigurationMongo);

    app.get('/api/getInReleaseActivities', routeData.GetInReleaseActivities);
    
    app.get('/api/getInReleasePackages', routeData.GetInReleasePackages);
    
    app.get('/api/getStageStatusCM', routeData.GetStageStatusCM);
    
    app.get('/api/getInReleaseDeployInfo', routeData.GetInReleaseDeployInfo);
    
     
    //Delete user data
    app.post('/api/DeleteAcitivity', routeData.DeleteAcitivity);
    
    //Jenkins Build
    app.post('/api/createbuilddefinitionjenkins', routeData.CreateBuildDefinition);
    
    app.post('/api/savebuilddefinitionjenkins/', routeData.SaveBuildDefinition);
    
    //app.post('/api/DeleteBuildDefinitionJenkins', routeData.DeleteBuildDefinitionJenkins);
    
    app.post('/api/DeleteBuildConfigEntireNode', routeData.DeleteBuildConfigEntireNode);
    
    app.post('/api/DeleteBuildDefinitionMongo', routeData.DeleteBuildDefinitionMongo);
    
    app.post('/api/DeleteBuildDefinitionMongoCD', routeData.DeleteBuildDefinitionMongoCD);
    
    app.post('/api/CMConfigurationApi', routeData.CMConfigurationApi);
    
    app.get('/api/GetUdeployApplications', routeData.GetUdeployApplications);
    
    app.get('/api/GetUdeployEnvironments', routeData.GetUdeployEnvironments);
    
    app.get('/api/GetUdeployApplProcesses', routeData.GetUdeployApplProcesses);
    
    app.get('/api/GetUdeployResources', routeData.GetUdeployResources);
    
    app.get('/api/GetUdeployComponents', routeData.GetUdeployComponents);
    app.get('/api/getinitialdata', routeData.GetInitialData);
    app.get('/api/GetUdeployComponentProcesses', routeData.GetUdeployComponentProcesses);

    app.post('/api/CreateUDeployConfigXML', routeData.CreateUDeployConfigXML);

    app.get('/api/GetComputerNameByAgent', routeData.GetComputerNameByAgent);
    app.get('/api/GetCICDJobType/', routeData.GetCICDJobType);
    app.get('/api/LogData/', routeData.LogData);

    app.post('/api/BuildDockerImage', routeData.BuildDockerImage);
    
      

    //app.post('/api/DownloadFiles/:curl/:curl1', routeData.DownloadFiles);

    //app.post('/api/UploadFiles/', routeData.UploadFiles);

    app.post('/api/BuildContainerUsingKubernetes', routeData.BuildContainerUsingKubernetes);
   
    //login
    app.post('/api/login', function (req, res, next) {        
        passport.authenticate('local-login', function (err, user, info) {
            if (err || !user) {
                return res.json({ message: info.message });
            }            
            req.logIn(user, function (err) {
                if (err) {
                    return next(err);
                }                
                if (constants.USER_LOGGING) {
                    console.log('User ' + user.username + ' logon ' + new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString());            
                }               
                res.json(user);
            });
        })(req, res, next);
    });
    
    //is user logged in
    app.get("/api/loggedin", function (req, res) {        
        if ((constants.USER_LOGGING) && (!req.isAuthenticated())) {                   
            console.log('Loggedin user session expired ' + new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString());
        }     
        res.send(req.isAuthenticated() ? req.user : '0');
    });    
    
    //logout
    app.post("/api/logout", function (req, res) {
        var username = "";
        if (req.user != null) {
            username = req.user.username;
        }
        req.logOut();
        if (constants.USER_LOGGING) {
            console.log('User ' + username + ' logout ' + new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString());
        }
        res.sendStatus(200);
    });

    //to route to angular index page
    app.get('*', function (req, res) {
        __dirname = path.resolve();
        if (env === 'dev' || env === 'development' || env === '') {
            res.sendFile(path.join(__dirname, 'client', 'index.html'));  
        } else if (env === 'prod' || env === 'production') {
            res.sendFile(path.join(__dirname,'dist', 'client', 'index.html'));
        }
        
    });
   
}

