﻿
var env = require('get-env')();
var path = require('path');
var promise = require('bluebird');
var mongoose = require('mongoose');
var querystring = require('querystring');
var SourceFileName = "routedata.js";

if (env === 'dev' || env === 'development' || env === '') {
    var customlogger = require("../utils/logger.js");
    promise.promisifyAll(mongoose);
    var toolslookupModel = require('../models/toolslookup.js');
    var applookupModel = require('../models/applookup.js');
    var builddefnModel = require('../models/builddefinition.js');
    var cmconfigModel = require('../models/cmconfig.js');
    var buildDefTemplateModel = require('../models/builddefinitiontemplate.js');
    
    //login definition 
    var loginModel = require('../models/logindefinition.js');
    
    //adding server
    var buildServerModel = require('../models/buildServer.js');
    
    //adding deploy server
    var deployServerModel = require('../models/DeployServer.js');
    
    //adding deploy config server
    var deployServerConfigModel = require('../models/DeployServerConfig.js');
    
    
    //Imports from factory.js
    var factory = require('../core/factory.js');
    var saveuserModel = require('../models/cmsave.js');
    var constants = require('../../config/serviceconstants.js');
    var createjobconfigxml = require('../core/jen_jobconfig_xml.js');
    var ActivitiesModel = require('../models/Activities.js');
    var ReportsModel = require('../models/Reports.js');
    var ResultsModel = require('../models/Results.js');

    var containerizationFactory = require('../core/containerization_factory.js');
    var docker = require('../core/docker.js');

} else if (env === 'prod' || env === 'production') {
    var customlogger = require("../utils/logger.min.js");
    promise.promisifyAll(mongoose);
    var toolslookupModel = require('../models/toolslookup.min.js');
    var applookupModel = require('../models/applookup.min.js');
    var builddefnModel = require('../models/builddefinition.min.js');
    var cmconfigModel = require('../models/cmconfig.min.js');
    var buildDefTemplateModel = require('../models/builddefinitiontemplate.min.js');
    
    //adding deploy server
    var deployServerModel = require('../models/DeployServer.min.js');
    var deployServerConfigModel = require('../models/DeployServerConfig.min.js');
    
    //login definition	
    var loginModel = require('../models/logindefinition.min.js');
    //adding server
    var buildServerModel = require('../models/buildServer.min.js');
    //Imports from factory.js
    var factory = require('../core/factory.min.js');
    var saveuserModel = require('../models/cmsave.min.js')
    var constants = require('../../config/serviceconstants.min.js');
    var createjobconfigxml = require('../core/jen_jobconfig_xml.min.js');
    var ActivitiesModel = require('../models/Activities.min.js');
    var ReportsModel = require('../models/Reports.min.js');
    var ResultsModel = require('../models/Results.min.js');
  
}

module.exports = {
    //Get all tools
    GetAllTools : function (req, res) {
        var method = "GetAllTools";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName};
            customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            CIApplicationDeploy: toolslookupModel.find({ toolgroup: 'CIApplicationNameDeploy' }).execAsync(),
            CDPipelineTrigger: toolslookupModel.find({ toolgroup: 'CDPipelineTrigger' }).execAsync(),
            RespositoryTool: toolslookupModel.find({ toolgroup: 'RespositoryTool' }).execAsync(),
            ConfigurationTool: toolslookupModel.find({ toolgroup: 'ConfigurationTool' }).execAsync(),
            OperatingSystem: toolslookupModel.find({ toolgroup: 'OperatingSystem' }).execAsync(),
            Platform: toolslookupModel.find({ toolgroup: 'Platform' }).execAsync(),
            Artifactdeployed: toolslookupModel.find({ toolgroup: 'Artifactdeployed' }).execAsync(),
            buildServerTools: toolslookupModel.find({ toolgroup: 'ContIntegration' }).execAsync(),
            deployServerTools: toolslookupModel.find({ toolgroup: 'CD' }).execAsync(),
            sourceControlTools: toolslookupModel.find({ toolgroup: 'SourceControl' }).execAsync(),
            binaryRepositoryTools: toolslookupModel.find({ toolgroup: 'Repository' }).execAsync(),
            uiTierAppTypes: applookupModel.find({ apptier: 'PresentationTier' }).execAsync(),
            businessTierAppTypes: applookupModel.find({ apptier: 'BusinessTier' }).execAsync(),
            DotNetUnitTestTools: toolslookupModel.find({ toolgroup: 'UnitTestDotNet' }).execAsync(),
            JavaUnitTestTools: toolslookupModel.find({ toolgroup: 'UnitTestJava' }).execAsync(),
            DotNetCoverageTools: toolslookupModel.find({ toolgroup: 'CoverageDotNet' }).execAsync(),
            JavaCoverageTools: toolslookupModel.find({ toolgroup: 'CoverageJava' }).execAsync(),
            DotNetAnalysisTools: toolslookupModel.find({ toolgroup: 'AnalysisDotNet' }).execAsync(),
            JavaAnalysisTools: toolslookupModel.find({ toolgroup: 'AnalysisJava' }).execAsync(),
            DotNetSecAnalysisTools: toolslookupModel.find({ toolgroup: 'SecAnalysisDotNet' }).execAsync(),
            JavaSecAnalysisTools: toolslookupModel.find({ toolgroup: 'SecAnalysisJava' }).execAsync(),
            DotNetCodeMetricsTools: toolslookupModel.find({ toolgroup: 'CodeMetricsDotNet' }).execAsync(),
            JavaCodeMetricsTools: toolslookupModel.find({ toolgroup: 'CodeMetricsJava' }).execAsync(),
            dataTierAppTypes: applookupModel.find({ apptier: 'DataTier' }).execAsync(),
            CodeCoverageInputs: toolslookupModel.find({ toolgroup: 'CodeCoverageInput' }).execAsync(),
            MetricInputs: toolslookupModel.find({ toolgroup: 'MetricInput' }).execAsync(),
            BuildConfigurations: toolslookupModel.find({ toolgroup: 'BuildConfigurations' }).execAsync(),
            BuildPlatforms: toolslookupModel.find({ toolgroup: 'BuildPlatform' }).execAsync(),
            DotNetPackagingFormats: toolslookupModel.find({ toolgroup: 'DotNetPackagingFormat' }).execAsync(),
            JavaPackagingFormats: toolslookupModel.find({ toolgroup: 'JavaPackagingFormat' }).execAsync(),
            SPPackagingFormats: toolslookupModel.find({ toolgroup: 'SPPackagingFormat' }).execAsync(),
            DotNetDeployPackageTools: toolslookupModel.find({ toolgroup: 'DeployPackageDotNet' }).execAsync(),
            JavaDeployPackageTools: toolslookupModel.find({ toolgroup: 'DeployPackageJava' }).execAsync(),
            RepotTypes: toolslookupModel.find({ toolgroup: 'ReportType' }).execAsync(),            
            buildDefinitionDetails: builddefnModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, BuildServerTemplate: 1, _id: 0 }).execAsync(),
            deployConfigDetails : deployServerConfigModel.find({ CDApplicationName: { $ne: ' ' } }, { CDApplicationName: 1, DeployServerConfigname: 1, "DeployStages.SelectCIApplication": 1 , _id: 0 }).execAsync(),
            CMbuildDefinitionDetails: cmconfigModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, _id: 0 }).execAsync(),
            buildTFSDetails: builddefnModel.findOne({ BuildServerTool: 'TFS' }, { ProjectCollectionName: 1, ProjectName: 1, BuildServerUserID: 1, BuildServerPassword: 1, BuildServerDomain: 1, BuildServerTool: 1, _id: 0 }).execAsync(),
            buildJenkinsDetails: buildServerModel.findOne({ BuildServerTool: 'Jenkins' }, { BuildServerName: 1, BuildServerPort: 1, BuildServerUserID: 1, BuildServerPassword: 1, BuildServerTool: 1, InstalledPath: 1, ProjectFolderMiddle: 1, ApplicationName: 1, ProjectFolderUI: 1, _id: 0 }).execAsync(),
            BuildDefinitionTemplates: buildDefTemplateModel.find({ TemplateName: { $ne: ' ' } }, { TemplateName: 1, _id: 0 }).execAsync(),
            ActivitiesInfo: ActivitiesModel.find().execAsync(),
            ReportsInfo: ReportsModel.find().execAsync(),                        
            ResultsInfo: ResultsModel.find().execAsync()
        })
            .then(function (results) {
            
            //customlogger.info(constants.GETALLTOOLS_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
           var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName};
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETALLTOOLS_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    }, 
    
    GetApplications: function (req, res) {
        var method = "GetApplications";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            ApplicationNames: builddefnModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, _id: 0 }).execAsync(),
            ApplicationType: builddefnModel.find({ UITierAppType: { $ne: ' ' } }, { UITierAppType: 1, _id: 0 }).execAsync()

        })
         .then(function (results) {
            
           //customlogger.info(constants.GETAPP_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETALLTOOLS_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    GetCDConfigs: function (req, res) {
        var method = "GetCDConfigs";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            
            CDConfigNames: deployServerConfigModel.find({ CDApplicationName: { $ne: ' ' } }, { CDApplicationName: 1, _id: 0 }).execAsync(),
 
        })
         .then(function (results) {
            
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
           var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    
    GetDeployServers: function (req, res) {
        var method = "GetDeployServers";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            
            DeployServerConfigNames: deployServerModel.find({ DeployServerConfigName: { $ne: ' ' } }, { DeployServerConfigName: 1, BuildServerName: 1, BuildServerPort: 1, BuildServerUserID: 1, BuildServerPassword: 1, _id: 0 }).execAsync()
           
        })
         .then(function (results) {
            
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetBuildServers: function (req, res) {
        var method = "GetBuildServers";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            BuildServerConfigNames: buildServerModel.find({ BuildServerConfigName: { $ne: ' ' } }, { BuildServerConfigName: 1, BuildServerName: 1,BuildServerPort: 1, BuildServerTool: 1, BuildServerUserID: 1,BuildServerPassword: 1,InstalledPath:1, _id: 0 }).execAsync(),
            SourceControlTools: buildServerModel.find({ SourceControlTool: { $ne: ' ' } }, { SourceControlTool: 1, _id: 0 }).execAsync()
         
        })
         .then(function (results) {
            
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetApplicationData: function (req, res) {
        var method = "GetApplicationData";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var SelectedApplication = JSON.parse(req.params.ApplicationName);
        promise.props({
            ApplicationData: builddefnModel.find({ ApplicationName: SelectedApplication }).execAsync()
        })
         .then(function (results) {
            
           //customlogger.info(constants.GETAPPDATA_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetCDConfigDataFromCDConfigName: function (req, res) {
        var method = "GetCDConfigDataFromCDConfigName";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var cdConfigName = JSON.parse(req.params.CDApplicationName);
        promise.props({
            DeployServerConfigname: deployServerConfigModel.find({ CDApplicationName: cdConfigName }).execAsync(),
            cdPipelineItemsDetails : deployServerConfigModel.find({ CDApplicationName: cdConfigName }, { BuildPipeline: 1, _id: 0 }).execAsync()
        })
         .then(function (results) {
            
            //customlogger.info(constants.GETAPPDATA_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetCDConfigDataFromCIName: function (req, res) {
        var method = "GetCDConfigDataFromCIName";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var ciConfigName = JSON.parse(req.params.CIApplicationName);
        promise.props({
            DeployServerConfigname: deployServerConfigModel.find({ "DeployStages.SelectCIApplication": ciConfigName }).execAsync()
        })
         .then(function (results) {
            
            //customlogger.info(constants.GETAPPDATA_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
          .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
 

    GetCDServerDetailsFromName: function (req, res) {
        var method = "GetCDServerDetailsFromName";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
    var cdServerName = JSON.parse(req.params.DeployServerConfigName);
    promise.props({
         DeployServer : deployServerModel.find({ DeployServerConfigName: cdServerName }).execAsync()
    })
         .then(function (results) {
        
            //customlogger.info(constants.GETAPPDATA_DATA_RETRIEVE_SUCCESS_MSG);
        res.send(results);
    })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
},

    GetCDServerFromCDConfigName: function (req, res) {
        var method = "GetCDServerFromCDConfigName";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var cdServerName = JSON.parse(req.params.CDApplicationName);
        promise.props({
            //DeployServerConfigName: deployServerConfigModel.find({ DeployServerConfigName: cdServerName }).execAsync()
            DeployServerConfigname: deployServerConfigModel.find({ DeployServerConfigname: cdServerName }).execAsync()
        })
         .then(function (results) {
            
            //customlogger.info(constants.GETAPPDATA_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
          .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    

    GetApplicationsByBuildServer: function (req, res) {
        var method = "GetApplicationsByBuildServer";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var SelectedBuildServerConfigName = JSON.parse(req.params.buildServerConfigName);
        promise.props({
            ApplicationConfigurations: builddefnModel.find({ BuildServerTemplate: SelectedBuildServerConfigName }).execAsync()
        })
         .then(function (results) {
            
           //customlogger.info(constants.GETAPPDATA_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetBuildServerConfigData: function (req, res) {
        var method = "GetBuildServerConfigData";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildServerConfigName = JSON.parse(req.params.buildServerConfigName);
        promise.props({
            BuildServerConfigData: buildServerModel.find({ BuildServerConfigName: buildServerConfigName }).execAsync()
        })
         .then(function (results) {
            
           //customlogger.info(constants.GETBUILDSERVERCONFIG_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetDeployServerConfigData: function (req, res) {
        var method = "GetDeployServerConfigData";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }        
        var deployServerConfigName = req.params.deployServerConfigName;
        //var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        //var deployServerConfigName = JSON.parse(eval(buildModelParam));
              
        promise.props({
            DeployServerConfigData: deployServerModel.find({ DeployServerConfigName: deployServerConfigName }).execAsync()  
        })
         .then(function (results) {
            
           //customlogger.info(constants.GETDEPLOYSERVERCONFIG_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetBuildDefinitionDetails : function (req, res) {
        var method = "GetBuildDefinitionDetails";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildDefName = req.params.buildModelParam;
        var buildServToolName = req.params.buildServTool;
        promise.props({
            buildDefinitionDetails: builddefnModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, _id: 0 }).execAsync(),
            buildItemDetails: builddefnModel.find({ ApplicationName: buildDefName }, { ItemsToBuildUI: 1, ItemsToBuildMiddle: 1, EnableUnitTestUI: 1, EnableUnitTestMiddle: 1, EnableDeployPackageUI: 1, EnableDeployPackageMT: 1, PackageServerNameMT: 1, PackageServerNameUI: 1, BuildServerTool: 1, ProjectCollectionName: 1, ApplicationName: 1, BuildServerDomain: 1, BuildServerUserID: 1, BuildServerPassword: 1, ProjectName: 1, CoverageInputUI: 1, MetricInputUI: 1, ProjectFolderMiddle: 1, ProjectFolderUI: 1, UITierAppType: 1, BusinessTierAppType: 1, CoverageInputMiddle: 1, MetricInputMiddle: 1, _id: 0 }).execAsync(),
            pipelineItemsDetails: builddefnModel.find({ ApplicationName: buildDefName}, {ServiceType: 1, BuildPipeline: 1,_id: 0}).execAsync()
        })
            .then(function (results) {
            
            //customlogger.info(constants.GETALLTOOLS_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },    
    
    GetBuildTemplateData : function (req, res) {
        var method = "GetBuildTemplateData";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildTemplate = JSON.parse(req.params.buildTemplate);
        var buildServToolName = JSON.parse(req.params.buildServTool);
        promise.props({
            buildDefTemplateDetails: buildDefTemplateModel.find({ BuildServerTool: buildServToolName, TemplateName: buildTemplate }).execAsync()
        })
            .then(function (results) {
            
            //console.log(constants.GETBUILDTEMPLATE_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },    
    //login details
    loginDetails: function (req, res) {
        var method = "loginDetails";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var UserName = decodeURIComponent(req.params.loginUserName);
        var UserPassword = decodeURIComponent(req.params.loginPassword);
        
        promise.props({
            loginDetails: loginModel.find({ UserName: UserName, Password: UserPassword }, { UserName: 1, Password: 1, _id: 0 }).execAsync()
        })
            .then(function (results) {
            
            
            if (results.loginDetails.length > 0) {
                
                res.send('true');
            } else {
                
                res.send('false');
            }
            
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method , SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },    
    
    GetBuildDefinitionDetailsCM : function (req, res) {
        var method = "GetBuildDefinitionDetailsCM";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildDefName = req.params.buildModelParam;
        promise.props({
            CMbuildDefinitionDetails: cmconfigModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, _id: 0 }).execAsync()
            //buildItemDetails: builddefnModel.find({ ApplicationName: buildDefName }, { ItemsToBuildUI: 1, ItemsToBuildMiddle: 1, EnableUnitTestUI: 1, EnableUnitTestMiddle : 1, EnableDeployPackageUI: 1, EnableDeployPackageMT: 1, PackageServerNameMT: 1, PackageServerNameUI: 1, BuildServerTool: 1, ProjectCollectionName: 1, ApplicationName: 1, BuildServerDomain: 1, BuildServerUserID: 1, BuildServerPassword: 1, ProjectName: 1, _id: 0 }).execAsync()
        })
            .then(function (results) {
            
           //customlogger.info(constants.GETALLTOOLS_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    //Create build definition
    CreateBuildDefinition : function (req, res) {
        var method = "CreateBuildDefinition";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.CreateBuildDefinition(buildModel,function (error, resultdata) {
            
            if (error != null) {
                   var loginfo = { message: error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                    customlogger.error({ loginfo: loginfo });
                    res.send(error);
                }
           
            else {
                res.send(resultdata);
            }
           
        });
    }, 
    
    //Edit build definition
    EditBuildDefinition : function (req, res) {
        var method = "EditBuildDefinition";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.EditBuildDefinition(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    //Trigger build 
    TriggerBuild : function (req, res) {
        var method = "TriggerBuild";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = "Jenkins";
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.TriggerBuild(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    CheckBuildDefinition: function (req, res) {
        var method = "CheckBuildDefinition";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method , SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool;
        if (buildModel.BuildServerTool != undefined) {
            buildServerTool = buildModel.BuildServerTool;
            }
            else {
            buildServerTool = 'Jenkins';
                }

        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.CheckBuildDefinition(buildModel, function (error, resultdata) {
            
            if (error != null && error != "") {
                
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
                console.log("error " + error);
            }
            else {
                if (resultdata == "true") {
                    res.send(true);
                }
                else {
                    res.send(false);
                }
            }

        });
    },
    
        
    
    DeleteBuildDefinition : function (req, res) {
        var method = "DeleteBuildDefinition";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.DeleteBuildDefinition(buildModel, function (error, resultdata) {
            
            if (error != null && error != "") {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);

            }
            else {
                if (resultdata == "" || resultdata == undefined || resultdata == true) {
                    res.send(true);
                }
            }
           
        });
    },
    
    DeleteCDApplication : function (req, res) {
        var method = "DeleteCDApplication";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildModelParam;
        var serverInfo = JSON.parse(req.body.server);
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = 'Jenkins';
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.DeleteCDApplication(buildModel, serverInfo, function (error, resultdata) {
        
            if (error != null && error != "") {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                if (resultdata == "" || resultdata == undefined || resultdata == true) {
                    res.send(true);
                }
            }
           
        });
    },
           

    DeleteBuildConfigEntireNode : function (req, res) {
        var method = "DeleteBuildConfigEntireNode";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.DeleteBuildConfigEntireNode(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null && error != "") {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "DeleteBuildConfigEntireNode", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                if (resultdata == "" || resultdata == undefined || resultdata == true) {
                    res.send(true);
                }
            }
           
        });
           

    },
    
    DeleteBuildDefinitionMongo: function (req, res) {
        var method = "DeleteBuildDefinitionMongo";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        
        builddefnModel.remove({
            "ApplicationName" : buildModel.ApplicationName
        }).exec();
        
        res.send(true);
    },
    DeleteBuildDefinitionMongoCD: function (req, res) {
        var method = "DeleteBuildDefinitionMongoCD";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        
        deployServerConfigModel.remove({
            "CDApplicationName" : buildModel.CDApplicationName
        }).exec();
        
        res.send(true);
    },
    
    //Save CM Configuration
    SaveCMConfiguration : function (req, res) {
        var method = "SaveCMConfiguration";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildFactory = factory.prototype.GetBuildToolObj(buildModel.BuildServerToolCM.toolname);
        buildFactory.SaveCMConfiguration(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "SaveCMConfiguration", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
                //console.log(constants.SAVECM_CONFIG_ERROR_MSG);
            }
            else {
                res.send(resultdata);
            }
           
        });
    }, 
    
    SaveCMConfigurationMongo: function (req, res) {
        var method = "SaveCMConfigurationMongo";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        if (buildModel.BuildServerTool.toolname == constants.JENKINS) {
            var buildurl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
            var objJenkinsConfigXml = new createjobconfigxml;
            
            // Generate config xml 
            objJenkinsConfigXml.Generate_Build_Config_XML(buildurl, buildModel);
        }
        var CMConfigModel;
        
        if (buildModel.MonitorAppTier == true && buildModel.MonitorMiddleTier == true) {
            
            
            CMConfigModel = new cmconfigModel({
                
                BuildActivityListUI : buildModel.BuildActivityListUI,
                BuildReportListUI : buildModel.BuildReportListUI,
                BuildRiskListUI : buildModel.BuildRiskListUI,
                BuildItemListUI : buildModel.BuildItemListUI,
                UnitTestActivityListUI : buildModel.UnitTestActivityListUI,
                UnitTestReportListUI : buildModel.UnitTestReportListUI,
                UnitTestResultListUI : buildModel.UnitTestResultListUI,
                DeployUI : buildModel.DeployComponent,
                DeployActivityListUI : buildModel.DeployActivityListUI,  
                DeployPackageListUI: buildModel.DeployPackageListUI,
                DeployApprovalListUI : buildModel.DeployApprovalListUI,
                DeployInReleaseListUI : buildModel.DeployInReleaseList,  
                DeployMid : buildModel.DeployMid,
                DeployActivityListMiddle : buildModel.DeployActivityListMiddle,  
                DeployPackageListMiddle: buildModel.DeployPackageListMiddle,
                DeployApprovalListMiddle : buildModel.DeployApprovalListMiddle,
                DeployInReleaseListMiddle : buildModel.DeployInReleaseListMiddle, 
                BuildActivityListMiddle : buildModel.BuildActivityListMiddle,
                BuildReportListMiddle : buildModel.BuildReportListMiddle,
                BuildRiskListMiddle : buildModel.BuildRiskListMiddle,
                BuildItemListMiddle : buildModel.BuildItemListMiddle,
                UnitTestActivityListMiddle : buildModel.UnitTestActivityListMiddle,
                UnitTestReportListMiddle : buildModel.UnitTestReportListMiddle,
                UnitTestResultListMiddle : buildModel.UnitTestResultListMiddle,
                
                BuildReportPathMiddle : buildModel.BuildReportPathMiddle,
                BuildReportPathUI : buildModel.BuildReportPathUI,
                ProjectCollectionName: buildModel.ProjectCollectionName,
                BuildServerUrl : buildModel.BuildServerUrl,
                DomainName: buildModel.DomainName,
                ProjectName: buildModel.ProjectName,
                TFSUserID: buildModel.BuildServerUserID,
                TFSPassword: buildModel.BuildServerPassword,
                BuildServerTool: buildModel.BuildServerToolCM.toolname,
                DeployServerTool: buildModel.DeployServerToolCM.toolname,
                EnableRiskAnalysisUI: buildModel.EnableRiskAnalysisUI,
                EnableUnitTestUI: buildModel.EnableUnitTestUI,
                EnableUnitTestMiddle: buildModel.EnableUnitTestMiddle,
                ApplicationName: buildModel.AppName,
                MonitorAppTier: buildModel.MonitorAppTier,
                MonitorMiddleTier: buildModel.MonitorMiddleTier,
                MonitorDataTier: buildModel.MonitorDataTier
            });
        }
        else if (buildModel.MonitorAppTier == true) {
            
            
            CMConfigModel = new cmconfigModel({
                
                BuildActivityListUI : buildModel.BuildActivityListUI,
                BuildReportListUI : buildModel.BuildReportListUI,
                BuildRiskListUI : buildModel.BuildRiskListUI,
                BuildItemListUI : buildModel.BuildItemListUI,
                UnitTestActivityListUI : buildModel.UnitTestActivityListUI,
                UnitTestReportListUI : buildModel.UnitTestReportListUI,
                UnitTestResultListUI : buildModel.UnitTestResultListUI,
                DeployUI : buildModel.DeployComponent,
                //DeployActivityListUI : buildModel.DeployActivityListUI,  
                //DeployPackageListUI: buildModel.DeployPackageListUI,
                //DeployApprovalListUI : buildModel.DeployApprovalListUI,
                DeployInReleaseListUI : buildModel.DeployInReleaseListUI,  
                
                BuildReportPathUI : buildModel.BuildReportPathUI,
                ProjectCollectionName: buildModel.ProjectCollectionName,
                BuildServerUrl : buildModel.BuildServerUrl,
                DomainName: buildModel.DomainName,
                ProjectName: buildModel.ProjectName,
                TFSUserID: buildModel.BuildServerUserID,
                TFSPassword: buildModel.BuildServerPassword,
                BuildServerTool: buildModel.BuildServerToolCM.toolname,
                DeployServerTool: buildModel.DeployServerToolCM.toolname,
                EnableRiskAnalysisUI: buildModel.EnableRiskAnalysisUI,
                EnableUnitTestUI: buildModel.EnableUnitTestUI,
                ApplicationName: buildModel.AppName,
                MonitorAppTier: buildModel.MonitorAppTier,
                MonitorMiddleTier: buildModel.MonitorMiddleTier,
                MonitorDataTier: buildModel.MonitorDataTier
            });
        }
        else if (buildModel.MonitorMiddleTier == true) {
            
            
            CMConfigModel = new cmconfigModel({
                
                DeployMid : buildModel.DeployMid,
                DeployActivityListMiddle : buildModel.DeployActivityListMiddle,  
                DeployPackageListMiddle: buildModel.DeployPackageListMiddle,
                DeployApprovalListMiddle : buildModel.DeployApprovalListMiddle,
                DeployInReleaseListMiddle : buildModel.DeployInReleaseListMiddle, 
                BuildActivityListMiddle : buildModel.BuildActivityListMiddle,
                BuildReportListMiddle : buildModel.BuildReportListMiddle,
                BuildRiskListMiddle : buildModel.BuildRiskListMiddle,
                BuildItemListMiddle : buildModel.BuildItemListMiddle,
                UnitTestActivityListMiddle : buildModel.UnitTestActivityListMiddle,
                UnitTestReportListMiddle : buildModel.UnitTestReportListMiddle,
                UnitTestResultListMiddle : buildModel.UnitTestResultListMiddle,
                
                BuildReportPathMiddle : buildModel.BuildReportPathMiddle,
                ProjectCollectionName: buildModel.ProjectCollectionName,
                BuildServerUrl : buildModel.BuildServerUrl,
                DomainName: buildModel.DomainName,
                ProjectName: buildModel.ProjectName,
                TFSUserID: buildModel.BuildServerUserID,
                TFSPassword: buildModel.BuildServerPassword,
                BuildServerTool: buildModel.BuildServerToolCM.toolname,
                DeployServerTool: buildModel.DeployServerToolCM.toolname,
                EnableUnitTestMiddle: buildModel.EnableUnitTestMiddle,
                ApplicationName: buildModel.AppName,
                MonitorAppTier: buildModel.MonitorAppTier,
                MonitorMiddleTier: buildModel.MonitorMiddleTier,
                MonitorDataTier: buildModel.MonitorDataTier
            });
        }
        else if (buildModel.AllStagesList.length > 0) {
            CMConfigModel = new cmconfigModel({
                
                BuildServerTool: buildModel.BuildServerTool.toolname,
                DeployServerTool: buildModel.DeployServerTool.toolname,
                ApplicationName: buildModel.AppName,
                BuildServerName: buildModel.BuildServerName,
                BuildServerPort: buildModel.BuildServerPort,
                //BuildServerUserId: buildModel.BuildServerUserId,
                //BuildServerPassword: buildModel.BuildServerPassword,
                DeployServerUrl: buildModel.DeployServerUrl,
                DeployServerPort: buildModel.DeployServerPort,
                DeployServerDomain: buildModel.DeployServerDomain,
                DeployServerUserID: buildModel.DeployServerUserID,
                DeployServerPassword: buildModel.DeployServerPassword,
                DeploySecurityType: buildModel.DeploySecurityType,
                AllStagesList: buildModel.AllStagesList,
                DeployUdeployApplicationList: buildModel.DeployUdeployApplicationList,
                DeployUdeployStageList: buildModel.DeployUdeployStageList
            });
        }
        else { CMConfigModel = new cmconfigModel({ ApplicationName: buildModel.AppName }); }
        
        CMConfigModel.save(function (err, data) {
            ////debugger;
            if (err) {
               var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: "SaveCMConfigurationMongo", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                //console.log(err);
                res.send(err);
            }
            else {
                //console.log(data);
                console.log(constants.SAVECM_CONFIG_SUCCESS_MSG);
                res.send(data);
            }
        });
        
       

        
        
    },
    
    //Edit CM Configuration
    ModifyCMConfiguration : function (req, res) {
        var method = "ModifyCMConfiguration";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildFactory = factory.prototype.GetBuildToolObj(buildModel.BuildServerToolCM.toolname);
        buildFactory.ModifyCMConfiguration(buildModel, function (error, resultdata) {
            // //debugger;
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "ModifyCMConfiguration", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
                //console.log(constants.MODIFYCM_CONFIG_ERROR_MSG);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    //Delete CM Configuration
    DeleteCMConfiguration : function (req, res) {
        var method = "DeleteCMConfiguration";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildFactory = factory.prototype.GetBuildToolObj(buildModel.BuildServerToolCM.toolname);
        buildFactory.DeleteCMConfiguration(buildModel, function (error, resultdata) {
            // //debugger;
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "DeleteCMConfiguration", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
                //console.log(constants.DELETECMCONFIGURATION_NOT_WORKING);
            }
            else {
                if (resultdata == "" || resultdata == undefined) {
                    res.send(true);
                }
            }
           
        });
    },
    
    DeleteCMConfigurationDetailsMongo : function (req, res) {
        var method = "DeleteCMConfigurationDetailsMongo";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        cmconfigModel.remove({
            "ApplicationName" : buildModel.ApplicationName
        }).exec();
        res.send(true);
    },
    
    GetTFSBuildDefinitions : function (req, res) {
        
        var method = "GetTFSBuildDefinitions";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';

        var buildModel = JSON.parse(eval(buildModelParam));
        //var buildDtls = req.query['buildModelParam'];//split("&");
        //var buildModel = JSON.parse(buildDtls);
        
        //var TFSDetailsModel = (
        //    {
        //        "ProjectCollectionName": buildDtls[0],
        //        "ProjectName": buildDtls[1],
        //       "BuildServerUserID": buildDtls[2],
        //        "BuildServerPassword": buildDtls[3]
        //    }
        //);
        
        //var buildModel = TFSDetailsModel;
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.GetTFSBuildDefinitions(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "GetTFSBuildDefinitions", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                
                res.send(resultdata);
            }
           
        });
    }, 
    
    GetMetadataTemplate : function (req, res) {
        var method = "GetMetadataTemplate";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildServerTool = constants.TFS;
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildFactory.GetMetadataTemplate("", function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error",methodName: "GetMetadataTemplate", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                
                res.send(resultdata);
            }

        });
    }, 
    
    GetInReleaseData : function (req, res) {
        
        var method = "GetInReleaseData";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildNumber = req.params.buildNumber;
        var buildFactory = factory.prototype.GetBuildToolObj(constants.TFS);
        buildFactory.GetInReleaseData(buildNumber, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "GetInReleaseData", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                var result = JSON.stringify(resultdata);
                res.send(result);
            }
           
        });
    },     
    
    SaveBuildDefinition: function (req, res) {
        var method = "SaveBuildDefinition";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildDefinition;
        var buildModel = JSON.parse(buildModelParam);
        var modCustomActUI = JSON.stringify(buildModel.CustomActivitiesUI);
        buildModel.ItemsToBuildUI = decodeURIComponent(buildModel.ItemsToBuildUI);
        // Middle tier
        buildModel.ItemsToBuildMiddle = decodeURIComponent(buildModel.ItemsToBuildMiddle);
        
        //buildModel.SourceControlUrl = decodeURIComponent(decodeURIComponent(buildModel.SourceControlUrl));
        var BuildDefinitionModel = new builddefnModel(
            {
                ModelEnableCMCIService: buildModel.ModelEnableCMCIService,
                ModelEnableCMCDService: buildModel.ModelEnableCMCDService,
                //BuildServerTool: buildModel.BuildServerTool,
                //SourceControlTool: buildModel.SourceControlTool,
                BinaryRepositoryTool: buildModel.BinaryRepositoryTool,
                //BuildServerName: buildModel.BuildServerName,
                //BuildServerUrl: buildModel.BuildServerUrl,
                //BuildServerPort: buildModel.BuildServerPort,
                //BuildServerUserID: buildModel.BuildServerUserID,
                //BuildServerPassword: buildModel.BuildServerPassword,
                //BuildServerDomain: buildModel.BuildServerDomain,   
                //SourceControlUserID: buildModel.SourceControlUserID,
                //SourceControlPassword: buildModel.SourceControlPassword,
                //BuildOutputPath: buildModel.BuildOutputPath,
                //InstalledPath: buildModel.InstalledPath, 
                //BuildReportPath: buildModel.BuildReportPath,
                ApplicationName: buildModel.ApplicationName,
                ProjectFolderName: buildModel.ProjectFolderName,
                ProjectFolderUI: buildModel.ProjectFolderUI,
                BuildServerTemplate: buildModel.BuildServerTemplate,
                SelectedBuildTemplate: buildModel.SelectedBuildTemplate,                          
                EnableAppTier: buildModel.EnableAppTier,
                UITierAppType: buildModel.UITierAppType,
                ItemsToBuildUI: buildModel.ItemsToBuildUI,
                ModelEnableUnitTestUI: buildModel.ModelEnableUnitTestUI,
                EnableAssemblyVersion: buildModel.EnableAssemblyVersion,
                AppProjectNameUI: buildModel.AppProjectNameUI,
                OutputFileNameUI: buildModel.OutputFileNameUI,
                ModelEnableCodeMetricsUI: buildModel.ModelEnableCodeMetricsUI,
                ModelEnableCodeSecAnalysisUI: buildModel.ModelEnableCodeSecAnalysisUI,
                TestAssemblyFileNameUI: buildModel.TestAssemblyFileNameUI,
                TestSettingsFileNameUI: buildModel.TestSettingsFileNameUI,
                EnableAssemblyVersionUI: buildModel.EnableAssemblyVersionUI,
                MajorVersion: buildModel.MajorVersion,
                ModelEnableCodeAnalysisMiddle: buildModel.ModelEnableCodeAnalysisMiddle,
                ModelEnableCodeSecAnalysisMiddle: buildModel.ModelEnableCodeSecAnalysisMiddle,
                MajorVersionUI: buildModel.MajorVersionUI,
                MinorVersionUI: buildModel.MinorVersionUI,
                MinorVersion: buildModel.MinorVersion,
                password: buildModel.password,
                ModelEnableRepository: buildModel.ModelEnableRepository,
                ModelEnableCodeMetricsMiddle: buildModel.ModelEnableCodeMetricsMiddle,
                ModelEnableCodeCoverageMiddle: buildModel.ModelEnableCodeCoverageMiddle,
                ModelEnableCodeAnalysisUI: buildModel.ModelEnableCodeAnalysisUI,
                ModelEnableCodeCoverageUI: buildModel.ModelEnableCodeCoverageUI,
                ModelPushPackageToNexusUI: buildModel.ModelPushPackageToNexusUI,
                ModelNexusUrlUI: buildModel.ModelNexusUrlUI,
                ModelPushPackageToCodeStationUI: buildModel.ModelPushPackageToCodeStationUI,
                ModelEnableQualityReportsUI: buildModel.ModelEnableQualityReportsUI,
                EnableSonarAnalysisUI: buildModel.EnableSonarAnalysisUI,  
                EnableWebHook: buildModel.EnableWebHook,       
                ProjectNameMiddle: buildModel.ProjectNameMiddle,
                EnableEMailSendingUI: buildModel.EnableEMailSendingUI,
                EnableEMailAttachementUI: buildModel.EnableEMailAttachementUI,
                EMailFromUI: buildModel.EMailFromUI,
                EMailToUI: buildModel.EMailToUI,
                SMTPServerUI: buildModel.SMTPServerUI,
                SMTPServerPortUI  : buildModel.SMTPServerPortUI,
                SMTPServerUserNameUI  : buildModel.SMTPServerUserNameUI,
                SMTPServerPwdUI  : buildModel.SMTPServerPwdUI,
                EnableDeployPackageUI: buildModel.EnableDeployPackageUI,
                PackageServerNameUI: buildModel.PackageServerNameUI,
                PackageUserNameUI: buildModel.PackageUserNameUI,            
                PackagePasswordUI: buildModel.PackagePasswordUI,
                VirtualDirPathUI: buildModel.VirtualDirPathUI,
                BuildController : buildModel.BuildController,
                BoxBuildAgent: buildModel.BoxBuildAgent,
                BuildOutputFolder: buildModel.BuildOutputFolder,
                EnableMiddleTier  : buildModel.EnableMiddleTier,
                BusinessTierAppType  : buildModel.BusinessTierAppType,
                ItemsToBuildMiddle  : buildModel.ItemsToBuildMiddle,
                OutputFileNameMiddle: buildModel.OutputFileNameMiddle,
                TestAssemblyFileNameMiddle: buildModel.TestAssemblyFileNameMiddle,
                TestSettingsFileNameMiddle: buildModel.TestSettingsFileNameMiddle,
                EnableAssemblyVersionMiddle  : buildModel.EnableAssemblyVersionMiddle,
                MajorVersionMiddle  : buildModel.MajorVersionMiddle,
                MinorVersionMiddle  : buildModel.MinorVersionMiddle,               
                ModelPushPackageToNexusMiddle  : buildModel.ModelPushPackageToNexusMiddle,
                ModelNexusUrlMiddle  : buildModel.ModelNexusUrlMiddle,
                ModelPushPackageToCodeStationMiddle  : buildModel.ModelPushPackageToCodeStationMiddle,
                ModelEnableQualityReportsMiddle  : buildModel.ModelEnableQualityReportsMiddle,
                EnableSonarAnalysisMiddle  : buildModel.EnableSonarAnalysisMiddle,           
                EnableEMailSendingMiddle  : buildModel.EnableEMailSendingMiddle,
                EnableEMailAttachementMiddle  : buildModel.EnableEMailAttachementMiddle,
                EMailFromMiddle  : buildModel.EMailFromMiddle,
                EMailToMiddle  : buildModel.EMailToMiddle,
                SMTPServerMiddle  : buildModel.SMTPServerMiddle, 
                SMTPServerPortMiddle  : buildModel.SMTPServerPortMiddle,
                SMTPServerUserNameMiddle  : buildModel.SMTPServerUserNameMiddle,
                SMTPServerPwdMiddle  : buildModel.SMTPServerPwdMiddle,  
                RequirementToolMiddle: buildModel.RequirementToolMiddle,
                RequirementApiMiddle: buildModel.RequirementApiMiddle,
                RequirementUserNameMiddle: buildModel.RequirementUserNameMiddle,
                RequirementPwdMiddle: buildModel.RequirementPwdMiddle,               
                EnableDeployPackageMT: buildModel.EnableDeployPackageMT,
                PackageServerNameMT: buildModel.PackageServerNameMT,
                PackageUserNameMT: buildModel.PackageUserNameMT,
                PackagePasswordMT: buildModel.PackagePasswordMT,
                VirtualDirPathMT: buildModel.VirtualDirPathMT,
                EnableDataTier  : buildModel.EnableDataTier,
                DataTierAppType  : buildModel.DataTierAppType,
                DeployDBScripts  : buildModel.DeployDBScripts,
                DBScriptsPath  : buildModel.DBScriptsPath,
                EnableAssemblyVersionData  : buildModel.EnableAssemblyVersionData,
                DataMajorVersion  : buildModel.DataMajorVersion,
                DataMinorVersion  : buildModel.DataMinorVersion,
                ModelEnableRepositoryData  : buildModel.ModelEnableRepositoryData,
                ModelPushPackageToNexusData  : buildModel.ModelPushPackageToNexusData,
                ModelNexusUrlData  : buildModel.ModelNexusUrlData,
                ModelPushPackageToCodeStationData  : buildModel.ModelPushPackageToCodeStationData,       
                EnableEMailSendingData  : buildModel.EnableEMailSendingData,
                EnableEMailAttachementData  : buildModel.EnableEMailAttachementData,
                EMailFromData  : buildModel.EMailFromData,
                EMailToData  : buildModel.EMailToData,
                SMTPServerData  : buildModel.SMTPServerData,
                SMTPServerPortData  : buildModel.SMTPServerPortData,
                SMTPServerUserNameData  : buildModel.SMTPServerUserNameData,
                SMTPServerPwdData  : buildModel.SMTPServerPwdData,
                CodeCoverageThresholdUI: buildModel.CodeCoverageThresholdUI,
                CodeCoverageThresholdMiddle: buildModel.CodeCoverageThresholdMiddle,
                EnableUnitTestUI : buildModel.EnableUnitTestUI,
                EnableUnitTestMiddle : buildModel.EnableUnitTestMiddle,
                UnitTestToolUI: buildModel.UnitTestToolUI,
                UnitTestThresholdValueUI : buildModel.UnitTestThresholdValueUI,
                UnitTestToolMiddle: buildModel.UnitTestToolMiddle,
                UnitTestThresholdValueMiddle: buildModel.UnitTestThresholdValueMiddle,
                EnableCodeCoverageUI : buildModel.EnableCodeCoverageUI,
                CodeCoverageToolUI: buildModel.CodeCoverageToolUI,
                EnableCodeCoverageMiddle : buildModel.EnableCodeCoverageMiddle,
                CodeCoverageToolMiddle : buildModel.CodeCoverageToolMiddle,
                EnableCodeAnalysisUI : buildModel.EnableCodeAnalysisUI,
                CodeAnalysisToolUI: buildModel.CodeAnalysisToolUI,
                CodeAnalysisCustomRulesUI: buildModel.CodeAnalysisCustomRulesUI,
                EnableCodeAnalysisMiddle : buildModel.EnableCodeAnalysisMiddle,
                CodeAnalysisToolMiddle : buildModel.CodeAnalysisToolMiddle,
                CodeAnalysisCustomRulesMiddle: buildModel.CodeAnalysisCustomRulesMiddle,
                EnableSecAnalysisUI : buildModel.EnableSecAnalysisUI,
                SecAnalysisToolUI: buildModel.SecAnalysisToolUI,
                EnableSecAnalysisMiddle : buildModel.EnableSecAnalysisMiddle,
                SecAnalysisToolMiddle : buildModel.SecAnalysisToolMiddle,
                EnableCodeMetricsUI : buildModel.EnableCodeMetricsUI,
                CodeMetricsToolUI : buildModel.CodeMetricsToolUI,
                ProjectFolderMiddle: buildModel.ProjectFolderMiddle,
                EnableCodeMetricsMiddle : buildModel.EnableCodeMetricsMiddle,
                CodeMetricsToolMiddle : buildModel.CodeMetricsToolMiddle,
                ModelEnableUnitTestMiddle: buildModel.ModelEnableUnitTestMiddle,
                EnableRiskAnalysisUI : buildModel.EnableRiskAnalysisUI,
                EnableRiskAnalysisMiddle : buildModel.EnableRiskAnalysisMiddle,
                CoverageInputUI : buildModel.CoverageInputUI,
                MetricInputUI : buildModel.MetricInputUI,
                CoverageInputMiddle : buildModel.CoverageInputMiddle,
                MetricInputMiddle : buildModel.MetricInputMiddle,
                EnableBuildPackageMiddle : buildModel.EnableBuildPackageMiddle,
                EnableBuildPackageUI : buildModel.EnableBuildPackageUI,
                PackagingFormatMiddle : buildModel.PackagingFormatMiddle,
                PackageScriptMiddle : buildModel.PackageScriptMiddle,
                ScriptFileMiddle : buildModel.ScriptFileMiddle,
                PackageParametersMiddle : buildModel.PackageParametersMiddle,
                ExecutionCommandMiddle : buildModel.ExecutionCommandMiddle,
                PackagingFormatUI : buildModel.PackagingFormatUI,
                PackageScriptUI : buildModel.PackageScriptUI,
                ScriptFileUI : buildModel.ScriptFileUI,
                PackageParametersUI : buildModel.PackageParametersUI,
                ExecutionCommandUI : buildModel.ExecutionCommandUI,
                BuildConfigiurationsUI : buildModel.BuildConfigiurationsUI,
                BuildPlatformUI : buildModel.BuildPlatformUI,
                BuildConfigiurationsMiddle : buildModel.BuildConfigiurationsMiddle,
                BuildPlatformMiddle : buildModel.BuildPlatformMiddle,
                PackageFolderMiddle : buildModel.PackageFolderMiddle,
                PackageFolderUI : buildModel.PackageFolderUI,
                EnableCodeRepository : buildModel.EnableCodeRepository,
                RepositoryTool : buildModel.RepositoryTool,
                RepositoryUserId : buildModel.RepositoryUserId,
                Repositorypassword : buildModel.Repositorypassword,
                EnableRepositoryUI: buildModel.EnableRepositoryUI,
                EnableRepositoryMiddle: buildModel.EnableRepositoryMiddle,
                RepositoryUrl: buildModel.RepositoryUrl,
                UdComponentNameUI: buildModel.UdComponentNameUI,
                UdComponentNameMiddle: buildModel.UdComponentNameMiddle,
                EnableRepositoryData: buildModel.EnableRepositoryData,
                ProjectCollectionName : buildModel.ProjectCollectionName,
                ProjectName: buildModel.ProjectName,
                EnableGatedBuildUI: buildModel.EnableGatedBuildUI,
                EnableGatedBuildMiddle: buildModel.EnableGatedBuildMiddle,
                EnableReleaseBuild: buildModel.EnableReleaseBuild,
                CustomActivitiesUI: modCustomActUI,
                CustomActivitiesMT: buildModel.CustomActivitiesMT,
                EnableActMonMT: buildModel.EnableActMonMT,
                EnableActMonUI: buildModel.EnableActMonUI,
                ModelActMonMT: buildModel.ModelActMonMT,
                ModelActMonUI: buildModel.ModelActMonUI,
                ModelActDispNmMT: buildModel.ModelActDispNmMT,
                ModelActDispNmUI: buildModel.ModelActDispNmUI,
                TFSBuildDefinitions: buildModel.TFSBuildDefinitions,
                SelectedTFSBuildDefinitions: buildModel.SelectedTFSBuildDefinitions,
                EnableCodeRepositoryUI     : buildModel.EnableCodeRepositoryUI,
                RepositoryToolUI           : buildModel.RepositoryToolUI,
                RepositoryUserIdUI         : buildModel.RepositoryUserIdUI,
                RepositoryPasswordUI       : buildModel.RepositoryPasswordUI,
                RepositoryUrlUI            : buildModel.RepositoryUrlUI,
                UdComponentNameAppUI       : buildModel.UdComponentNameAppUI,
                UdComponentNameAppMiddle   : buildModel.UdComponentNameAppMiddle,
                EnableReposAppUIYes        : buildModel.EnableReposAppUIYes,
                EnableRepositoryAppUI      : buildModel.EnableRepositoryAppUI,
                EnableRepositoryAppMiddle  : buildModel.EnableRepositoryAppMiddle,
                EnableRepositoryAppData    : buildModel.EnableRepositoryAppData,
                EnableCodeRepositoryMiddle : buildModel.EnableCodeRepositoryMiddle,
                RepositoryToolMiddle       : buildModel.RepositoryToolMiddle,
                RepositoryUserIdMiddle     : buildModel.RepositoryUserIdMiddle,
                RepositoryPasswordMiddle   : buildModel.RepositoryPasswordMiddle,
                RepositoryUrlMiddle        : buildModel.RepositoryUrlMiddle,
                UdComponentNameBLUI        : buildModel.UdComponentNameBLUI,
                UdComponentNameBLMiddle    : buildModel.UdComponentNameBLMiddle,
                EnableReposAppMidYes       : buildModel.EnableReposAppMidYes,
                EnableRepositoryBLUI       : buildModel.EnableRepositoryBLUI,
                EnableRepositoryBLMiddle   : buildModel.EnableRepositoryBLMiddle,
                EnableRepositoryBLData     : buildModel.EnableRepositoryBLData,
                
                EnableJenDeployPackageUI: buildModel.EnableJenDeployPackageUI,
                //DeployPackageToolUI: buildModel.DeployPackageToolUI,
                DeployPackageUserIdUI: buildModel.DeployPackageUserIdUI,
                DeployPackagePasswordUI: buildModel.DeployPackagePasswordUI,
                DeployPackageUrlUI: buildModel.DeployPackageUrlUI,
                ArtifactToUploadUI: buildModel.ArtifactToUploadUI,
                PackageNameUI: buildModel.PackageNameUI,
                NexusGroupUI: buildModel.NexusGroupUI,
                PackageVersionUI: buildModel.PackageVersionUI,
                Noinstance: buildModel.Noinstance,
                DockerportNumber: buildModel.DockerportNumber,
                Kubernetes:buildModel.Kubernetes,
                //EnableJenDeployPackageMiddle: buildModel.EnableJenDeployPackageMiddle,
                DeployPackageToolMiddle: buildModel.DeployPackageToolMiddle,
                DeployPackageUserIdMiddle: buildModel.DeployPackageUserIdMiddle,
                DeployPackagePasswordMiddle: buildModel.DeployPackagePasswordMiddle,
                DeployPackageUrlMiddle: buildModel.DeployPackageUrlMiddle,
                BuildPipeline: buildModel.PipelineData,
                
                EnableDockerFileUI : buildModel.EnableDockerFileUI,
                DockerFilePathUI : buildModel.DockerFilePathUI
                
                //StgName : buildModel.StgName,
                //StgDisp : buildModel.StgDisp
            });
        
        
        BuildDefinitionModel.save(function (err, data) {
            
            if (err) {
               var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: "BuildDefinitionModel.save", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                console.log(err);
                res.send(err);
            }
            else {
                //console.log(data);
                console.log(constants.BUILD_DEF_DATA_SUCCESS_MSG);
                res.send(data);
            }
        });
       
    }, 
    
    AddDeployServerConfig: function (req, res) {
        var method = "AddDeployServerConfig";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.DeployServerConfig;
        var deployserverconfigmodel = JSON.parse(buildModelParam);
        
        if (deployserverconfigmodel.Servicetype == constants.CD) {
            
            // Get the build model
            var buildServerTool = deployserverconfigmodel.BuildServerTool;
            var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
            buildFactory.CreateBuildDefinition(deployserverconfigmodel, function (error, resultdata) {
                
                if (error != null) {
                   var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                    customlogger.error({ loginfo: loginfo });
                    res.send(error);
                }
                else {
                    res.send(resultdata);
                    //var addDeployServerConfigModel = new deployServerConfigModel(               
                    //    {                            
                    //        CDApplicationName                         : deployserverconfigmodel.CDApplicationName,                            
                    //        // template name BuildServerConfigName
                    //        DeployServerConfigname                    : deployserverconfigmodel.DeployServerConfigname.DeployServerConfigName,
                    //        CDJobName                                 : deployserverconfigmodel.CDJobName,                        
                    //        DeployStages                              : deployserverconfigmodel.DeployStages            
                    //    });
                    
                    //addDeployServerConfigModel.save(function (err, data) {                        
                    //    if (err) {                            
                    //        console.log(err);
                    //        res.send(err);
                    //    }
                    //    else {
                    //        console.log(constants.ADD_DEPLOY_SER_SUCCESS_MSG);
                    //        res.send(constants.SUCCESS);
                    //    }
                    //});      
                }
            });
        }   
      
    }, 
    
    SaveDeployServerConfig: function (req, res) {
        var method = "SaveDeployServerConfig";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        } 
        var buildModelParam = req.body.DeployServerConfig;
        var deployserverconfigmodel = JSON.parse(buildModelParam);
        
        var addDeployServerConfigModel = new deployServerConfigModel(
      
            {
                ServiceType: deployserverconfigmodel.Servicetype,
                CDApplicationName                          : deployserverconfigmodel.CDApplicationName,
                
                // template name BuildServerConfigName
                DeployServerConfigname                    : deployserverconfigmodel.DeployServerConfigname.DeployServerConfigName,
                CDJobName                                 : deployserverconfigmodel.CDJobName,    
                
                DeployStages                              : deployserverconfigmodel.DeployStages,
                BuildPipeline                             : deployserverconfigmodel.PipelineData
                   
                 
            });
        
        addDeployServerConfigModel.save(function (err, data) {
            
            if (err) {
               var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                console.log(err);
                res.send(err);
            }
            else {
                //console.log(data);
                console.log(constants.ADD_DEPLOY_SER_SUCCESS_MSG);
                res.send(constants.SUCCESS);
            }
        });
    },


    // Adding deploy server
    AddDeployServer: function (req, res) {
        var method = "AddDeployServer";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.DeployServer;
        
        
        
        var deployservermodel = JSON.parse(buildModelParam);
        
        var addDeployServerModel = new deployServerModel(
            {
                // template name BuildServerConfigName
                DeployServerConfigName   : deployservermodel.DeployServerConfigname,
                
                BuildServerPort         : deployservermodel.BuildServerPort,
                BuildServerName          : deployservermodel.BuildServerName,
                BuildServerUserID     : deployservermodel.BuildServerUserID,
                BuildServerPassword     : deployservermodel.BuildServerPassword,
                
                
                ConfigurationTool       : deployservermodel.ConfigurationTool.toolname,
                ConfigurationPath       : deployservermodel.ConfigurationPath,
                ConfigurationUsername   : deployservermodel.ConfigurationUsername, 
                ConfigurationPassword   : deployservermodel.ConfigurationPassword,
             
                
            });
        
        
        addDeployServerModel.save(function (err, data) {
            
            if (err) {
               var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                console.log(err);
                res.send(err);
            }
            else {
                //console.log(data);
                console.log(constants.ADD_DEPLOY_SER_SUCCESS_MSG);
                res.send(constants.SUCCESS);
            }
        });
       
    }, 
    
    
    //Adding build server
    AddBuildServer: function (req, res) {
        var method = "AddBuildServer";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildServerDetails;
        
        
        
        var servermodel = JSON.parse(buildModelParam);
        //var modCustomActUI = JSON.stringify(buildModel.CustomActivitiesUI);
        //buildModel.ItemsToBuildUI = decodeURIComponent(buildModel.ItemsToBuildUI);
        // Middle tier
        //buildModel.ItemsToBuildMiddle = decodeURIComponent(buildModel.ItemsToBuildMiddle);
        
        //buildModel.SourceControlUrl = decodeURIComponent(decodeURIComponent(buildModel.SourceControlUrl));
        var addBuildServerModel = new buildServerModel(
            {
                // template name BuildServerConfigName
                BuildServerConfigName     : servermodel.BuildServerConfigName,
                
                BuildServerTool         : servermodel.BuildServerTool.toolname,
                SourceControlTool       : servermodel.SourceControlTool.toolname,
                
                //both for jenkins and tfs
                BuildServerPort         : servermodel.BuildServerPort,
                BuildServerName         : servermodel.BuildServerName,
                BuildServerUserID       : servermodel.BuildServerUserID,
                BuildServerPassword     : servermodel.BuildServerPassword,

                //git
                GitCredentials          : servermodel.GitCredentials,
                
                //tfs
                BuildServerUrl          : servermodel.BuildServerUrl,
                BuildServerDomain       : servermodel.BuildServerDomain, 
                BuildController         : servermodel.BuildController,
                BuildOutputFolder       : servermodel.BuildOutputFolder,
                BoxBuildAgent           : servermodel.BoxBuildAgent, 
                ProjectCollectionName   : servermodel.ProjectCollectionName,
                
                //jenkins
                SourceControlUserID     : servermodel.SourceControlUserID,
                SourceControlPassword   : servermodel.SourceControlPassword,
                InstalledPath           : servermodel.InstalledPath,
                BuildOutputPath         : servermodel.BuildOutputPath

                
            });
        
        
        addBuildServerModel.save(function (err, data) {
            
            if (err) {
               var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                console.log(err);
                res.send(err);
            }
            else {
                //console.log(data);
                console.log(constants.ADD_BUILD_SER_SUCCESS_MSG);
                res.send(constants.SUCCESS);
            }
        });
       
    }, 
    
    //Editing build server config data
    EditBuildServerConfig: function (req, res) {
        var method = "EditBuildServerConfig";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildServerConfigDetails = req.body.buildServerConfigDetails;
        var buildServerConfigModel = JSON.parse(buildServerConfigDetails);
        
        buildServerModel.update({ BuildServerConfigName: buildServerConfigModel.BuildServerConfigName }, {
            $set: {
                BuildServerTool         : buildServerConfigModel.BuildServerTool.toolname,
                SourceControlTool       : buildServerConfigModel.SourceControlTool.toolname,
                
                //both for jenkins and tfs
                BuildServerPort         : buildServerConfigModel.BuildServerPort,
                BuildServerName         : buildServerConfigModel.BuildServerName,
                
                //tfs
                BuildServerUrl          : buildServerConfigModel.BuildServerUrl,
                BuildServerUserID       : buildServerConfigModel.BuildServerUserID,
                BuildServerDomain       : buildServerConfigModel.BuildServerDomain, 
                BuildController         : buildServerConfigModel.BuildController,
                BuildOutputFolder       : buildServerConfigModel.BuildOutputFolder,
                BuildServerPassword     : buildServerConfigModel.BuildServerPassword,
                BoxBuildAgent           : buildServerConfigModel.BoxBuildAgent, 
                ProjectCollectionName   : buildServerConfigModel.ProjectCollectionName,
                
                //jenkins
                SourceControlUserID     : buildServerConfigModel.SourceControlUserID,
                SourceControlPassword   : buildServerConfigModel.SourceControlPassword,
                GitCredentials          : buildServerConfigModel.GitCredentials,
                InstalledPath           : buildServerConfigModel.InstalledPath,
                BuildOutputPath         : buildServerConfigModel.BuildOutputPath
            }
        }).exec();
        
        res.send(constants.SUCCESS);
    },
    
    DeleteBuildServerConfigData: function (req, res) {
        var method = "DeleteBuildServerConfigData";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;        
        var buildServerConfigName = JSON.parse(req.params.buildServerConfigName);
        var buildServerTool = JSON.parse(req.params.buildServerTool);
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        buildServerModel.remove({
            "BuildServerConfigName": buildServerConfigName,
            "BuildServerTool": buildServerTool
        }).exec();
        
        res.send(true);
    },

    DeleteDeployServer: function (req, res) {
        var method = "DeleteDeployServer";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        //debugger;        
        var DeployServerName = JSON.parse(req.params.DeployServerName);
        //var buildServerTool = JSON.parse(req.params.buildServerTool);
        
       // var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        deployServerModel.remove({
            "DeployServerConfigName": DeployServerName
            
        }).exec();
        
        res.send(true);
    },

    SaveBuildDefinitionTemplate: function (req, res) {
        var method = "SaveBuildDefinitionTemplate";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildDefTemplateModelParam = req.body.buildModelParam;
        
        var buildModel = JSON.parse(buildDefTemplateModelParam);
        var BuildDefinitionTemplateModel = new buildDefTemplateModel(
            {
                TemplateName : buildModel.BuildTemplateName,                
                BuildServerTool : buildModel.BuildServerTool,                        
                EnableAppTier  : buildModel.EnableAppTier,
                UITierAppType  : buildModel.UITierAppType,
                EnableMiddleTier  : buildModel.EnableMiddleTier,
                BusinessTierAppType  : buildModel.BusinessTierAppType,
                EnableGatedBuildUI: buildModel.EnableGatedBuildUI,
                EnableGatedBuildMiddle: buildModel.EnableGatedBuildMiddle,
                EnableAssemblyVersion  : buildModel.EnableAssemblyVersion,
                EnableAssemblyVersionUI : buildModel.EnableAssemblyVersionUI,
                EnableAssemblyVersionMiddle : buildModel.EnableAssemblyVersionMiddle,
                EnableUnitTestUI : buildModel.EnableUnitTestUI,                
                UnitTestToolUI: buildModel.UnitTestToolUI,
                UnitTestThresholdValueUI: buildModel.UnitTestThresholdValueUI,
                EnableUnitTestMiddle : buildModel.EnableUnitTestMiddle,
                UnitTestToolMiddle: buildModel.UnitTestToolMiddle,
                UnitTestThresholdValueMiddle: buildModel.UnitTestThresholdValueMiddle,
                EnableCodeCoverageUI : buildModel.EnableCodeCoverageUI,
                CodeCoverageToolUI : buildModel.CodeCoverageToolUI,
                CodeCoverageThresholdUI: buildModel.CodeCoverageThresholdUI,
                EnableCodeCoverageMiddle : buildModel.EnableCodeCoverageMiddle,
                CodeCoverageToolMiddle : buildModel.CodeCoverageToolMiddle,
                CodeCoverageThresholdMiddle : buildModel.CodeCoverageThresholdMiddle,
                EnableCodeAnalysisUI : buildModel.EnableCodeAnalysisUI,
                CodeAnalysisToolUI : buildModel.CodeAnalysisToolUI,
                EnableCodeAnalysisMiddle : buildModel.EnableCodeAnalysisMiddle,
                CodeAnalysisToolMiddle : buildModel.CodeAnalysisToolMiddle,
                EnableSecAnalysisUI : buildModel.EnableSecAnalysisUI,
                SecAnalysisToolUI: buildModel.SecAnalysisToolUI,
                EnableSecAnalysisMiddle : buildModel.EnableSecAnalysisMiddle,
                SecAnalysisToolMiddle : buildModel.SecAnalysisToolMiddle,
                EnableCodeMetricsUI : buildModel.EnableCodeMetricsUI,
                CodeMetricsToolUI : buildModel.CodeMetricsToolUI,
                EnableCodeMetricsMiddle : buildModel.EnableCodeMetricsMiddle,
                CodeMetricsToolMiddle : buildModel.CodeMetricsToolMiddle,
                EnableRiskAnalysisUI : buildModel.EnableRiskAnalysisUI,
                CoverageInputUI : buildModel.CoverageInputUI,
                MetricInputUI : buildModel.MetricInputUI,
                EnableRiskAnalysisMiddle : buildModel.EnableRiskAnalysisMiddle,
                CoverageInputMiddle : buildModel.CoverageInputMiddle,
                MetricInputMiddle : buildModel.MetricInputMiddle,                
                EnableSonarAnalysisUI  : buildModel.EnableSonarAnalysisUI,
                EnableWebHook : buildModel.EnableWebHook,
                EnableSonarAnalysisMiddle  : buildModel.EnableSonarAnalysisMiddle,              
                EnableBuildPackageUI : buildModel.EnableBuildPackageUI,
                PackagingFormatUI : buildModel.PackagingFormatUI,                              
                EnableBuildPackageMiddle : buildModel.EnableBuildPackageMiddle,
                PackagingFormatMiddle : buildModel.PackagingFormatMiddle,                
                EnableDeployPackageUI : buildModel.EnableDeployPackageUI,
                EnableDeployPackageMT : buildModel.EnableDeployPackageMT,
                EnableJenDeployPackageUI : buildModel.EnableJenDeployPackageUI,
                EnableDockerFileUI : buildModel.EnableDockerFileUI,
                DockerFilePathUI : buildModel.DockerFilePathUI
                //EnableJenDeployPackageMiddle : buildModel.EnableJenDeployPackageMiddle
            });
        
        
        BuildDefinitionTemplateModel.save(function (err, data) {
            
            if (err) {
               var loginfo =  {message: err, sessionID: req.sessionID, levelName: "error", methodName: "BuildDefinitionTemplateModel", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                console.log(err);
                res.send(err);
            }
            else {
                console.log("Build definition template successfully saved.");
                res.send(data);
            }
        });
       
    }, 
    
    EditBuildDefinitionMongo: function (req, res) {
        var method = "EditBuildDefinitionMongo";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.buildDefinition;
        
        var buildModel = JSON.parse(buildModelParam);
        var modCustomActUI = JSON.stringify(buildModel.CustomActivitiesUI);
        buildModel.ItemsToBuildUI = decodeURIComponent(buildModel.ItemsToBuildUI);
        // Middle tier
        buildModel.ItemsToBuildMiddle = decodeURIComponent(buildModel.ItemsToBuildMiddle);
        
        builddefnModel.update({ ApplicationName: buildModel.ApplicationName }, {
            $set: {
               
                ModelEnableCMCIService: buildModel.ModelEnableCMCIService,
                ModelEnableCMCDService: buildModel.ModelEnableCMCDService,
                //BuildServerTool: buildModel.BuildServerTool,
                //SourceControlTool: buildModel.SourceControlTool,
                BinaryRepositoryTool: buildModel.BinaryRepositoryTool,
                //BuildServerName: buildModel.BuildServerName,
                //BuildServerUrl: buildModel.BuildServerUrl,
                //BuildServerPort: buildModel.BuildServerPort,
                //BuildServerUserID: buildModel.BuildServerUserID,
                //BuildServerPassword: buildModel.BuildServerPassword,
                //BuildServerDomain: buildModel.BuildServerDomain,   
                //SourceControlUserID: buildModel.SourceControlUserID,
                //SourceControlPassword: buildModel.SourceControlPassword,
                ProjectFolderUI: buildModel.ProjectFolderUI,
                BuildOutputPath: buildModel.BuildOutputPath,
                InstalledPath: buildModel.InstalledPath, 
                BuildReportPath: buildModel.BuildReportPath,
                ApplicationName: buildModel.ApplicationName,       
                SelectedBuildTemplate: buildModel.SelectedBuildTemplate,                       
                EnableAppTier: buildModel.EnableAppTier,
                UITierAppType: buildModel.UITierAppType,
                ItemsToBuildUI: buildModel.ItemsToBuildUI,
                ModelEnableUnitTestUI: buildModel.ModelEnableUnitTestUI,
                ProjectFolderMiddle: buildModel.ProjectFolderMiddle,
                EnableAssemblyVersion: buildModel.EnableAssemblyVersion,
                AppProjectNameUI: buildModel.AppProjectNameUI,
                OutputFileNameUI: buildModel.OutputFileNameUI,
                ModelEnableCodeMetricsUI: buildModel.ModelEnableCodeMetricsUI,
                TestAssemblyFileNameUI: buildModel.TestAssemblyFileNameUI,
                TestSettingsFileNameUI: buildModel.TestSettingsFileNameUI,
                EnableAssemblyVersionUI: buildModel.EnableAssemblyVersionUI,
                MajorVersion: buildModel.MajorVersion,
                ModelEnableCodeAnalysisMiddle: buildModel.ModelEnableCodeAnalysisMiddle,
                MajorVersionUI: buildModel.MajorVersionUI,
                MinorVersionUI: buildModel.MinorVersionUI,
                MinorVersion: buildModel.MinorVersion,
                MinorVersionMiddle: buildModel.MinorVersionMiddle,
                MajorVersionMiddle: buildModel.MajorVersionMiddle,
                //  password: buildModel.password,
                ModelEnableRepository: buildModel.ModelEnableRepository,
                ModelEnableCodeMetricsMiddle: buildModel.ModelEnableCodeMetricsMiddle,
                ModelEnableCodeCoverageMiddle: buildModel.ModelEnableCodeCoverageMiddle,
                ModelEnableCodeAnalysisUI: buildModel.ModelEnableCodeAnalysisUI,
                ModelEnableCodeCoverageUI: buildModel.ModelEnableCodeCoverageUI,
                ModelPushPackageToNexusUI: buildModel.ModelPushPackageToNexusUI,
                ModelNexusUrlUI: buildModel.ModelNexusUrlUI,
                ModelPushPackageToCodeStationUI: buildModel.ModelPushPackageToCodeStationUI,
                ModelEnableQualityReportsUI: buildModel.ModelEnableQualityReportsUI,
                EnableSonarAnalysisUI: buildModel.EnableSonarAnalysisUI, 
                EnableWebHook : buildModel.EnableWebHook,           
                ProjectNameMiddle: buildModel.ProjectNameMiddle,
                EnableEMailSendingUI: buildModel.EnableEMailSendingUI,
                EnableEMailAttachementUI: buildModel.EnableEMailAttachementUI,
                EMailFromUI: buildModel.EMailFromUI,
                EMailToUI: buildModel.EMailToUI,
                SMTPServerUI: buildModel.SMTPServerUI,
                SMTPServerPortUI  : buildModel.SMTPServerPortUI,
                SMTPServerUserNameUI  : buildModel.SMTPServerUserNameUI,
                SMTPServerPwdUI  : buildModel.SMTPServerPwdUI,
                EnableDeployPackageUI: buildModel.EnableDeployPackageUI,
                PackageServerNameUI: buildModel.PackageServerNameUI,
                PackageUserNameUI: buildModel.PackageUserNameUI,            
                PackagePasswordUI: buildModel.PackagePasswordUI,
                VirtualDirPathUI: buildModel.VirtualDirPathUI,
                BuildController : buildModel.BuildController,
                BoxBuildAgent: buildModel.BoxBuildAgent,
                BuildOutputFolder: buildModel.BuildOutputFolder,
                EnableMiddleTier  : buildModel.EnableMiddleTier,
                BusinessTierAppType  : buildModel.BusinessTierAppType,
                ItemsToBuildMiddle  : buildModel.ItemsToBuildMiddle,
                OutputFileNameMiddle: buildModel.OutputFileNameMiddle,
                TestAssemblyFileNameMiddle: buildModel.TestAssemblyFileNameMiddle,
                TestSettingsFileNameMiddle: buildModel.TestSettingsFileNameMiddle,
                EnableAssemblyVersionMiddle  : buildModel.EnableAssemblyVersionMiddle,
                MiddleMajorVersion  : buildModel.MajorVersionMiddle,
                MiddleMinorVersion  : buildModel.MinorVersionMiddle,               
                ModelPushPackageToNexusMiddle  : buildModel.ModelPushPackageToNexusMiddle,
                ModelNexusUrlMiddle  : buildModel.ModelNexusUrlMiddle,
                ModelPushPackageToCodeStationMiddle  : buildModel.ModelPushPackageToCodeStationMiddle,
                ModelEnableQualityReportsMiddle  : buildModel.ModelEnableQualityReportsMiddle,
                EnableSonarAnalysisMiddle  : buildModel.EnableSonarAnalysisMiddle,             
                EnableEMailSendingMiddle  : buildModel.EnableEMailSendingMiddle,
                EnableEMailAttachementMiddle  : buildModel.EnableEMailAttachementMiddle,
                EMailFromMiddle  : buildModel.EMailFromMiddle,
                EMailToMiddle  : buildModel.EMailToMiddle,
                SMTPServerMiddle  : buildModel.SMTPServerMiddle, 
                SMTPServerPortMiddle  : buildModel.SMTPServerPortMiddle,
                SMTPServerUserNameMiddle  : buildModel.SMTPServerUserNameMiddle,
                SMTPServerPwdMiddle  : buildModel.SMTPServerPwdMiddle,  
                RequirementToolMiddle: buildModel.RequirementToolMiddle,
                RequirementApiMiddle: buildModel.RequirementApiMiddle,
                RequirementUserNameMiddle: buildModel.RequirementUserNameMiddle,
                RequirementPwdMiddle: buildModel.RequirementPwdMiddle,               
                EnableDeployPackageMT: buildModel.EnableDeployPackageMT,
                PackageServerNameMT: buildModel.PackageServerNameMT,
                PackageUserNameMT: buildModel.PackageUserNameMT,
                PackagePasswordMT: buildModel.PackagePasswordMT,
                VirtualDirPathMT: buildModel.VirtualDirPathMT,
                EnableDataTier  : buildModel.EnableDataTier,
                DataTierAppType  : buildModel.DataTierAppType,
                DeployDBScripts  : buildModel.DeployDBScripts,
                DBScriptsPath  : buildModel.DBScriptsPath,
                EnableAssemblyVersionData  : buildModel.EnableAssemblyVersionData,
                DataMajorVersion  : buildModel.DataMajorVersion,
                DataMinorVersion  : buildModel.DataMinorVersion,
                ModelEnableRepositoryData  : buildModel.ModelEnableRepositoryData,
                ModelPushPackageToNexusData  : buildModel.ModelPushPackageToNexusData,
                ModelNexusUrlData  : buildModel.ModelNexusUrlData,
                ModelPushPackageToCodeStationData  : buildModel.ModelPushPackageToCodeStationData,       
                EnableEMailSendingData  : buildModel.EnableEMailSendingData,
                EnableEMailAttachementData  : buildModel.EnableEMailAttachementData,
                EMailFromData  : buildModel.EMailFromData,
                EMailToData  : buildModel.EMailToData,
                SMTPServerData  : buildModel.SMTPServerData,
                SMTPServerPortData  : buildModel.SMTPServerPortData,
                SMTPServerUserNameData  : buildModel.SMTPServerUserNameData,
                SMTPServerPwdData  : buildModel.SMTPServerPwdData,
                CodeCoverageThresholdUI: buildModel.CodeCoverageThresholdUI,
                CodeCoverageThresholdMiddle: buildModel.CodeCoverageThresholdMiddle,
                EnableUnitTestUI : buildModel.EnableUnitTestUI,
                EnableUnitTestMiddle : buildModel.EnableUnitTestMiddle,
                UnitTestToolUI: buildModel.UnitTestToolUI,
                UnitTestThresholdValueUI : buildModel.UnitTestThresholdValueUI,
                UnitTestToolMiddle: buildModel.UnitTestToolMiddle,
                UnitTestThresholdValueMiddle: buildModel.UnitTestThresholdValueMiddle,
                EnableCodeCoverageUI : buildModel.EnableCodeCoverageUI,
                CodeCoverageToolUI: buildModel.CodeCoverageToolUI,
                EnableCodeCoverageMiddle : buildModel.EnableCodeCoverageMiddle,
                CodeCoverageToolMiddle : buildModel.CodeCoverageToolMiddle,
                EnableCodeAnalysisUI : buildModel.EnableCodeAnalysisUI,
                CodeAnalysisToolUI: buildModel.CodeAnalysisToolUI,
                CodeAnalysisCustomRulesUI: buildModel.CodeAnalysisCustomRulesUI,
                EnableCodeAnalysisMiddle : buildModel.EnableCodeAnalysisMiddle,
                CodeAnalysisToolMiddle : buildModel.CodeAnalysisToolMiddle,
                CodeAnalysisCustomRulesMiddle: buildModel.CodeAnalysisCustomRulesMiddle,
                EnableSecAnalysisUI : buildModel.EnableSecAnalysisUI,
                SecAnalysisToolUI: buildModel.SecAnalysisToolUI,
                EnableSecAnalysisMiddle : buildModel.EnableSecAnalysisMiddle,
                SecAnalysisToolMiddle : buildModel.SecAnalysisToolMiddle,
                EnableCodeMetricsUI : buildModel.EnableCodeMetricsUI,
                CodeMetricsToolUI : buildModel.CodeMetricsToolUI,
                EnableCodeMetricsMiddle : buildModel.EnableCodeMetricsMiddle,
                CodeMetricsToolMiddle : buildModel.CodeMetricsToolMiddle,
                //ModelEnableUnitTestMiddle: buildModel.ModelEnableUnitTestMiddle,
                EnableRiskAnalysisUI : buildModel.EnableRiskAnalysisUI,
                EnableRiskAnalysisMiddle : buildModel.EnableRiskAnalysisMiddle,
                CoverageInputUI : buildModel.CoverageInputUI,
                MetricInputUI : buildModel.MetricInputUI,
                CoverageInputMiddle : buildModel.CoverageInputMiddle,
                MetricInputMiddle : buildModel.MetricInputMiddle,
                EnableBuildPackageMiddle : buildModel.EnableBuildPackageMiddle,
                EnableBuildPackageUI : buildModel.EnableBuildPackageUI,
                PackagingFormatMiddle : buildModel.PackagingFormatMiddle,
                PackageScriptMiddle : buildModel.PackageScriptMiddle,
                ScriptFileMiddle : buildModel.ScriptFileMiddle,
                PackageParametersMiddle : buildModel.PackageParametersMiddle,
                ExecutionCommandMiddle : buildModel.ExecutionCommandMiddle,
                PackagingFormatUI : buildModel.PackagingFormatUI,
                PackageScriptUI : buildModel.PackageScriptUI,
                ScriptFileUI : buildModel.ScriptFileUI,
                PackageParametersUI : buildModel.PackageParametersUI,
                ExecutionCommandUI : buildModel.ExecutionCommandUI,
                BuildConfigiurationsUI : buildModel.BuildConfigiurationsUI,
                BuildPlatformUI : buildModel.BuildPlatformUI,
                BuildConfigiurationsMiddle : buildModel.BuildConfigiurationsMiddle,
                BuildPlatformMiddle : buildModel.BuildPlatformMiddle,
                PackageFolderMiddle : buildModel.PackageFolderMiddle,
                PackageFolderUI : buildModel.PackageFolderUI,
                EnableCodeRepository : buildModel.EnableCodeRepository,
                RepositoryTool : buildModel.RepositoryTool,
                RepositoryUserId : buildModel.RepositoryUserId,
                Repositorypassword : buildModel.Repositorypassword,
                EnableRepositoryUI: buildModel.EnableRepositoryUI,
                EnableRepositoryMiddle: buildModel.EnableRepositoryMiddle,
                RepositoryUrl: buildModel.RepositoryUrl,
                UdComponentNameUI: buildModel.UdComponentNameUI,
                UdComponentNameMiddle: buildModel.UdComponentNameMiddle,
                EnableRepositoryData: buildModel.EnableRepositoryData,
                ProjectCollectionName : buildModel.ProjectCollectionName,
                ProjectName: buildModel.ProjectName,
                EnableGatedBuildUI: buildModel.EnableGatedBuildUI,
                EnableGatedBuildMiddle: buildModel.EnableGatedBuildMiddle,
                EnableReleaseBuild: buildModel.EnableReleaseBuild,
                CustomActivitiesUI: modCustomActUI,
                CustomActivitiesMT: buildModel.CustomActivitiesMT,
                EnableActMonMT: buildModel.EnableActMonMT,
                EnableActMonUI: buildModel.EnableActMonUI,
                ModelActMonMT: buildModel.ModelActMonMT,
                ModelActMonUI: buildModel.ModelActMonUI,
                ModelActDispNmMT: buildModel.ModelActDispNmMT,
                ModelActDispNmUI: buildModel.ModelActDispNmUI,
                TFSBuildDefinitions: buildModel.TFSBuildDefinitions,
                SelectedTFSBuildDefinitions: buildModel.SelectedTFSBuildDefinitions,
                EnableCodeRepositoryUI     : buildModel.EnableCodeRepositoryUI,
                RepositoryToolUI           : buildModel.RepositoryToolUI,
                RepositoryUserIdUI         : buildModel.RepositoryUserIdUI,
                RepositoryPasswordUI       : buildModel.RepositoryPasswordUI,
                RepositoryUrlUI            : buildModel.RepositoryUrlUI,
                UdComponentNameAppUI       : buildModel.UdComponentNameAppUI,
                UdComponentNameAppMiddle   : buildModel.UdComponentNameAppMiddle,
                EnableReposAppUIYes        : buildModel.EnableReposAppUIYes,
                EnableRepositoryAppUI      : buildModel.EnableRepositoryAppUI,
                EnableRepositoryAppMiddle  : buildModel.EnableRepositoryAppMiddle,
                EnableRepositoryAppData    : buildModel.EnableRepositoryAppData,
                EnableCodeRepositoryMiddle : buildModel.EnableCodeRepositoryMiddle,
                RepositoryToolMiddle       : buildModel.RepositoryToolMiddle,
                RepositoryUserIdMiddle     : buildModel.RepositoryUserIdMiddle,
                RepositoryPasswordMiddle   : buildModel.RepositoryPasswordMiddle,
                RepositoryUrlMiddle        : buildModel.RepositoryUrlMiddle,
                UdComponentNameBLUI        : buildModel.UdComponentNameBLUI,
                UdComponentNameBLMiddle    : buildModel.UdComponentNameBLMiddle,
                EnableReposAppMidYes       : buildModel.EnableReposAppMidYes,
                EnableRepositoryBLUI       : buildModel.EnableRepositoryBLUI,
                EnableRepositoryBLMiddle   : buildModel.EnableRepositoryBLMiddle,
                EnableRepositoryBLData     : buildModel.EnableRepositoryBLData,
                
                EnableJenDeployPackageUI: buildModel.EnableJenDeployPackageUI,
                //DeployPackageToolUI: buildModel.DeployPackageToolUI,
                DeployPackageUserIdUI: buildModel.DeployPackageUserIdUI,
                DeployPackagePasswordUI: buildModel.DeployPackagePasswordUI,
                DeployPackageUrlUI: buildModel.DeployPackageUrlUI,
                NexusGroupUI: buildModel.NexusGroupUI,
                PackageVersionUI: buildModel.PackageVersionUI,
                Noinstance: buildModel.Noinstance,
                DockerportNumber: buildModel.DockerportNumber,
                Kubernetes: buildModel.Kubernetes,   
                //EnableJenDeployPackageMiddle: buildModel.EnableJenDeployPackageMiddle,
                DeployPackageToolMiddle: buildModel.DeployPackageToolMiddle,
                DeployPackageUserIdMiddle: buildModel.DeployPackageUserIdMiddle,
                DeployPackagePasswordMiddle: buildModel.DeployPackagePasswordMiddle,
                DeployPackageUrlMiddle: buildModel.DeployPackageUrlMiddle,
                BuildPipeline: buildModel.PipelineData,               
                
                EnableDockerFileUI : buildModel.EnableDockerFileUI,
                DockerFilePathUI : buildModel.DockerFilePathUI
                //StgName : buildModel.StgName,
                //StgDisp : buildModel.StgDisp
            }
        }).exec();
        res.send(constants.SUCCESS_LOWERCASE);
    },
    
    //Get Specific job build details
    GetBuildDefinitions : function (req, res) {
        var method = "GetBuildDefinitions";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';       
        
        var buildModel = JSON.parse(eval(buildModelParam));
       
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetBuildDetails(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetBuildActivities : function (req, res) {
        var method = "GetBuildActivities";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel=  buildModelArray['pipeLineModelParam'];
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        var deployFactory = factory.prototype.GetDeployToolObj("UDeploy");
        if (buildModel.StageType == "Build") {
            buildFactory.GetBuildActivities(buildModel, pipeLineModel, function (error, resultdata) {
                if (error != null) {
                   var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "GetBuildActivities-Build", SourceFile : SourceFileName };
                    customlogger.error({ loginfo: loginfo });
                    res.send(error);
                }
                else {
                    res.send(resultdata);
                }
            });
        }
        else {
            deployFactory.GetBuildActivities(buildModel, function (error, resultdata) {
                if (error != null) {
                   var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "GetBuildActivities-NonBuild", SourceFile : SourceFileName };
                    customlogger.error({ loginfo: loginfo });
                    res.send(error);
                }
                else {
                    res.send(resultdata);
                }
            });
        }
    },
    
    GetStageActivities : function (req, res) {
        var method = "GetStageActivities";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel = buildModelArray['pipeLineModelParam'];
        var buildServerTool = buildModel.BuildServerTool;
        var result = [];
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
       
        buildFactory.GetStageActivities(buildModel, pipeLineModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                result = resultdata;
                res.send(result);
            }
        });
    },
    
    GetStageStatus : function (req, res) {
        var method = "GetStageStatus";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel = buildModelArray['pipeLineModelParam'];
        // Get the build model
        //var buildModel = JSON.parse(buildModelParam);
        //var pipeLineModel = JSON.parse(pipeLineModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        var result = [];
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        //var deployFactory = factory.prototype.GetDeployToolObj("UDeploy");
        
        buildFactory.GetStageStatus(buildModel, pipeLineModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                result = resultdata;
                //deployFactory.GetStageStatus(buildModel, function (error, resultdata) {
                //    if (error != null) {
                //        res.send(error);
                //    }
                //    else {
                //        for (var i = 0; i < resultdata.length; i++) {
                //            result[result.length] = resultdata[i];
                //        }
                //        //res.send(result);
                //    }
                //});
                res.send(result);
            }
        });
    },
    
    GetStageStatusCM : function (req, res) {
        var method = "GetStageStatusCM";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetStageStatusCM(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: "GetStageStatusCM", SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetBuildReports : function (req, res) {
        var method = "GetBuildReports";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel = buildModelArray['pipeLineModelParam'];

        var stage = buildModelArray['stage'];

        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetReportDetails(stage, buildModel, pipeLineModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  { message: error,sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetBuildTestResults : function (req, res) {
        var method = "GetBuildTestResults";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel = buildModelArray['pipeLineModelParam'];

        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetBuildTestResults(buildModel, pipeLineModel, function (error, resultdata) {
            //
            if (error != null) {
               var loginfo =  { message: error,sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetActivityDetails : function (req, res) {
        var method = "GetActivityDetails";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel = buildModelArray['pipeLineModelParam'];

        var stage = buildModelArray['stage'];

        var buildFactory = factory.prototype.GetBuildToolObj(buildModel.BuildServerTool);
        
        buildFactory.GetActivityDetails(stage, buildModel, pipeLineModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  { message: error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetRiskAnalysisDetails : function (req, res) {
        var method = "GetRiskAnalysisDetails";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var buildModel = buildModelArray['buildModelParam'];
        var pipeLineModel = buildModelArray['pipeLineModelParam'];

        var stage = buildModelArray['stage'];
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetRiskAnalysisDetails(stage, buildModel, pipeLineModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  { message: error,sessionID: req.sessionID, levelName: "error" , methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    //Get all CM details
    GetCMDetails : function (req, res) {
        var method = "GetCMDetails";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            CMDetails: saveuserModel.find().execAsync(),
        })
            .then(function (results) {
            //customlogger.info(constants.GETCMDETAILS_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
          .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetCMConfigurationDetails : function (req, res) {
        var method = "GetCMConfigurationDetails";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var SelectedApplication = JSON.parse(req.query['ApplicationName']);
        
        promise.props({
            CMConfigurationDetailsData: cmconfigModel.find({ ApplicationName: SelectedApplication }).execAsync()
        })
            .then(function (results) {
           //customlogger.info(constants.GETCMCONFIGDETAILS_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetCMConfigurations : function (req, res) {
        var method = "GetCMConfigurations";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            CMConfigurationDetails: cmconfigModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, _id: 0 }).execAsync()
        })
            .then(function (results) {
           //customlogger.info(constants.GETCMCONFIG_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
           .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    EditCMConfigurationMongo: function (req, res) {
        var method = "EditCMConfigurationMongo";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = req.body.CMConfigurationData;
        
        var buildModel = JSON.parse(buildModelParam);
        
        if (buildModel.BuildServerTool.toolname == constants.JENKINS) {
            var buildurl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
            var objJenkinsConfigXml = new createjobconfigxml;
            
            // Generate config xml 
            objJenkinsConfigXml.Generate_Build_Config_XML(buildurl, buildModel);
            cmconfigModel.update({ ApplicationName: buildModel.ApplicationName }, {
                $set: {
                    BuildServerTool: buildModel.BuildServerTool.toolname,
                    DeployServerTool: buildModel.DeployServerTool.toolname,
                    ApplicationName: buildModel.AppName,
                    BuildServerName: buildModel.BuildServerName,
                    BuildServerPort: buildModel.BuildServerPort,
                    //BuildServerUserId: buildModel.BuildServerUserId,
                    //BuildServerPassword: buildModel.BuildServerPassword,
                    AllStagesList : buildModel.AllStagesList
                }
            }).exec();
        }
        else {
            
            cmconfigModel.update({ ApplicationName: buildModel.ApplicationName }, {
                $set: {
                    BuildActivityListUI : buildModel.BuildActivityListUI,
                    BuildReportListUI : buildModel.BuildReportListUI,
                    BuildRiskListUI : buildModel.BuildRiskListUI,
                    BuildItemListUI : buildModel.BuildItemListUI,
                    UnitTestActivityListUI : buildModel.UnitTestActivityListUI,
                    UnitTestReportListUI : buildModel.UnitTestReportListUI,
                    UnitTestResultListUI : buildModel.UnitTestResultListUI,
                    DeployUI : buildModel.DeployUI,
                    DeployActivityListUI : buildModel.DeployActivityListUI,  
                    DeployPackageListUI: buildModel.DeployPackageListUI,
                    DeployApprovalListUI : buildModel.DeployApprovalListUI,
                    DeployInReleaseListUI : buildModel.DeployInReleaseListUI,  
                    DeployMid : buildModel.DeployMid,
                    DeployActivityListMiddle : buildModel.DeployActivityListMiddle,  
                    DeployPackageListMiddle: buildModel.DeployPackageListMiddle,
                    DeployApprovalListMiddle : buildModel.DeployApprovalListMiddle,
                    DeployInReleaseListMiddle : buildModel.DeployInReleaseListMiddle, 
                    BuildActivityListMiddle : buildModel.BuildActivityListMiddle,
                    BuildReportListMiddle : buildModel.BuildReportListMiddle,
                    BuildRiskListMiddle : buildModel.BuildRiskListMiddle,
                    BuildItemListMiddle : buildModel.BuildItemListMiddle,
                    UnitTestActivityListMiddle : buildModel.UnitTestActivityListMiddle,
                    UnitTestReportListMiddle : buildModel.UnitTestReportListMiddle,
                    UnitTestResultListMiddle : buildModel.UnitTestResultListMiddle,
                    
                    BuildReportPathMiddle : buildModel.BuildReportPathMiddle,
                    BuildReportPathUI : buildModel.BuildReportPathUI,
                    ProjectCollectionName: buildModel.ProjectCollectionName,
                    BuildServerUrl : buildModel.BuildServerUrl,
                    DomainName: buildModel.DomainName,
                    ProjectName: buildModel.ProjectName,
                    TFSUserID: buildModel.BuildServerUserID,
                    TFSPassword: buildModel.BuildServerPassword,
                    BuildServerTool: buildModel.BuildServerToolCM.toolname,
                    DeployServerTool: buildModel.DeployServerToolCM.toolname,
                    EnableRiskAnalysisUI: buildModel.EnableRiskAnalysisUI,
                    EnableUnitTestUI: buildModel.EnableUnitTestUI,
                    EnableUnitTestMiddle: buildModel.EnableUnitTestMiddle,
                    MonitorAppTier: buildModel.MonitorAppTier,
                    MonitorMiddleTier: buildModel.MonitorMiddleTier,
                    MonitorDataTier: buildModel.MonitorDataTier
                }
            }).exec();
        }
        
    }, 
    
    GetInReleaseActivities : function (req, res) {
        var method = "GetInReleaseActivities";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
       
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetInReleaseActivities(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  { message: error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetInReleasePackages : function (req, res) {
        var method = "GetInReleasePackages";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetInReleasePackages(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  { message: error,sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    GetInReleaseDeployInfo : function (req, res) {
        var method = "GetInReleaseDeployInfo";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.GetInReleaseDeployInfo(buildModel, function (error, resultdata) {
            
            if (error != null) {
               var loginfo =  { message: error,sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
        });
    },
    
    //Save User data in Mongo DB
    DeleteAcitivity: function (req, res) {
        var method = "DeleteActivity";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var MonitoringDetails = JSON.parse(req.body.CMDataDeleteObject);
        
        saveuserModel.remove({
            "CMDataModel.Tool_NM" : MonitoringDetails.tool_NM, 
            "CMDataModel.Build_url": MonitoringDetails.buildServerURL, "CMDataModel.Port": MonitoringDetails.buildServerPort,
            "CMDataModel.Build_Definition_JobName": MonitoringDetails.teamProject
        }).exec();
    },
    
    GetUdeployApplications : function (req, res) {
        var method = "GetUdeployApplications";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';        
        var buildModel = JSON.parse(eval(buildModelParam));
        
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetUdeployApplications(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    GetUdeployEnvironments : function (req, res) {
        var method = "GetUeployEnvironments";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetUdeployEnvironments(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    GetUdeployApplProcesses : function (req, res) {
        var method = "GetUdeployApplProcesses";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;        
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        var buildModel = JSON.parse(buildModelParam);
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetUdeployApplProcesses(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    GetUdeployResources : function (req, res) {
        var method = "GetUdeployResources";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;        
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        var buildModel = JSON.parse(buildModelParam);
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetUdeployResources(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    GetUdeployComponents : function (req, res) {
        var method = "GetUdeployComponents";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetUdeployComponents(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    GetUdeployComponentProcesses : function (req, res) {
        var method ="GetUdeployComponentProcesses";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;        
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModel = JSON.parse(eval(buildModelParam));
        var buildModel = JSON.parse(buildModelParam);
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetUdeployComponentProcess(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });
    },
    
    //Delete build definition
    CMConfigurationApi : function (req, res) {
        var method = "CMConfigurationApi";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        var apiType = req.body.apiType;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var buildServerTool = buildModel.BuildServerTool;
        
        //buildServerTool = "Jenkins";//buildModel.BuildServerToolCM.toolname;
        
        var buildFactory = factory.prototype.GetBuildToolObj(buildServerTool);
        
        buildFactory.CMConfigurationApi(apiType, buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
                res.send(error);
            }
            else {
                res.send(resultdata);
            }
           
        });


    },
    
    CreateUDeployConfigXML: function (req, res) {
        var method = "CreateUDeployConfigXML";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName  };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;
        var buildModelParam = req.body.buildModelParam;
        // Get the build model
        var buildModel = JSON.parse(buildModelParam);
        var deployServerTool = buildModel.DeployServerTool;
        
        var buildFactory = factory.prototype.GetDeployToolObj(deployServerTool.toolname);
        
        buildFactory.CreateUDeployConfigXML(buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
               var loginfo =  { message: error,sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }

        });
    },
    
    GetInitialData : function (req, res) {
        var method = "GetInitialData";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        promise.props({
            buildServerTools: toolslookupModel.find({ toolgroup: 'ContIntegration' }).execAsync(),
            deployServerTools: toolslookupModel.find({ toolgroup: 'CD' }).execAsync(),                        
            buildServerDetails: builddefnModel.findOne({ BuildServerTool: 'Jenkins' }, { BuildServerName: 1, BuildServerPort: 1, BuildServerUserID: 1, BuildServerPassword: 1, BuildServerTool: 1, InstalledPath: 1, ProjectFolderMiddle: 1, ApplicationName: 1, ProjectFolderUI: 1, _id: 0 }).execAsync(),
            buildDefinitionDetails: cmconfigModel.find({ ApplicationName: { $ne: ' ' } }, { ApplicationName: 1, _id: 0 }).execAsync(),
        })
        .then(function (results) {
            
           //customlogger.info(constants.GETALLTOOLS_DATA_RETRIEVE_SUCCESS_MSG);
            res.send(results);
        })
        .catch(function (err) {
            var loginfo = { message: err, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
            customlogger.error({ loginfo: loginfo });
            //customlogger.info(constants.GETAPP_DATA_RETRIEVE_ERROR_MSG);
            res.send(err);
        });
    },
    
    GetComputerNameByAgent: function (req, res) {
        var method = "GetComputerNameByAgent";
        if (constants.TRACE_ENABLED) {
            var loginfo = { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;        
        // Get the build model
        var buildModelParam = '\'' + querystring.unescape(req.url).split('?')[1] + '\'';
        var buildModelArray = JSON.parse(eval(buildModelParam));
        var agentId = buildModelArray['agentId'];
        var buildModel = buildModelArray['buildModelParam'];        
        var deployServerTool = buildModel.DeployServerTool;
        
        var deployFactory = factory.prototype.GetDeployToolObj(deployServerTool);
        
        deployFactory.GetComputerNameByAgent(agentId, buildModel, function (error, resultdata) {
            ////debugger;
            if (error != null) {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
            }
            else {
                res.send(resultdata);
            }

        });
    },

    GetCICDJobType: function (req, res) {
        var method = "GetCICDJobType";
        if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName };
             customlogger.trace({ loginfo: loginfo });
        }
        ////debugger;        
        // Get the build model
        var buildDefinitionNames = req.params.buildDefinitionNames;
        var deployConfigDetails = req.params.deployConfigDetails;

        res.send(buildDefinitionNames);

    },
    
    //Log Data function to create log for the files with trace in seperate file and errors in seperate file
    LogData: function (req, res) {
        var logDetails = [];
        logDetails = JSON.parse(req.params.logdetails);
        logDetails['SessionID'] = req.sessionID;
        var message = logDetails.message;
       //If level is trace
        if (logDetails.levelName == "trace") {
            customlogger.trace({ loginfo: logDetails });
        }
        //If level is error
        if (logDetails.levelName == "error") {
            customlogger.error({ loginfo: logDetails });
        }
        customlogger.error(message);
        res.send(null);
    },



   BuildDockerImage: function (req, res) {
      var method = "BuildDockerImage";
        //if (constants.TRACE_ENABLED) {
           var loginfo =  { sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile : SourceFileName};
             customlogger.trace({ loginfo: loginfo });
        //}
	   var FolderName= req.query.FolderName;
           var Nexusurl= req.query.Nexusurl;
	   var Dockerurl= req.query.Dockerurl;
           var Packagename= req.query.Packagename;
           var Dockername = req.query.DockerName ;
           var Imagename= req.query.ImageName;
           var Imagerepo= req.query.ImageRepo;

     
       var buildFactory = containerizationFactory.prototype.GetContainerizationToolObj(constants.DOCKER);
       buildFactory.BuildDockerImage(FolderName, Nexusurl,Dockerurl,Packagename,Dockername ,Imagename,Imagerepo, function (error, resultdata) {

           
         if (error != null && error != "") {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
                return;

            }
            else {
                if (resultdata == "" || resultdata == undefined || resultdata == true  ) {
                    res.send(resultdata);
                }              
           }

           
        });
     },



   BuildContainerUsingKubernetes: function(req, res) {
       var method = "BuildContainerUsingKubernetes";
console.log( "inside routedata");

       //if ( constants.TRACE_ENABLED) {
           var loginfo = {sessionID: req.sessionID, levelName: "trace", methodName: method, SourceFile: SourceFileName };
           customlogger.trace({ loginfo: loginfo });
       //}

	   var DockerImageurl = req.query.imageurl ;
           var packagename= req.query.packagename;
           var applicationname= req.query.applicationname;
	   var stagename = req.query.namespace;
           var port = req.query.port;


       var buildFactory = containerizationFactory.prototype.GetContainerizationToolObj(constants.DOCKER);
       buildFactory.BuildContainerUsingKubernetes(DockerImageurl,   stagename, packagename,  applicationname ,port, function (error, resultdata) {
     
       if (error != null && error != "") {
               var loginfo =  {message:error, sessionID: req.sessionID, levelName: "error", methodName: method, SourceFile : SourceFileName };
                customlogger.error({ loginfo: loginfo });
                res.send(error);
                return;

            }
            else {
                if (resultdata == "" || resultdata == undefined || resultdata == true  ) {
                    res.send(resultdata);
                }
              // console.log(resultdata );

		callback(error, resultdata);
		return;
            }
           
        });
   }


    

};