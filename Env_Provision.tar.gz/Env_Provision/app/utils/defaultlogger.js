﻿var winston = require('winston');
winston.emitErrs = true;

var logger = new winston.Logger({
    transports: [
        new winston.transports.File({
            name: 'info-file',   
            level: 'info',
            filename: './logs/all-logs.log',            
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: false
        })       
    ],
    
    exceptionHandlers: [
        new winston.transports.File({
            filename: './logs/exceptions.log'
        })
    ],
    
    exitOnError: false
});

module.exports = logger;
module.exports.stream = {
    write: function (message, encoding) {
        logger.info(message);
    }
};
