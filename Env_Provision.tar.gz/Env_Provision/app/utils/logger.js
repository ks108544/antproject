﻿
//  "fatal"(60): The service/app is going to stop or become unusable now. An operator should definitely look into this soon.
//  "error" (50): Fatal for a particular request, but the service / app continues servicing other requests.An operator should look at this soon(ish).
//  "warn"(40): A note on something that should probably be looked at by an operator eventually.
//  "info" (30): Detail on regular operation.
//  "debug" (20): Anything else, i.e. too verbose to be included in "info" level.
//  "trace" (10): Logging from external libraries used by your app or very detailed application logging.
//Time of the event in ISO 8601 Extended Format format and in UTC


//Check the folder if Exist else create a folder.


var env = require('get-env')();
if (env === 'dev' || env === 'development' || env === '') {
    
    var constants = require('../../config/serviceconstants.js');
    
    
} else if (env === 'prod' || env === 'production') {
     
    var constants = require('../../config/serviceconstants.min.js');
   
}
var fs = require('fs');
var dir = constants.LOG_SHARE;

if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
}
var customlogger = require('bunyan');
 //Hostname ,Pid,Msg should be removed from bunyan.js library if not required
 
var logPath = constants.LOG_SHARE+'/applogging.log';
var errorlogPath = constants.LOG_SHARE +'/errorlogging.log';
 
var logger = new customlogger({
    name: 'logger',
     
    streams: [
         
        {
            level: 'error',
            path: errorlogPath,
            type: 'rotating-file',
            period: '1d',  
            gzip: true,
            count: 15
        },
         {
            level: 'trace',
            path: logPath,
            type: 'rotating-file',
            period: '1d',  
            gzip: true,
            count: 15
            
            
        }
    ] 
    
});
 
module.exports = logger;