﻿var winston = require('winston');
winston.emitErrs = true;

var customLogger = new (winston.Logger)({
    transports: [
        new (winston.transports.File)({
            name: 'info-file',   
            level: 'info',
            filename: './logs/all-logs.log',            
            json: true,
            maxsize: 5242880, //5MB
            maxFiles: 5,
            colorize: false
        })
    ]
});

module.exports = customLogger;
module.exports.stream = {
    write: function (message, encoding) {
        customLogger.info(message);
    }
};