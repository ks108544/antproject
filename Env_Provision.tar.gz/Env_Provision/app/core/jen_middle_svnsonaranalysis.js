﻿function fn_middle_svnsonaranalysis() {
    this.middle_svnsonaranalysis_json = {
        _name : 'project',
        _content : 
 [
            {
                _name : 'keepDependencies',
                _content : 'false'
            },
            {
                _name : 'scm',
                _content : {},
                _attrs : { 'class': 'hudson.scm.NullSCM' }
            },
            {
                _name : 'canRoam',
                _content : 'true'
            },
            {
                _name : 'disabled',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenDownstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenUpstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'jdk',
                _content : '(Inherit From Job)'
            },
            {
                _name : 'triggers',
                _content : {},
                _attrs : { 'class' : 'vector' }
            },
            {
                _name : 'concurrentBuild',
                _content : 'false'
            },
            {
                _name : 'customWorkspace',
                _content : 'C:\\jenkins_instdir\\jobs\\NerddinnerWS_Subversion\\workspace'
            },
            {
                _name : 'builders',
                _content : 
 [
                    {
                        _name : 'hudson.plugins.sonar.SonarRunnerBuilder',
                        _content: [
                            {
                                _name: 'project',
                                _content : 'C:/jenkins_instdir/jobs/NerddinnerWS_Subversion/workspace/sonar-project.properties'
                            },
                            {
                                _name : 'sonarRunnerName',
                                _content : 'SonarRunner'
                            }
                        ],
                        _attrs : { 'plugin' : 'sonar' }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'copy NUL Sonar.txt'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'xcopy'
                        }
                    }
                ]
            }
        ]

    }
};
		
module.exports = fn_middle_svnsonaranalysis;