﻿var env = require('get-env')();

var request = require('request');
var fs = require('fs');
var http = require('http');
var path = require('path');

if (env === 'dev' || env === 'development' || env === '') {
    var constants = require('../../config/serviceconstants.js');
}
else if (env === 'prod' || env === 'production') {
    var constants = require('../../config/serviceconstants.min.js');
}

function JenkinsJobConfigXML() {
    
    // XML Building using ElementTree module
    var et = require('elementtree');
    var XML = et.XML;
    var ElementTree = et.ElementTree;
    var element = et.Element;
    var subElement = et.SubElement;
    var etree;
    var xmlData, toolIndex;
    
    this.Generate_Job_Config_XML = function (buildurl, buildModel) {
        
        var filePath = path.join(__dirname, '../../config', 'Metadata.xml');
        var xml2js = require('xml2js');
        var parser = new xml2js.Parser();
        var configxml = "";
        var fileData;
        var jobconfigfilePath = "";   
        
        
        try {
            
            var fileData = fs.readFileSync(filePath, 'ascii');
            
            parser.parseString(fileData, function (err, result) {
                xmlData = result;
            });
            
            
            //Searching index for TFS tool
            for (toolIndex = 0; toolIndex < xmlData.Metadata.Tool.length; toolIndex++) {
                if (xmlData.Metadata.Tool[toolIndex].Name[0] == constants.JENKINS_CAPS) {
                    break;
                }
            }
            
            jobconfigfilePath = path.join(__dirname, '../../config', 'JenkinsJobConfiguration.xml');
            var exists = fs.existsSync(jobconfigfilePath);
            if (!exists) {
                var jobconfigroot, jenkinsurl, jobinfo;
                
                jobconfigroot = element('JobConfiguration');
                
                jenkinsurl = subElement(jobconfigroot, constants.JENKINSURL);
                jenkinsurl.text = buildurl;
                
                jobinfo = subElement(jobconfigroot, constants.JOBINFORMATION);
                
                etree = new ElementTree(jobconfigroot);
                configxml = etree.write({ 'xml_declaration': true });
            }
            
            var data, fd, mainjob, isexists;
            
            if (etree == undefined || etree == '') {
                //data = fs.readFileSync(jobconfigfilePath, 'ascii').toString();
                fd = fs.openSync(jobconfigfilePath, 'a');
                data = fs.readFileSync(jobconfigfilePath).toString();
                etree = et.parse(data);
            }
            
            mainjob = etree.findall('*/Job/JobName');
            isexists = false;
            for (var i = 0; i < mainjob.length; i++) {
                if (buildModel.Servicetype == "CI") {
                    if (mainjob[i].text.indexOf(buildModel.ApplicationName) > -1) {
                        isexists = true;
                        this.Get_XML_String(buildModel, function (result) {
               
                        });
                        
                        configxml = etree.write();
                        fs.writeFileSync(jobconfigfilePath, configxml);
                    
                        data = fs.readFileSync(jobconfigfilePath).toString();
                        
                        var DOMParser = require('xmldom').DOMParser;
                        var doc = new DOMParser().parseFromString(data, 'text/xml');
                        
                        var childNod = doc.getElementsByTagName(constants.JOB)[i];
                        childNod.parentNode.removeChild(childNod);
                        
                        fs.writeFileSync(jobconfigfilePath, doc);
                        
                        break;
                    }
                }
                else if (buildModel.Servicetype == "CD") {
                    if (mainjob[i].text.indexOf(buildModel.CDApplicationName) > -1) {
                        isexists = true;
                        this.Get_XML_String_CD(buildModel, function (result) {
               
                        });

                        configxml = etree.write();
                        fs.writeFileSync(jobconfigfilePath, configxml);
                
                        data = fs.readFileSync(jobconfigfilePath).toString();
                        
                        var DOMParser = require('xmldom').DOMParser;
                        var doc = new DOMParser().parseFromString(data, 'text/xml');
                        
                        var childNod = doc.getElementsByTagName(constants.JOB)[i];
                        childNod.parentNode.removeChild(childNod);
                        
                        fs.writeFileSync(jobconfigfilePath, doc);
                        
                        break;
                    }
                }             
            }
            
            if (!isexists) {
                
                if (buildModel.Servicetype == "CD") {
                    this.Get_XML_String_CD(buildModel, function (result) {
               
                    });
                }
                else {
                    this.Get_XML_String(buildModel, function (result) {
               
                    });

                }
                
                configxml = etree.write();
                fs.writeFileSync(jobconfigfilePath, configxml);
            }
            
            
            if (fd != undefined && fd != '') {
                fs.closeSync(fd);
            }
        }
        catch (ex) {
        }
    },

    this.Get_XML_String = function (buildModel, callback) {
         //debugger;
        var jobInformation, job,service, cijobname,pipelines, pipeline, stageactivities, activitytrackings, pipeactivities, pipereports, piperisks, pipeitems, pipeuinttests, child, parent;
        
        //Constructing Report Server URL
        var ReportServer = 'http://' + buildModel.BuildServerName + ':8082';
        var SonarReportURL = 'http://' + buildModel.BuildServerName + ':' + constants.SONAR_REPORT_PORT;
        
        jobInformation = etree.find('./JobInformation');
        job = subElement(jobInformation, constants.JOB);
      
        
        //First Lavel Elements
        //-------------------------------------------------
        child = subElement(job, 'Application');
        child.text = buildModel.ApplicationName;
        child = subElement(job, 'JobName');
        child.text = buildModel.ApplicationName;
        child = subElement(job, 'JobType');
        child.text = "MainJob";
        child = subElement(job, 'ServiceType');
        child.text = "CI";          //buildModel.ServiceType;
        service = subElement(job, 'CI');
        child = subElement(service, 'CIJobName');
        child.text = buildModel.ApplicationName;
        //Pipe Line View
        //---------------------------------------------------------
        pipelines = subElement(service, 'PipeLines');
        
        for (var i = 0; i < xmlData.Metadata.Tool[toolIndex].CI[0].Services.length; i++) {
            
            //--------------- Build ------------------------- 
            
            if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Stage[0] == constants.BUILD) {
                
                if ((buildModel.ItemsToBuildUI != "") || (buildModel.ItemsToBuildMiddle != "")) {
                    
                    //Pipe Line
                    //---------------------------------------------------------
                    pipeline = subElement(pipelines, 'PipeLine');
                    
                    //Middle Level Pipe Line view : Stage Build
                    //-----------------------------------------------------------
                    child = subElement(pipeline, 'Stage');
                    child.text = constants.BUILD;
                    
                    child = subElement(pipeline, 'Type');
                    child.text = constants.BUILD;
                    
                    //Stage Activities
                    //-------------------------------------------
                    stageactivities = subElement(pipeline, constants.ACTIVITIES);
                    
                    //Detail view : ActivityTrackings---------------------
                    //----------------------------------------------------
                    activitytrackings = subElement(pipeline, constants.ACTIVITYTRACKINGS);
                    
                    var indx = 1;
                    for (var j = 0; j < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service.length; j++) {
                        
                        //ActivityTracking : Creating Type "Activity"
                        //--------------------------------------------
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.ACTIVITY) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.ACTIVITY;
                            pipeactivities = subElement(parent, constants.ACTIVITIES);
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity.length; k++) {
                                
                                if (buildModel.EnableAppTier != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.UI 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.BUILD) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UNDERSCORE + constants.UISUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UNDERSCORE + constants.UISUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                if (buildModel.EnableMiddleTier != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.MT 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.BUILD) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLESUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLESUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                            }  // End of k for loop
                        } //End of if - Activity               
                        
                        //ActivityTracking : Creating Type "Risk"
                        //--------------------------------------------
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.RISK) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.RISK;
                            piperisks = subElement(parent, 'Risks');
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk.length; k++) {
                                
                                // UI Risk
                                if (buildModel.UITierAppType == ".NET" && buildModel.EnableAppTier == true && buildModel.EnableRiskAnalysisUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Type == constants.RISK_ANALYSIS) {
                                    
                                    child = subElement(piperisks, 'Risk');
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Directory);
                                    child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Name);
                                    child.set('Text', '');
                                }
                                
                                //Middle Tier Risk
                                if (buildModel.BusinessTierAppType == ".NET" && buildModel.EnableRiskAnalysisMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Application == "MT" 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Type == constants.RISK_ANALYSIS) {
                                    
                                    child = subElement(piperisks, 'Risk');
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Directory);
                                    child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Risks[0].Risk[k].$.Name);
                                    child.set('Text', '');
                                }

                            } // End of k for loop
                        } //End of if - Risk
                    
                    ////ActivityTracking : Creating Type "Item"
                    ////--------------------------------------------
                    //if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == "Item") {
                        
                    //    parent = subElement(activitytrackings, 'ActivityTracking');
                    //    child = subElement(parent, 'Type');
                    //    child.text = "Item";
                    //    pipeitems = subElement(parent, 'Items');
                            
                    //    for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Items[0].Item.length; k++) {
                                
                    //        // UI Item
                    //        if (buildModel.BuildOutputFolder != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Items[0].Item[k].$.Application == "UI") {
                                    
                    //            child = subElement(pipeitems, 'Item');                                
                    //            child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Items[0].Item[k].$.DisplayText);
                    //            child.set('Value', buildModel.BuildOutputFolder + '\\' + buildModel.BuildDefinitionName + "_UI");
                    //        }
                                
                    //        //Middle Tier Item
                    //        if (buildModel.BuildOutputFolder != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Items[0].Item[k].$.Application == "MT") {
                                    
                    //            child = subElement(pipeitems, 'Item');
                    //            child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Items[0].Item[k].$.DisplayText);
                    //            child.set('Value', buildModel.BuildOutputFolder + '\\' + buildModel.BuildDefinitionName + "_MT");
                    //        }

                    //    } // End of k for loop
                    //} //End of if - Item

                    }// End of j for loop
                }
            }//End of if - Build
            
            
            //--------------- Unit Testing ------------------------- 
            
            if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Stage[0] == constants.UNIT_TESTING) {
                
                if ((buildModel.EnableUnitTestUI != "") || (buildModel.EnableUnitTestMiddle != "")) {
                    //Pipe Line
                    //---------------------------------------------------------
                    pipeline = subElement(pipelines, 'PipeLine');
                    
                    //Middle Level Pipe Line view : Stage Unit Testing
                    //-----------------------------------------------------------
                    child = subElement(pipeline, 'Stage');
                    child.text = constants.UNIT_TESTING;
                    
                    child = subElement(pipeline, 'Type');
                    child.text = constants.BUILD;
                    
                    //Stage Activities
                    //-------------------------------------------
                    stageactivities = subElement(pipeline, constants.ACTIVITIES);
                    
                    //Detail view : ActivityTrackings---------------------
                    //----------------------------------------------------
                    activitytrackings = subElement(pipeline, constants.ACTIVITYTRACKINGS);
                    
                    var indx = 1;
                    for (var j = 0; j < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service.length; j++) {
                        
                        //ActivityTracking : Creating Type "Activity"
                        //--------------------------------------------
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.ACTIVITY) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.ACTIVITY;
                            pipeactivities = subElement(parent, constants.ACTIVITIES);
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity.length; k++) {
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableUnitTestUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.UI 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.UNITTEST) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UISUBVERSION_UNITTEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UISUBVERSION_UNITTEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableUnitTestUI == true && buildModel.UnitTestThresholdValueUI != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.UI 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.UNITTESTRESULT) {
                                                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);                                 
                                    child.set('Name', buildModel.ApplicationName + constants.UISUBVERSION_UNITTEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableCodeCoverageUI == true && buildModel.CodeCoverageThresholdUI != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.UI 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.CODE_COVERAGES) {
                                                         
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);                                
                                    child.set('Name', buildModel.ApplicationName + constants.UISUBVERSION_UNITTEST);                                    
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                if (buildModel.EnableMiddleTier == true && buildModel.EnableUnitTestMiddle != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.MT 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.UNITTEST) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLESUBVERSION_UNITTEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLESUBVERSION_UNITTEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                if (buildModel.EnableMiddleTier == true && buildModel.EnableUnitTestMiddle == true && buildModel.UnitTestThresholdValueMiddle != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.MT 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.UNITTESTRESULT) {
                                                                      
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);                                
                                    child.set('Name', '');
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', 'Unit Test(MT)');
                                    indx++;
                                }
                                
                                if (buildModel.EnableMiddleTier == true && buildModel.EnableCodeCoverageMiddle == true && buildModel.CodeCoverageThresholdMiddle != "" && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.MT 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.CODE_COVERAGES) {
                                                                     
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);                                  
                                    child.set('Name', '');
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', 'Code Coverage(MT)');
                                    indx++;
                                }

                            }  // End of k for loop
                        }//End of if - Activity
                        
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.REPORT) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.REPORT;
                            pipereports = subElement(parent, constants.REPORTS);
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report.length; k++) {
                                
                                //UI Reports
                                if (buildModel.EnableAppTier == true && buildModel.EnableCodeCoverageUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.CODE_COVERAGE_UI) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.UITierAppType == "Java"? "index.html" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type);
                                }
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableUnitTestUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.UNIT_TEST_UI) {
                                    
                                    //var temp = new Array();
                                    //temp = buildModel.ItemsToBuildUI.split('/');
                                    //var name = temp[temp.length - 1].split('.')[0] + "TestResults.html";
                                    var temp = "";
                                    temp = buildModel.ProjectFolderUI;
                                    var name = temp + constants.TESTRESULTSHTML;
                                    
                                    
                                    //buildModel.UnitTestReportList.push({
                                    //    Link: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link,
                                    //    Directory: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory,
                                    //    //Name: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name,
                                    //    Name: name,
                                    //    Text: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText
                                    //});
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    //child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Name', name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type);
                                }
                                
                                //Middle Tier Reports
                                if (buildModel.EnableMiddleTier == true && buildModel.EnableCodeCoverageMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                 && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.CODE_COVERAGE_MT) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.BusinessTierAppType == ".NET"? "index.htm" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type);
                                }
                                
                                if (buildModel.EnableMiddleTier == true && buildModel.EnableUnitTestMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.UNIT_TEST_MT) {
                                    
                                    //var temp = new Array();
                                    //temp = buildModel.ItemsToBuildMiddle.split('/');
                                    //var name = temp[temp.length - 1].split('.')[0] + "TestResults.html";
                                    
                                    var temp = "";
                                    temp = buildModel.ProjectFolderMiddle;
                                    var name = temp + constants.TESTRESULTSHTML;
                                    
                                    //buildModel.UnitTestReportList.push({
                                    //    Link: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link,
                                    //    Directory: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory,
                                    //    //Name: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name,
                                    //    Name: name,
                                    //    Text: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText
                                    //});
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    //child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Name', name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type);
                                }
                            } // End of k for loop
                        }//End of if - Report
                        
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.UNITTEST) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.UNITTEST;
                            pipeuinttests = subElement(parent, 'Tests');
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test.length; k++) {
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableUnitTestUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Application == constants.UI) {
                                    
                                    //buildModel.UnitTestResultList.push({
                                    //    Type: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Type,
                                    //    Text: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Text,
                                    //    Tier: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Application
                                    //});
                                    
                                    child = subElement(pipeuinttests, constants.TEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Type);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Text);
                                    child.set('Tier', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Application);
                                }
                                
                                if (buildModel.EnableMiddleTier == true && buildModel.EnableUnitTestMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Application == constants.MT) {
                                    
                                    //buildModel.UnitTestResultList.push({
                                    //    Type: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Type,
                                    //    Text: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Text,
                                    //    Tier: xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Application
                                    //});
                                    
                                    child = subElement(pipeuinttests, constants.TEST);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Type);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Text);
                                    child.set('Tier', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Tests[0].Test[k].$.Application);
                                }
                            }// End of k for loop
                        }//End of if - UnitTest

                    } // End of j for loop
                }
            
            }// End of Main if - Unit Testing
            //--------------- Post Build ------------------------- 
            
            if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Stage[0] == constants.POSTBUILD) {
                
                if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI) 
                   || (buildModel.EnableSonarAnalysisUI) || (buildModel.EnableJenDeployPackageUI) || (buildModel.EnableCodeAnalysisMiddle) || (buildModel.EnableCodeMetricsMiddle) || (buildModel.EnableSecAnalysisMiddle) 
                   || (buildModel.EnableRiskAnalysisMiddle) || (buildModel.EnableSonarAnalysisMiddle)) {
                    
                    //Pipe Line
                    //---------------------------------------------------------
                    pipeline = subElement(pipelines, 'PipeLine');
                    
                    //Middle Level Pipe Line view : Stage Post Build
                    //-----------------------------------------------------------
                    child = subElement(pipeline, 'Stage');
                    child.text = constants.POSTBUILD;
                    
                    child = subElement(pipeline, 'Type');
                    child.text = constants.BUILD;
                    
                    //Stage Activities
                    //-------------------------------------------
                    stageactivities = subElement(pipeline, constants.ACTIVITIES);
                    
                    //Detail view : ActivityTrackings---------------------
                    //----------------------------------------------------
                    activitytrackings = subElement(pipeline, constants.ACTIVITYTRACKINGS);
                    
                    var indx = 1;
                    for (var j = 0; j < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service.length; j++) {
                        
                        //ActivityTracking : Creating Type "Activity"
                        //--------------------------------------------
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.ACTIVITY) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.ACTIVITY;
                            pipeactivities = subElement(parent, constants.ACTIVITIES);
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity.length; k++) {
                                
                                if (buildModel.EnableAppTier == true && ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableSecAnalysisUI) 
                                || (buildModel.EnableRiskAnalysisUI) || (buildModel.EnableJenDeployPackageUI))
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.UI 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.REPORT) {
                                    
                                    var JobName = "";            

                                    if ((buildModel.EnableJenDeployPackageUI) && ((xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText).indexOf('Nexus') > -1)) {
                                        JobName = buildModel.ApplicationName + constants.UISUBVERSION_DEPLOY;
                                        
                                        child = subElement(stageactivities, constants.ACTIVITY);
                                        child.set('Id', indx);
                                        child.set('Name', JobName);
                                        child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                        child.set('AltName', '');
                                        
                                        child = subElement(pipeactivities, constants.ACTIVITY);
                                        child.set('Id', indx);
                                        child.set('Name', JobName);
                                        child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                        child.set('AltName', '');
                                        indx++;                               
                                    }
                                    else if ((xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText).indexOf('Nexus') == -1) {
                                        JobName = buildModel.ApplicationName + constants.UNDERSCORE + constants.UIPUBLISHREPORTS + constants.UNDERSCORE + constants.SUBVERSION;

                                        child = subElement(stageactivities, constants.ACTIVITY);
                                        child.set('Id', indx);
                                        child.set('Name', JobName);
                                        child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                        child.set('AltName', '');
                                        
                                        child = subElement(pipeactivities, constants.ACTIVITY);
                                        child.set('Id', indx);
                                        child.set('Name', JobName);
                                        child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                        child.set('AltName', '');
                                        indx++;                                    
                                    }                                    
                                                                    
                                }
                                
                                if (buildModel.EnableMiddleTier == true && ((buildModel.EnableCodeAnalysisMiddle) || (buildModel.EnableCodeMetricsMiddle) || (buildModel.EnableSecAnalysisMiddle) 
                                || (buildModel.EnableRiskAnalysisMiddle)) 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.MT 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.REPORT) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLEPUBLISHREPORTS_SUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLEPUBLISHREPORTS_SUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                if (buildModel.EnableAppTier == true && (buildModel.EnableSonarAnalysisUI == true) 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.UI 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.SONAR_REPORT) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UIRUNSONARANALYSIS_SUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UIRUNSONARANALYSIS_SUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                
                                if (buildModel.EnableMiddleTier == true && (buildModel.EnableSonarAnalysisMiddle == true) 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Application == constants.MT 
                                && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.Type == constants.SONAR_REPORT) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLERUNSONARANALYSIS_SUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.MIDDLERUNSONARANALYSIS_SUBVERSION);
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                            }  // End of k for loop
                        } //End of if - Activity
                        
                        //ActivityTracking : Creating Type "Report"
                        //--------------------------------------------
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.REPORT) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.REPORT;
                            pipereports = subElement(parent, constants.REPORTS);
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report.length; k++) {
                                
                                // UI Reports
                                if (buildModel.EnableAppTier == true && buildModel.EnableCodeMetricsUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.CODE_METRICS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.UITierAppType == "Java" ? "CodeMetricsReport.html" :  xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableCodeAnalysisUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.STATIC_CODE_ANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.UITierAppType == "Java" ? "checkstyle_report.html" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableSecAnalysisUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.SECURITY_CODE_ANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.UITierAppType == "Java" ? "findbugs-default.html" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableSonarAnalysisUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                 && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.SONARANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? SonarReportURL : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableAppTier == true && buildModel.EnableRiskAnalysisUI == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.UI 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.RISK_ANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                ////Middle Tier Reports
                                if (buildModel.EnableCodeMetricsMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                    && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.CODE_METRICS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.BusinessTierAppType == ".NET" ? "CodeMetricsRpt.html" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableCodeAnalysisMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                 && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.STATIC_CODE_ANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.BusinessTierAppType == ".NET" ? "CodeAnalysisReport.html" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableSecAnalysisMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                 && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.SECURITY_CODE_ANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', buildModel.BusinessTierAppType == ".NET" ? "Report.html" : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }
                                
                                if (buildModel.EnableSonarAnalysisMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                 && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.SONARANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? SonarReportURL : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }

                                if (buildModel.EnableRiskAnalysisMiddle == true && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Application == constants.MT 
                                     && xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Type == constants.RISK_ANALYSIS) {
                                    
                                    child = subElement(pipereports, constants.REPORT);
                                    child.set('Link', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link == "" ? ReportServer : xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Link);
                                    child.set('Directory', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Directory);
                                    child.set('Name', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.Name);
                                    child.set('Text', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Reports[0].Report[k].$.DisplayText);
                                }

                            }  // End of k for loop
                        } //End of if - Report

                    }
                }
            } // End of Post build
            
           //Check for code repo Stage

            if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Stage[0] == constants.CODEREPO) {
                var coderepo = true; // need to be build model
                if (coderepo) {
                    
                    //Pipe Line
                    //---------------------------------------------------------
                    pipeline = subElement(pipelines, 'PipeLine');
                    
                    //Middle Level Pipe Line view : Stage Post Build
                    //-----------------------------------------------------------
                    child = subElement(pipeline, 'Stage');
                    child.text = constants.CODEREPO;
                    
                    child = subElement(pipeline, 'Type');
                    child.text = constants.BUILD;
                    
                    //Stage Activities
                    //-------------------------------------------
                    stageactivities = subElement(pipeline, constants.ACTIVITIES);
                    
                    //Detail view : ActivityTrackings---------------------
                    //----------------------------------------------------
                    activitytrackings = subElement(pipeline, constants.ACTIVITYTRACKINGS);
                    
                    var indx = 1;
                    for (var j = 0; j < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service.length; j++) {
                        
                        //ActivityTracking : Creating Type "Activity"
                        //--------------------------------------------
                        if (xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Type[0] == constants.ACTIVITY) {
                            
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.ACTIVITY;
                            pipeactivities = subElement(parent, constants.ACTIVITIES);
                            
                            for (var k = 0; k < xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity.length; k++) {
                                
                                if (buildModel.EnableAppTier == true || buildModel.EnableMiddleTier == true ) {
                                    
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UNDERSCORE + constants.UISUBVERSION_DEPLOY );
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.ApplicationName + constants.UNDERSCORE + constants.UISUBVERSION_DEPLOY );
                                    child.set('Type', xmlData.Metadata.Tool[toolIndex].CI[0].Services[i].Service[j].Activities[0].Activity[k].$.DisplayText);
                                    child.set('AltName', '');
                                    indx++;
                                }
                                 
                            }  // End of k for loop
                        }  

                        //end of code repo
                    }
                }
            }

        }// End of i for loop
        
        callback(etree);
    },
    
   this.Get_XML_String_CD = function (buildModel, callback) {
        
        //test build model start
        /*buildModel.DeployServerConfigname = 'test';
        buildModel.CDApplicationName = 'testCD';
        buildModel.SelectCIApplication = 'testCI';
        
        var array = [];    
        var platformtable = [];
        var ApplicationTable = [];
        
        platformtable.push({            
             SeqNo: 1,
             PlatformName: 'jdk',
             CookBookPath: 'jdkcookbookpath',
             TargetInventory: 'jdkinventorypath'
        });
        
        ApplicationTable.push({
            SeqNo: 1,
            AppDeployName: 'deploy_app1',
            CookBookPath: 'app1cookbookpath',
            TargetInventory: 'app1inventorypath'
        });        

        array.push({
            StageName: 'DEV',
            EnablePlatformProvisioning: true,
            PlatformProvisioning:
            {
                OperationgSystem               : 'Linux',             
                Platform                       : platformtable,
            },
            EnableApplicationDeployment: true,
           AppDeployment:
            {
                AppRespositoryTool: 'Nexus',
                ApplicationDeploy: ApplicationTable
            }
           
        });
        
        array.push({
            StageName: 'INT',
            EnablePlatformProvisioning: true,
            PlatformProvisioning:
            {
                OperationgSystem               : 'Linux',             
                Platform                       : platformtable,
            },
            EnableApplicationDeployment: true,
            AppDeployment:
            {
                AppRespositoryTool: 'Nexus',
                ApplicationDeploy: ApplicationTable
            }
           
        });        
        
        buildModel.DeployStages = array;*/        
        //test build model end 

        var jobInformation, job, service, pipelines, pipeline, stageactivities, activitytrackings, pipeactivities, child, parent;
        
        jobInformation = etree.find('./JobInformation');
        job = subElement(jobInformation, constants.JOB);    
        
        if ((typeof (buildModel.DeployServerConfigname) != constants.UNDEFINED) && buildModel.DeployServerConfigname != null && buildModel.DeployServerConfigname != constants.EMPTY &&
            (typeof (buildModel.CDApplicationName) != constants.UNDEFINED) && buildModel.CDApplicationName != null && buildModel.CDApplicationName != constants.EMPTY) {
            
            //Check for stages
            if ((typeof (buildModel.DeployStages) != constants.UNDEFINED) && buildModel.DeployStages != null && buildModel.DeployStages.length > 0) {
                                
                //First Level Elements        
                child = subElement(job, 'Application');
                child.text = buildModel.CDApplicationName;
                child = subElement(job, 'JobName');
                child.text = buildModel.CDApplicationName;
                child = subElement(job, 'JobType');
                child.text = "MainJob";
                child = subElement(job, 'ServiceType');
                child.text = "CD";
                service = subElement(job, 'CD');
                child = subElement(service, 'CDJobName');
                child.text = buildModel.CDApplicationName;
                child = subElement(service, 'CIApplication');
                if (buildModel.DeployStages[0].SelectCIApplication != null && buildModel.DeployStages[0].SelectCIApplication != constants.EMPTY) {
                    child.text = buildModel.DeployStages[0].SelectCIApplication;
                }
                else {
                    child.text = constants.EMPTY;
                }
                
                //Pipe Line View        
                pipelines = subElement(service, 'PipeLines');

                // Stage wise            
                for (var i = 0; i < buildModel.DeployStages.length; i++) {
                    pipeline = subElement(pipelines, 'PipeLine');
                    
                    if ((typeof (buildModel.DeployStages[i]) != constants.UNDEFINED) && buildModel.DeployStages[i] != null) {
                        child = subElement(pipeline, 'Stage');
                        child.text = buildModel.DeployStages[i].StageName;
                        
                        var indx = 1;
                        
                        // Platform provisioning 
                        if ((buildModel.DeployStages[i].EnablePlatformProvisioning) && (typeof (buildModel.DeployStages[i].PlatformProvisioning) != constants.UNDEFINED) && buildModel.DeployStages[i].PlatformProvisioning != null &&
                            (typeof (buildModel.DeployStages[i].PlatformProvisioning.Platform) != constants.UNDEFINED) && buildModel.DeployStages[i].PlatformProvisioning.Platform != null && buildModel.DeployStages[i].PlatformProvisioning.Platform.length > 0) {
                            //Activity wise            
                            stageactivities = subElement(pipeline, constants.ACTIVITIES);
                            activitytrackings = subElement(pipeline, constants.ACTIVITYTRACKINGS);
                                
                            parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                            child = subElement(parent, 'Type');
                            child.text = constants.ACTIVITY;
                            pipeactivities = subElement(parent, constants.ACTIVITIES);
                           

                            for (var j = 0; j < buildModel.DeployStages[i].PlatformProvisioning.Platform.length; j++) {
                                if ((typeof (buildModel.DeployStages[i].PlatformProvisioning.Platform[j]) != constants.UNDEFINED) && buildModel.DeployStages[i].PlatformProvisioning.Platform[j] != null) {
                                    //Activity
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName);
                                    child.set('Type', buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName);
                                    child.set('Text', constants.PLATFORMPROVISIONING);
                                    
                                    //Activity tracking
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName);
                                    child.set('Type', buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName);
                                    child.set('Text', constants.PLATFORMPROVISIONING);
                                    indx++;
                                }
                            }

                        }
                        
                        // App Deployment
                        if ((buildModel.DeployStages[i].EnableApplicationDeployment) && (typeof (buildModel.DeployStages[i].AppDeployment) != constants.UNDEFINED) && buildModel.DeployStages[i].AppDeployment != null &&
                            (typeof (buildModel.DeployStages[i].AppDeployment.ApplicationDeploy) != constants.UNDEFINED) && buildModel.DeployStages[i].AppDeployment.ApplicationDeploy != null && buildModel.DeployStages[i].AppDeployment.ApplicationDeploy.length > 0) {
                            
                            if (!(buildModel.DeployStages[i].EnablePlatformProvisioning)) {
                                //Activity wise            
                                stageactivities = subElement(pipeline, constants.ACTIVITIES);
                                activitytrackings = subElement(pipeline, constants.ACTIVITYTRACKINGS);
                                
                                parent = subElement(activitytrackings, constants.ACTIVITYTRACKING);
                                child = subElement(parent, 'Type');
                                child.text = constants.ACTIVITY;
                                pipeactivities = subElement(parent, constants.ACTIVITIES);
                            }
                            //Repository - Nexus
                            if (buildModel.DeployStages[i].AppDeployment.AppRespositoryTool == constants.NEXUS) {
                                //Activity
                                child = subElement(stageactivities, constants.ACTIVITY);
                                child.set('Id', indx);
                                child.set('Name', buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.ACTIVITY_NEXUS);
                                child.set('Type', constants.ACTIVITY_NEXUS);
                                child.set('Text', constants.NEXUSREPOSITORY);
                                
                                //Activity tracking
                                child = subElement(pipeactivities, constants.ACTIVITY);
                                child.set('Id', indx);
                                child.set('Name', buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.ACTIVITY_NEXUS);
                                child.set('Type', constants.ACTIVITY_NEXUS);
                                child.set('Text', constants.NEXUSREPOSITORY);
                                indx++;
                            }
                            // App deployment
                            for (var k = 0; k < buildModel.DeployStages[i].AppDeployment.ApplicationDeploy.length; k++) {
                                if ((typeof (buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[k]) != constants.UNDEFINED) && buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[k] != null) {
                                    //Activity
                                    child = subElement(stageactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[k].AppDeployName);
                                    child.set('Type', buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[k].AppDeployName);
                                    child.set('Text', constants.APPLICATIONDEPLOYMENT);
                                    
                                    //Activity tracking
                                    child = subElement(pipeactivities, constants.ACTIVITY);
                                    child.set('Id', indx);
                                    child.set('Name', buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[k].AppDeployName);
                                    child.set('Type', buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[k].AppDeployName);
                                    child.set('Text', constants.APPLICATIONDEPLOYMENT);
                                    indx++;
                                }
                            }

                        }

                    }

                }
            }
        }        
        
        callback(etree);        
    },

    this.Generate_Build_Config_XML = function (buildurl, buildModel) {
        
        var filePath = path.join(__dirname, '../../config', 'Metadata.xml');
        var xml2js = require('xml2js');
        var parser = new xml2js.Parser();
        var configxml = "";
        var fileData;
        var jobconfigfilePath = "";
        
        try {
            
            jobconfigfilePath = path.join(__dirname, '../../config', 'JenkinsBuildConfiguration.xml');
            var exists = fs.existsSync(jobconfigfilePath);
            if (!exists) {
                var jobconfigroot, jenkinsurl, jobinfo;
                
                jobconfigroot = element('JobConfiguration');
                
                jenkinsurl = subElement(jobconfigroot, constants.JENKINSURL);
                jenkinsurl.text = buildurl;
                
                jobinfo = subElement(jobconfigroot, constants.JOBINFORMATION);
                
                etree = new ElementTree(jobconfigroot);
                configxml = etree.write({ 'xml_declaration': true });
            }
            
            var data, fd, mainjob, isexists;
            
            if (etree == undefined || etree == '') {
                //data = fs.readFileSync(jobconfigfilePath, 'ascii').toString();
                fd = fs.openSync(jobconfigfilePath, 'a');
                data = fs.readFileSync(jobconfigfilePath).toString();
                etree = et.parse(data);
            }
            
            mainjob = etree.findall('*/Job/JobName');
            isexists = false;
            for (var i = 0; i < mainjob.length; i++) {
                if (mainjob[i].text.indexOf(buildModel.ApplicationName) > -1) {
                    //debugger;
                    isexists = true;
                    this.Get_XML_String_Build(buildModel, function (result) {
               
                    });
                    
                    configxml = etree.write();
                    fs.writeFileSync(jobconfigfilePath, configxml);
                    
                    
                    
                    fd = fs.openSync(jobconfigfilePath, 'a');
                    data = fs.readFileSync(jobconfigfilePath).toString();
                    
                    var DOMParser = require('xmldom').DOMParser;
                    var doc = new DOMParser().parseFromString(data, 'text/xml');
                    
                    var childNod = doc.getElementsByTagName(constants.JOB)[i];
                    childNod.parentNode.removeChild(childNod);
                    
                    fs.writeFileSync(jobconfigfilePath, doc);
                    
                    
                    break;
                }
            }
            
            if (!isexists) {
                
                this.Get_XML_String_Build(buildModel, function (result) {
                //etree = result;
                });
                
                configxml = etree.write();
                fs.writeFileSync(jobconfigfilePath, configxml);
            }
            
            
            if (fd != undefined && fd != '') {
                fs.closeSync(fd);
            }
        }
        catch (ex) {
        }
    },

    this.Get_XML_String_Build = function (buildModel, callback) {
     //debugger;
        if (buildModel.AllStagesList.length > 0) {
            var jobInformation, job, pipelines, pipeline, stageactivities, activitytrackings, pipeactivities, pipereports, piperisks, pipeitems, pipeuinttests, child, parent, reportactivities;
            
            //Constructing Report Server URL
            //var ReportServer = 'http://' + buildModel.BuildServerName + ':8082';
            //var SonarReportURL = 'http://' + buildModel.BuildServerName + ':' + constants.SONAR_REPORT_PORT;
            
            jobInformation = etree.find('./JobInformation');
            job = subElement(jobInformation, constants.JOB);
            
            //First Lavel Elements
            //-------------------------------------------------
            child = subElement(job, 'Application');
            child.text = buildModel.AppName;
            child = subElement(job, 'JobName');
            child.text = buildModel.ApplicationName;
            child = subElement(job, 'JobType');
            child.text = "MainJob";
            
            //Pipe Line View
            //---------------------------------------------------------
            pipelines = subElement(job, 'PipeLines');
            
            for (var i = 0; i < buildModel.AllStagesList.length; i++) {
                
                //--------------- Build ------------------------- 
                
                //Pipe Line
                //---------------------------------------------------------
                pipeline = subElement(pipelines, 'PipeLine');
                
                //Middle Level Pipe Line view : Stage Build
                //-----------------------------------------------------------
                child = subElement(pipeline, 'Stage');
                child.text = buildModel.AllStagesList[i].StgName;
                
                
                
                //Stage Activities
                //-------------------------------------------
                stageactivities = subElement(pipeline, constants.ACTIVITIES);
                
                
                //var indx = 1;
                for (var j = 0; j < buildModel.AllStagesList[i].StageDetails.length; j++) {
                    
                    child = subElement(stageactivities, constants.ACTIVITY);
                    //child.set('Id', buildModel.AllStagesList[i].StageDetails[j].id);
                    child.set('Name', buildModel.AllStagesList[i].StageDetails[j].JobActivity);
                    child.set('DisplayText', buildModel.AllStagesList[i].StageDetails[j].StgDisplayText);
                        
                }// End of i for loop
                
                reportactivities = subElement(pipeline, constants.REPORTS);
                for (var k = 0; k < buildModel.AllStagesList[i].ReportDetails.length; k++) {
                    
                    child = subElement(reportactivities, constants.REPORT);
                    //child.set('Id', buildModel.AllStagesList[i].ReportDetails[k].id);
                    child.set('Report', buildModel.AllStagesList[i].ReportDetails[k].CMReportType);
                    child.set('Tool', buildModel.AllStagesList[i].ReportDetails[k].CMToolType);
                    child.set('Link', buildModel.AllStagesList[i].ReportDetails[k].CMReportLink);
                    child.set('DisplayText', buildModel.AllStagesList[i].ReportDetails[k].CMReportDispText);
                    child.set('Directory', buildModel.AllStagesList[i].ReportDetails[k].CMReportDirPath);
                    child.set('FileName', buildModel.AllStagesList[i].ReportDetails[k].CMReportFileName);
                    child.set('CoverageInput', buildModel.AllStagesList[i].ReportDetails[k].CMReportCoverageInput);
                    child.set('CoverageTool', buildModel.AllStagesList[i].ReportDetails[k].CMReportCoverageTool);
                    child.set('MetricsInput', buildModel.AllStagesList[i].ReportDetails[k].CMReportMetricsInput);
                    child.set('MetricsTool', buildModel.AllStagesList[i].ReportDetails[k].CMReportMetricsTool);
                 
                }
                callback(etree);
            
            }
        }
    }
}

module.exports = JenkinsJobConfigXML;