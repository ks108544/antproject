﻿var env = require('get-env')();

if (env === 'dev' || env === 'development' || env === '') {    
    //Imports from containerizedprov.js
    var env_containerized_prov = require('./env_containerized_prov.js');
    var constants = require('../../config/serviceconstants.js');
} else if (env === 'prod' || env === 'production') {
    //Imports from containerizedprov.min.js
    var env_containerized_prov = require('./env_containerized_prov.min.js');
    var constants = require('../../config/serviceconstants.min.js');
}

//Env provisioning factory class to create respective tool object at runtime
function EnvProvFactory() {
   
};

EnvProvFactory.prototype = {
    GetEnvProvisioningType: function GetEnvProvisioningType(type) {
        if (type == constants.ENV_CONTAINERIZED_PROVISIONING)
            return new env_containerized_prov;     
    }
}

module.exports = EnvProvFactory;