﻿function fn_platform_prov_main() {
    this.platform_prov_main_json = {
        _name: 'com.tikal.jenkins.plugins.multijob.MultiJobProject',
        _content:
 [
            {
            _name : 'keepDependencies',
            _content : 'false'
        },        
            {
            _name : 'scm',
            _content : {},
            _attrs : { 'class' : 'hudson.scm.NullSCM' }
        },
            {
            _name : 'canRoam',
            _content : 'true',
            _attrs : null
        },
            {
            _name : 'disabled',
            _content : 'false',
            _attrs : null
        },
            {
            _name : 'blockBuildWhenDownstreamBuilding',
            _content : 'false',
            _attrs : null
        },
            {
            _name : 'blockBuildWhenUpstreamBuilding',
            _content : 'false',
            _attrs : null
        },
            {
            _name : 'triggers',
            _content : {},
            _attrs : { 'class': 'vector' }
        },
            {
            _name : 'concurrentBuild',
            _content : 'false',
            _attrs : null
        },
            {
            _name : 'builders',
            _content : 
            [                    
                    {
                        _name: 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content:
                            [
                                {
                                    _name: 'phaseName',
                                    _content: 'UI Multijob',
                                    _attrs: null
                                },
                                {
                                    _name: 'phaseJobs',
                                    _content: {
                                        _name: 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                        _content: [
                                                    { _name: 'jobName', _content: 'Platform_Prov_JDK' },
                                                    { _name: 'currParams', _content: 'true' },
                                                    { _name: 'exposedSCM', _content: 'false' },
                                                    { _name: 'configs', _content: {}, _attrs: { 'class': 'empty-list' } }
                                        ]
                                    }
                                },
                                {
                                    _name: 'continuationCondition',
                                    _content: 'COMPLETED'
                                }
                            ]
                    },
                    {
                        _name: 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content:
                            [
                                {
                                    _name: 'phaseName',
                                    _content: 'UI Multijob',
                                    _attrs: null
                                },
                                {
                                    _name: 'phaseJobs',
                                    _content: {
                                        _name: 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                        _content: [
                                                    { _name: 'jobName', _content: 'Platform_Prov_JRE' },
                                                    { _name: 'currParams', _content: 'true' },
                                                    { _name: 'exposedSCM', _content: 'false' },
                                                    { _name: 'configs', _content: {}, _attrs: { 'class': 'empty-list' } }
                                        ]
                                    }
                                },
                                {
                                    _name: 'continuationCondition',
                                    _content: 'COMPLETED'
                                }
                            ]
                    },
                    {
                        _name: 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content:
                            [
                                {
                                    _name: 'phaseName',
                                    _content: 'UI Multijob',
                                    _attrs: null
                                },
                                {
                                    _name: 'phaseJobs',
                                    _content: {
                                        _name: 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                        _content: [
                                                    { _name: 'jobName', _content: 'Platform_Prov_DotNet' },
                                                    { _name: 'currParams', _content: 'true' },
                                                    { _name: 'exposedSCM', _content: 'false' },
                                                    { _name: 'configs', _content: {}, _attrs: { 'class': 'empty-list' } }
                                        ]
                                    }
                                },
                                {
                                    _name: 'continuationCondition',
                                    _content: 'COMPLETED'
                                }
                            ]
                    },
                    {
                        _name: 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content:
                            [
                                {
                                    _name: 'phaseName',
                                    _content: 'UI Multijob',
                                    _attrs: null
                                },
                                {
                                    _name: 'phaseJobs',
                                    _content: {
                                        _name: 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                        _content: [
                                                    { _name: 'jobName', _content: 'Platform_Prov_IIS' },
                                                    { _name: 'currParams', _content: 'true' },
                                                    { _name: 'exposedSCM', _content: 'false' },
                                                    { _name: 'configs', _content: {}, _attrs: { 'class': 'empty-list' } }
                                        ]
                                    }
                                },
                                {
                                    _name: 'continuationCondition',
                                    _content: 'COMPLETED'
                                }
                            ]
                    },
                    {
                    _name : 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                    _content : 
                        [
                            {
                            _name : 'phaseName',
                            _content : 'Middle Multijob',
                            _attrs : null
                            },
                            {
                            _name : 'phaseJobs',
                            _content : {
                            _name : 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                            _content : [
                                        { _name : 'jobName', _content : 'Platform_Prov_Tomcat' },
                                        { _name : 'currParams', _content : 'true' },
                                        { _name : 'exposedSCM', _content : 'false' },
                                        { _name : 'configs', _content : {}, _attrs : { 'class' : 'empty-list' } }
                                    ]
                                }
                            },
                            {
                            _name : 'continuationCondition',
                            _content : 'SUCCESSFUL'
                            }
                        ]
                    }
                ]
            },
            {
            _name : 'properties',
            _content :                     
            {
            }
        }
        ],
        _attrs: { 'plugin' : 'jenkins-multijob-plugin' }
    }
};

module.exports = fn_platform_prov_main;