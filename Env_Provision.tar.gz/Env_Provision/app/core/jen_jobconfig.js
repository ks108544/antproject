﻿var env = require('get-env')();

if (env === 'dev' || env === 'development' || env === '') {
    var jobconfig_repo = require('./jen_jobconfig_sourcecont.js');
    var constants = require('../../config/serviceconstants.js');
} else if (env === 'prod' || env === 'production') {
    var jobconfig_repo = require('./jen_jobconfig_sourcecont.min.js');
    var constants = require('../../config/serviceconstants.min.js');
}

function JenkinsConfig() {
    
    var objjobconfig_repo = new jobconfig_repo;
    
    // UI build job config xml creation
    this.ui_build_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        
        if (buildModel.UITierAppType == constants.DOTNET_UPPER && buildModel.SourceControlTool == constants.SVN) {
            configxml = objjobconfig_repo.ui_svndotnet_build_config(buildModel);
        }
        else if (buildModel.UITierAppType == constants.DOTNET_UPPER && buildModel.SourceControlTool == constants.GIT) {
            configxml = objjobconfig_repo.gitdotnet_build_config(buildModel);
        }
        else if (buildModel.UITierAppType == constants.JAVA && buildModel.SourceControlTool == constants.SVN) {
            if (constants.BUILDTOOL == 'maven' || (buildModel.PackagingFormatUI == constants.JAR)) {
                configxml = objjobconfig_repo.ui_svnjava_build_config_maven(buildModel);
            }
            else {
                configxml = objjobconfig_repo.ui_svnjava_build_config(buildModel);
            }
        }
        else if (buildModel.UITierAppType == constants.JAVA && buildModel.SourceControlTool == constants.GIT) {
            configxml = objjobconfig_repo.gitjava_build_config(buildModel);
        }
        
        return configxml;
    };
    
    // UI unittest job config xml creation
    this.ui_unittest_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        
        if (buildModel.UITierAppType == constants.DOTNET_UPPER) {
            configxml = objjobconfig_repo.ui_dotnet_unittest_config(buildModel);
        }  
        else if (buildModel.UITierAppType == constants.JAVA) {
            configxml = objjobconfig_repo.ui_java_unittest_config(buildModel);
        }
        
        return configxml;
    };
    // UI deploy job config xml creation
    this.ui_deploy_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) || (buildModel.SourceControlTool == constants.GIT)) {
            if (buildModel.UITierAppType == constants.DOTNET_UPPER)
                configxml = objjobconfig_repo.ui_dotnet_deploy_config(buildModel);
            else if (buildModel.UITierAppType == constants.JAVA)
                configxml = objjobconfig_repo.ui_java_deploy_config(buildModel);
        }
        return configxml;
    };
    
    // UI multi job config xml creation
    this.ui_multijob_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) || (buildModel.SourceControlTool == constants.GIT)) {
            if (buildModel.UITierAppType == constants.DOTNET_UPPER)
                configxml = objjobconfig_repo.ui_dotnet_multijob_config(buildModel);
            else if (buildModel.UITierAppType == constants.JAVA)
                configxml = objjobconfig_repo.ui_java_multijob_config(buildModel);
        }
        return configxml;
    };
    
    this.main_multijob_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        configxml = objjobconfig_repo.main_multijob_config(buildModel);
        return configxml;
    };
    
    // UI publish reports job config xml creation
    this.ui_publishreports_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if (buildModel.UITierAppType == constants.DOTNET_UPPER) {
            configxml = objjobconfig_repo.ui_dotnet_publishreports_config(buildModel);
        }
        else if (buildModel.UITierAppType == constants.JAVA) {
            configxml = objjobconfig_repo.ui_java_publishreports_config(buildModel);
        }
        
        return configxml;
    };
    
    // UI sonar analysis job config xml creation
    this.ui_sonaranalysis_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if (buildModel.UITierAppType == constants.DOTNET_UPPER)
            configxml = objjobconfig_repo.ui_dotnet_sonaranalysis_config(buildModel);
        else if ((buildModel.UITierAppType == constants.JAVA))
            configxml = objjobconfig_repo.ui_java_sonaranalysis_config(buildModel);
        
        return configxml;
    };
    
    // Middle tier build job config xml creation
    this.middle_build_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.JAVA))
            configxml = objjobconfig_repo.middle_svnjava_build_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_build_config(buildModel);
        return configxml;
    };
    
    // Middle tier unittest job config xml creation
    this.middle_unittest_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.JAVA))
            configxml = objjobconfig_repo.middle_svnjava_unittest_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_unittest_config(buildModel);
        return configxml;
    };
    
    // Middle tier deploy job config xml creation
    this.middle_deploy_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.JAVA))
            configxml = objjobconfig_repo.middle_svnjava_deploy_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_deploy_config(buildModel);
        return configxml;
    };
    
    // Middle tier publish reports job config xml creation
    this.middle_publishreports_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.JAVA))
            configxml = objjobconfig_repo.middle_svnjava_publishreports_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_publishreports_config(buildModel);
        
        return configxml;
    };
    
    // Middle tier sonar analysis job config xml creation
    this.middle_sonaranalysis_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.JAVA))
            configxml = objjobconfig_repo.middle_svnjava_sonaranalysis_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_sonaranalysis_config(buildModel);
        
        return configxml;
    };
    
    // Middle tier multi job config xml creation
    this.middle_multijob_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.JAVA))
            configxml = objjobconfig_repo.middle_svnjava_multijob_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_multijob_config(buildModel);
        return configxml;
    };
    
    // Data tier job config xml creation
    this.datajob_createconfig = function (buildModel) {
        var configxml = constants.EMPTY;
        if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.DataTierAppType == constants.SQL))
            configxml = objjobconfig_repo.data_svnsql_job_config(buildModel);
        else if ((buildModel.SourceControlTool == constants.SVN) && (buildModel.BusinessTierAppType == constants.DOTNET_UPPER))
            configxml = objjobconfig_repo.middle_svndotnet_multijob_config(buildModel);
        return configxml;
    };
    
    // Download artifacts from nexus job config xml createion
    this.Nexusjob_createconfig = function (buildModel, i) {
        var configxml = constants.EMPTY;
        if (buildModel.Servicetype == constants.CD)
            configxml = objjobconfig_repo.java_nexusdownload_config(buildModel, i);
        return configxml;
    };
    
    // Deploy Ansible playbook for platform provisioning into Ansible server
    this.Deploy_playbook_platformprovisioning_job_config = function (buildModel, subJobType, i) {
        var configxml = constants.EMPTY;
        if (buildModel.Servicetype == constants.CD)
            configxml = objjobconfig_repo.deploy_playbook_platformprovisioning_job_config(buildModel, subJobType, i);
        return configxml;
    };
    
    // Deploy Ansible playbook for application deployment into Ansible server
    this.Deploy_playbook_applicationdeployment_job_config = function (buildModel, jobName, i) {
        var configxml = constants.EMPTY;
        if (buildModel.Servicetype == constants.CD)
            configxml = objjobconfig_repo.deploy_playbook_applicationdeployment_job_config(buildModel, jobName, i);
        return configxml;
    };
    
    // Create platform provisioning main job
    this.platformprovisioning_main_job_config = function (buildModel, i) {
        var configxml = constants.EMPTY;
        var dependentJobs = [];
        var mainJob = constants.EMPTY;
        if (buildModel.Servicetype == constants.CD) {
            if (buildModel.DeployStages[i].PlatformProvisioning.OperatingSystem == constants.LINUX) {
                mainJob = buildModel.CDApplicationName + constants.UNDERSCORE + constants.PLATFORMPROVISIONING + constants.UNDERSCORE + constants.LINUX + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE_MAIN;
            }
            else if (buildModel.DeployStages[i].PlatformProvisioning.OperatingSystem == constants.WINDOWS) {
                mainJob = buildModel.CDApplicationName + constants.UNDERSCORE + constants.PLATFORMPROVISIONING + constants.UNDERSCORE + constants.WINDOWS + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE_MAIN;
            }
            else if (buildModel.DeployStages[i].PlatformProvisioning.OperatingSystem == constants.SOLARIS) {
                mainJob = buildModel.CDApplicationName + constants.UNDERSCORE + constants.PLATFORMPROVISIONING + constants.UNDERSCORE + constants.SOLARIS + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE_MAIN;
            }
            for (var j = 0; j < buildModel.DeployStages[i].PlatformProvisioning.Platform.length; j++) {
                if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.JDK.toUpperCase()) {
                    dependentJobs.push(buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.JDK.toUpperCase());
                }
                else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.JRE.toUpperCase()) {
                    dependentJobs.push(buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.JRE.toUpperCase());
                }
                else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.TOMCAT.toUpperCase()) {
                    dependentJobs.push(buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.TOMCAT.toUpperCase());
                }
                else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.DOCKER.toUpperCase()) {
                    dependentJobs.push(buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.DOCKER.toUpperCase());
                }
                else {
                    dependentJobs.push(buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase());
                }
            }
            configxml = objjobconfig_repo.deploy_mainjob_createconfig(buildModel, dependentJobs, mainJob);
        }
        return configxml;
    };
    
    // Create application deployment main job
    this.application_deployment_main_job_config = function (buildModel, subJobType, i) {
        var configxml = constants.EMPTY;
        var dependentJobs = [];
        var mainJob = constants.EMPTY;
        if (buildModel.Servicetype == constants.CD) {
            if (subJobType == constants.APPDEPLOY) {
                configxml = objjobconfig_repo.application_deployment_main_job_config(buildModel, subJobType, i);
            } else {
                mainJob = buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE_MAIN;
                for (var j = 0; j < buildModel.DeployStages[i].AppDeployment.ApplicationDeploy.length; j++) {
                    jobName = buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[j].AppDeployName;
                    dependentJobs.push(jobName);
                }
                configxml = objjobconfig_repo.deploy_mainjob_createconfig(buildModel, dependentJobs, mainJob);
            }
        }
        return configxml;
    };
    
    // create deployment main job
    this.deploy_mainjob_createconfig = function (buildModel, dependentJobs, mainJob) {
        var configxml = constants.EMPTY;
        if (buildModel.Servicetype == constants.CD)
            configxml = objjobconfig_repo.deploy_mainjob_createconfig(buildModel, dependentJobs, mainJob);
        return configxml;
    };
}
module.exports = JenkinsConfig;