﻿var request = require('request');
var API = '/api/json';
var DELETE = '%s/job/%s/doDelete';
var CONFIG = '%s/job/%s/config.xml';
var JOBINFOAPI = '%s/job/%s' + API;
var util = require('util');
var LIST = '%s' + API;
var env = require('get-env')();
var path = require('path');
//debugger;
if (env === 'dev' || env === 'development' || env === '') {
    var urlbuilder = require('../helper/buildurl.js');
    var constants = require('../../config/serviceconstants.js');
} else if (env === 'prod' || env === 'production') {
    // console.log("jenkins_api  Start ");
    var urlbuilder = require('../helper/buildurl.min.js');
    var constants = require('../../config/serviceconstants.min.js');
   // console.log("jenkins_api  End ");
}
var buildurl = "";
//var exists = false;

function JenkinsAPI() {
    
    this.CreateJob = function (job_config, buildurl, callback) {
        /*
           Create a new job based on a job_config string 
            */         

            request(
            {
                method: 'POST'
                ,url: buildurl
                ,body: job_config
                ,headers: { "content-type": "application/xml" }
            }, 
                
                function (error, response, body) {
                if (error || response.statusCode !== 200) {
                    callback(error || true, response);
                    return;
                }
                var data = body;
                callback(null, data);
            }
        );
    };
    
    this.ModifyJob = function (jobName, jenkinsHostedUrl, configxml, callback) {
        
        var jenkinsnpm = require('jenkins')({ baseUrl: jenkinsHostedUrl , crumbIssuer: true });
        jenkinsnpm.job.config(jobName, configxml, function (err) {
            
            if (err) {
                if (err.notFound == true) {
                    callback(null, null);
                }
                else {
                    callback(err, null);
                }
               
            }
            else {
                callback(null, null);
            }

        });
    };
    this.Deletejobs = function (jobName, jenkinsHostedUrl, callback) {
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        //jenkinsnpm.job.exists(jobName, function (err, exists) {
        
        //    if (err) throw err;
        //    if (exists == true) {
        jenkinsnpm.job.destroy(jobName, function (err) {
            
            if (err) {
                if (err.notFound == true) {
                    callback(null, null);
                }
                else {
                    callback(err, null);
                }
            }
            else {
                callback(null, null);
            }
        });
           // }
        //});
    };
    
    this.BuildJob = function (buildurl, callback) {
        request({ method: 'POST', url: buildurl }, function (error, response) {
            if (error || (response.statusCode !== 201 && response.statusCode !== 302)) {
                callback(error, response);
                return;
            }
            
            var data = response;
            callback(null, '');
        });
    
    };
    
    this.GetConfigXML = function (jobname, buildServerName , buildServerPort, callback) {
        /*
            Get the config xml for a job
            */
        buildurl = urlbuilder.build_url_job(CONFIG, buildServerName, buildServerPort, jobname);
        //    request({ method: 'GET', url: buildurl }, function (error, response, body) {
        //    if (error || response.statusCode !== 200) {
        //        callback(error || true, response);
        //        return;
        //    }
        //    var data = body;
        //    callback(null, data);
        //});
        //var request = require('sync-request');
        //var res = request('GET', buildurl);
        //console.log(res.getBody());
        //callback(null, res.getBody());
        
        
        
        var request = require('request-sync');
        var res = request({ method: 'GET', uri: buildurl });
        //console.log(res.body);
        callback(null, res.body);
    };
    
    //this.UpdateJob = function (jobname, modifyfunction, callback) { 
    //    /*
    //        Copies a job and allows you to pass in a function to modify the configuration
    //        of the job you would like to copy
    //        */
    //    buildurl = urlbuilder.build_url(CONFIG, buildServerName, buildServerPort);
    //        this.get_config_xml(jobname, function (error, data) {
    //        if (error) {
    //            callback(error, data);
    //            return;
    //        }
    //        request({ method: 'POST', url: buildurl, body: modifyfunction(data) }, function (error, response, body) {
    //            if (error || response.statusCode !== 200) {
    //                callback(error || true, response);
    //                return;
    //            }
    //            var data = body;
    //            callback(null, data);
    //        });
    //    });
    //};
    
    this.Deletejob = function (jobname, buildServerName , buildServerPort, buildServerUserID, buildServerPassword, callback) {
        //jenkins version <= 1.5 Rest api for delete doesn't work - use CLI for delete and for version <=1.5 ensure constants.JENKINS_USERNAME is empty
        //jenkins version > 1.5 Rest api works, use URL authenication

        if (buildServerUserID != constants.EMPTY) {
            //use RestAPI  with authenticated header
            var buildURL = buildServerUserID != constants.EMPTY  ? 'http://' + buildServerUserID + ':' + buildServerPassword + '@' + buildServerName + ':' + buildServerPort + '/job/' + jobname + '/doDelete'
            : 'http://' + buildServerName + ':' + buildServerPort + '/job/' + jobname + '/doDelete';
            
            request(
                {
                    method: 'POST'
                    ,url: buildURL
                    ,headers: { "content-type": "application/xml" }
                }, 
                
                function (error, response, body) {
                    if ((error || response.statusCode !== 302) && (error || response.statusCode !== 200)) {
                        callback(error || true, response);
                        return;
                    }
                    var data = body;
                    callback(null, data);
                }
            );
           
        } else {

            var execFile = require('child_process').execFile;
            var batchFilePath = path.join(__dirname, '../utils/', constants.DELETE_BATCH_FILE_PATH);
            var jenkins_cli_path = path.join(__dirname, '../../client/libs/jenkins-cli/', "");

            execFile(batchFilePath, ['http://' + buildServerName + ':' + buildServerPort, jobname, jenkins_cli_path], null, function (error, stdout, stderr) {
                callback(null, stdout);
            });
        }


    };
    
    this.JobInfo = function (jobname, buildServerName , buildServerPort,  buildServerUserID, buildServerPassword,  callback) {
        /*
            Get all information for a job
            */
        buildurl = (buildServerUserID != constants.EMPTY) ? urlbuilder.build_url_job(JOBINFOAPI, buildServerUserID + ':' + buildServerPassword + '@' + buildServerName, buildServerPort, jobname)
        : urlbuilder.build_url_job(JOBINFOAPI, buildServerName, buildServerPort, jobname);
        
        request({ method: 'GET', url: buildurl }, function (error, response, body) {
            if (error || response.statusCode !== 200) {
                callback(error || null, response);
                return;
            }
            var data = JSON.parse(body.toString());
            callback(null, data);
        });
 
    };
    
    this.AllJobs = function (buildServerName , buildServerPort, buildServerUserID, buildServerPassword, callback) {
        /*
            Return a list of object literals containing the name and color of all jobs on the Jenkins server
            */
        buildurl = (buildServerUserID != constants.EMPTY)? urlbuilder.build_url(LIST, buildServerUserID + ':' + buildServerPassword + '@' + buildServerName, buildServerPort)
        : urlbuilder.build_url(LIST, buildServerName, buildServerPort);
        
        request({ method: 'GET', url: buildurl }, function (error, response, body) {
            if (error || response.statusCode !== 200) {
                callback(error || true, response);
                return;
            }
            var data = JSON.parse(body.toString()).jobs;
            callback(null, data);
        });
    };
    
    this.SetBuildNumber = function (jobname, nextBuildNumber, buildServerName , buildServerPort, buildServerUserID, buildServerPassword, callback) {
        /*
           SetBuildNumber for new job to match the main job. 
            */         
           var buildurl = (buildServerUserID != constants.EMPTY) ? 
            'http://' + buildServerUserID + ':' + buildServerPassword + '@' + buildServerName + ':' + buildServerPort + '/job/' + jobname + '/nextbuildnumber/submit'
            : 'http://' + buildServerName + ':' + buildServerPort + '/job/' + jobname + '/nextbuildnumber/submit';
        request(
            {
                method: 'POST'
                ,url: buildurl
                ,body: 'nextBuildNumber=' + nextBuildNumber
                ,headers: { "content-type": "application/x-www-form-urlencoded" }
            }, 
                
                function (error, response, body) {
                if (error || response.statusCode !== 200) {
                    callback(error || true, response);
                    return;
                }
                var data = body;
                callback(null, data);
            }
        );
    };

};




module.exports = JenkinsAPI;

