﻿var env = require('get-env')();

if (env === 'dev' || env === 'development' || env === '') {    
    //Imports from ansible.js
    var ansible = require('./ansible.js');
    var constants = require('../../config/serviceconstants.js');
} else if (env === 'prod' || env === 'production') {
    //Imports from ansible.min.js
    var ansible = require('./ansible.min.js');
    var constants = require('../../config/serviceconstants.min.js');
}

//Configuration management factory class to create respective tool object at runtime
function ConfigMgmtFactory() {
   
};

ConfigMgmtFactory.prototype = {
    GetConfigMgmtToolObj: function GetConfigMgmtToolObj(type) {
        if (type == constants.ANSIBLE)
            return new ansible;     
    }
}

module.exports = ConfigMgmtFactory;