﻿function fn_app_publishreports() {
    this.app_publishreports_json = {
        _name : 'project',
        _content : 
 [
            {
                _name : 'keepDependencies',
                _content : 'false'
            },
            {
                _name : 'properties',
                _content : {}
            },
            {
                _name : 'scm',
                _content : {},
                _attrs : { 'class': 'hudson.scm.NullSCM' }
            },
            {
                _name : 'canRoam',
                _content : 'true'
            },
            {
                _name : 'disabled',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenDownstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenUpstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'triggers',
                _content : {},
                _attrs : { 'class' : 'vector' }
            },
            {
                _name : 'concurrentBuild',
                _content : 'false'
            },
            {
                _name : 'builders',
                _content : 
 [
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Make Reports Directory'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\CodeAnalysisReportbat'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy CodeAnalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\CodeMetricsbat'
                        }
                    
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy CodeMetricsReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\UT-RegressionTest'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy UT-RegressionTestReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\CodeCoverageReport'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy CodeCoverageReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\SecurityCodeanalysis'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy SecurityCodeanalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\RiskAnalysis'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    },
                    {
                    //_name : 'hudson.tasks.BatchFile',
                    //_content : 
                    //{
                    //    _name : 'command',
                    //    _content : 'C:\\Jenkins\\JenkinReportbat\\copyreportfiles'
                    //}
                    },
                    {
                    //_name : 'hudson.tasks.BatchFile',
                    //_content : 
                    //{
                    //    _name : 'command',
                    //    _content : 'C:\\Jenkins\\JenkinReportbat\\SVNLogHistory.bat'
                    //}
                    },
                    {
                    //_name : 'hudson.tasks.BatchFile',15
                    //_content : 
                    //{
                    //    _name : 'command',
                    //    _content : 'cd C:\\Jenkins\\Utilities\\EnterpriseBuildEmail EnterpriseCustomEmail.exe %REVISIONNUMBER_SVN%'
                    //}
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'REM Xcopy RiskAnalysisReport to workspace path '
                        }
                    }
                ]
            },
            {
                _name : 'publishers',
                _content :
 {
                    _name : 'htmlpublisher.HtmlPublisher',
                    _content : 
 {
                        _name: 'reportTargets',
                        _content:
 [
                            {
                                _name : 'htmlpublisher.HtmlPublisherTarget',
                                _content : {
                                    "reportName": "Code Coverage",
                                    "reportDir": "C:\\Reports\\BuildsCodeCoverage",
                                    "reportFiles": "index.htm",
                                    "keepAll": "false",
                                    "allowMissing": "false",
                                    "wrapperName": "htmlpublisher-wrapper.html"
                                }
                            },
                            {
                                _name : 'htmlpublisher.HtmlPublisherTarget',
                                _content : {
                                    "reportName": "Security Code Analysis Report",
                                    "reportDir": "C:\\Reports\\SecurityAnalysis",
                                    "reportFiles": "Report.html",
                                    "keepAll": "false",
                                    "allowMissing": "false",
                                    "wrapperName": "htmlpublisher-wrapper.html"
                                }
                            },
                            {
                                _name : 'htmlpublisher.HtmlPublisherTarget',
                                _content : {
                                    "reportName": "Static Code Analysis Report",
                                    "reportDir": "C:\\Reports\\BuildsStaticCodeAnalysisReport",
                                    "reportFiles": "CodeAnalysisReport.html",
                                    "keepAll": "false",
                                    "allowMissing": "false",
                                    "wrapperName": "htmlpublisher-wrapper.html"
                                }
                            },
                            {
                                _name : 'htmlpublisher.HtmlPublisherTarget',
                                _content : {
                                    "reportName": "Unit Test Result",
                                    "reportDir": "C:\\Reports\\BuildsUTCResults",
                                    "reportFiles": "UTCResults.html",
                                    "keepAll": "false",
                                    "allowMissing": "false",
                                    "wrapperName": "htmlpublisher-wrapper.html"
                                }
                            },
                            {
                                _name : 'htmlpublisher.HtmlPublisherTarget',
                                _content : {
                                    "reportName": "Code Metrics",
                                    "reportDir": "C:\\Reports\\BuildsCodeMetricsReport",
                                    "reportFiles": "CodeMetricsRpt.html",
                                    "keepAll": "false",
                                    "allowMissing": "false",
                                    "wrapperName": "htmlpublisher-wrapper.html"
                                }
                            },
                            {
                                _name : 'htmlpublisher.HtmlPublisherTarget',
                                _content : {
                                    "reportName": "Build Analysis Report",
                                    "reportDir": "C:\\Reports\\BuildsRiskAnalysisReport",
                                    "reportFiles": "BuildAnalysis.html",
                                    "keepAll": "false",
                                    "allowMissing": "false",
                                    "wrapperName": "htmlpublisher-wrapper.html"
                                }
                            }
                        ]
                    }
                    ,
                    _attrs : { 'plugin': 'htmlpublisher' }
                }
            }
        ],
        _attrs : null
    }
};
		
module.exports = fn_app_publishreports;