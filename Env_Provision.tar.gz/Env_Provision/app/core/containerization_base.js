﻿// Abstract base class
function ContainerizationBase() {
    //To do
    //Add base class properties
};

// Abstract methods of class ContainerizationBase
ContainerizationBase.prototype = {
    InstallContainerEngine: function InstallContainerEngine(VMName, userName, password, obj) {
    },
    
    //Build container
    BuildContainer: function BuildContainer(type, obj) {        

    },

    //Build image
    BuildDockerImage: function BuildDockerImage(NexusJarfile, NexusDockerfile,  obj) {
    },

    //Build Container using Kubernetes
    BuildContainerUsingKubernetes: function(NexusJarfile, NexusDockerfile, obj) {
    }
    
    
};

module.exports = ContainerizationBase;