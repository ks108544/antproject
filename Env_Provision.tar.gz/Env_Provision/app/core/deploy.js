﻿// Abstract base class
function Deploy() {
    
};

// Abstract methods of class ClsBuild
Deploy.prototype = {
    
    GetDeploymentDetails: function GetDeploymentDetails(type, obj) {        

    }
};

module.exports = Deploy;