﻿function fn_ui_svndeploy() {
    this.ui_svndeploy_json = {
        _name: 'project',
        _content: [ 
            {
                _name: 'keepDependencies',
                _content: 'false',
                _attrs: null
            },
            {
                _name : 'scm',
                _content : {},
                _attrs : { 'class' : 'hudson.scm.NullSCM' }
            },
            {
                _name: 'canRoam',
                _content: true,
                _attrs: null
            },
            {
                _name: 'disabled',
                _content: false,
                _attrs: null
            },
            {
                _name: 'blockBuildWhenDownstreamBuilding',
                _content: false,
                _attrs: null
            },
            {
                _name: 'blockBuildWhenUpstreamBuilding',
                _content: false,
                _attrs: null
            },
            {
                _name: 'triggers',
                _content: {},
                _attrs: { class: "vector" }
            },
            {
                _name: 'concurrentBuild',
                _content: false,
                _attrs: null
            },
            {
                _name: 'builders',
                _content: [{ _name: 'hudson.tasks.BatchFile', _content: { 'command': 'msbuild.exe' } },
                                { _name: 'hudson.tasks.BatchFile', _content: { 'command': 'msdeplooy.exe' } }
                ],
                
                _attrs: null
        },
            {
            _name: 'customWorkspace',
            _content: 'C:\\jenkins_instdir\\jobs\\NerddinnerWS_Subversion\\workspace'
        },
        ],
        _attrs: null
        
    }
    
};

module.exports = fn_ui_svndeploy;