﻿var env = require('get-env')();
var SourceFileName = "jenkins.js"
var http = require('http');
var request = require('request');
var dateformat = require('dateformat');
var fs = require('fs');
var promise = require('bluebird');
var mongoose = require('mongoose');
var path = require('path');
// moment module deprecated
//var moment = require('moment');
var async = require('async');
var cherio = require('cheerio');
var redis = require('redis');

//debugger;
if (env === 'dev' || env === 'development' || env === '') {
    //Imports from build.js
    var Build = require('./build.js');
    var customlogger = require("../utils/logger.js");
    //Imports from helper.js
    var urlbuilder = require('../helper/buildurl.js');
    var builddefnModel = require('../models/builddefinition.js');
    var cmconfigModel = require('../models/cmconfig.js');
    var createjobconfig = require('./jen_jobconfig.js');
    var jenkinsapi = require('./jenkins_api.js');
    //var createjobconfigxml = require('./jen_jobconfig_xml.js');
    var constants = require('../../config/serviceconstants.js');
    //log file
    var customlogger = require("../utils/logger.js");
    
} else if (env === 'prod' || env === 'production') {
    //console.log("jenkins  Start ");
    
    //Imports from build.min.js
    var Build = require('./build.min.js');
    
    //Imports from helper.min.js
    var urlbuilder = require('../helper/buildurl.min.js');
    var builddefnModel = require('../models/builddefinition.min.js');
    var cmconfigModel = require('../models/cmconfig.min.js');
    var createjobconfig = require('./jen_jobconfig.min.js');
    var jenkinsapi = require('./jenkins_api.min.js');
    //var createjobconfigxml = require('./jen_jobconfig_xml.min.js');
    var constants = require('../../config/serviceconstants.min.js');
    //console.log("jenkins End ");
    //log file
    var customlogger = require("../utils/logger.js");
}


var reportsSharePath = constants.REPORTS_LINK_PATH;
//debugger;

promise.promisifyAll(mongoose);

//Constants
var API = '/api/json';
var LIST = '%s' + API;
var LAST_BUILD = '%s/job/%s/lastBuild' + API;
var JOBINFO = '%s/job/%s' + API;

var data, fname;
var NEWJOB = '%s/createItem?name=';
var BUILD = '%s/job/jobname/build';

/*var client = redis.createClient(constants.REDIS_PORT, constants.REDIS_SERVER);
client.on('connect', function () {
    console.log('Redis connected @ ' + constants.REDIS_SERVER + 'listenting on port ' + constants.REDIS_PORT);
});*/

//Concreate Jenkins build class inheriting base build class
function Jenkins() {
    Build.apply(this, arguments);
    
    //to do:
    //Add jenkins related properties
}

Jenkins.prototype = new Build;

//Jenkins build class overridding base class methods

Jenkins.prototype = {
    
    CreateUIJob: function (buildModel, jobName, jobType, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateUIJob", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ?
        'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort
        :'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var configxml = "";
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var objcreatejobconfig = new createjobconfig;
        var nextBuildNumber = 1;
        
        if (jobType == constants.BUILD) {
            // Get config xml of App tier build job
            configxml = objcreatejobconfig.ui_build_createconfig(buildModel);
        }
        else if (jobType == constants.UNITTEST) {
            // Get config xml of App tier build job
            configxml = objcreatejobconfig.ui_unittest_createconfig(buildModel);
        }
        else if (jobType == constants.PUBLISHREPORTS) {
            // Get config xml of App tier reports job
            configxml = objcreatejobconfig.ui_publishreports_createconfig(buildModel);
        }
        else if (jobType == constants.SONARANALYSIS) {
            // Get config xml of App tier sonar analysis job
            configxml = objcreatejobconfig.ui_sonaranalysis_createconfig(buildModel);
        }       
        else if (jobType == constants.CI) {
            // Get config xml of App tier multi job        
            configxml = objcreatejobconfig.ui_multijob_createconfig(buildModel);
        }
        else if (jobType == constants.DEPLOY) {
            // Get config xml of App tier build job
            configxml = objcreatejobconfig.ui_deploy_createconfig(buildModel);
        }
        var exists = false;
        //Frame the build url using urlbuilder  
        buildurl = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort)
        :  urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerName, buildModel.BuildServerPort);
        if (EditMode == false) {
            objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                callback(null, resultdata);
            });
        }
        else {
            objjenkinsapi.JobInfo(jobName, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                if (resultdata != null) {
                    if (resultdata.displayName == jobName) {
                        exists = true;
                    }
                    else if (resultdata.statusMessage == constants.NOT_FOUND) {
                        exists = false;
                    }
                }
                if (exists == false) {
                    objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }
                        //get main job's build number and set the build number to match the newly created job in edit mode, so both build numbers will be in sync
                        objjenkinsapi.JobInfo(buildModel.ApplicationName + constants.UNDERSCORE_MAIN, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                            if (error != null) {
                                callback(error, resultdata);
                                return;
                            }
                            if (resultdata != null) {
                                nextBuildNumber = resultdata.lastBuild.number + 1;
                                objjenkinsapi.SetBuildNumber(jobName, nextBuildNumber, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                    if (error != null) {
                                        if (resultdata.statusCode > 199 && resultdata.statusCode < 303) {
                                            callback(null, resultdata);
                                            return;
                                        }
                                        else {
                                            callback(error, resultdata);
                                            return;
                                        }
                                    }
                                    if (resultdata != null && error == null) {
                                        callback(null, resultdata);
                                        return;
                                    }
                                });
                            }
                        });
                    });
                }
                else if (exists == true) {
                    objjenkinsapi.ModifyJob(jobName, jenkinsHostedUrl, configxml, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }
                        callback(null, resultdata);
                        return;
                    });
                }
                //callback(null, resultdata);
            });
        }

    },
    
    CreateAppTierJobs: function (buildModel, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateAppTierJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ? 'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort
        : 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var objjenkinsapi = new jenkinsapi;
        // Initialise variables
        var buildurl = "";
        var ui_build_configxml = "";
        var ui_reportsjob_configxml = "";
        var ui_multijob_configxml = "";
        //var sourceControlPath = "";
        var jobName = "";
        var uijobName_Build = "";
        var uijobName_Reportsjob = "";
        var uijobName_Sonaranalysisjob = "";
        var uijobName_Multijob = "";
        var uijobName_Deploy = "";
        var uijobName_UnitTest = "";
        
        
        jobName = buildModel.ApplicationName;
        
        if (buildModel.SourceControlTool == constants.SVN) {
            uijobName_Build = jobName + constants.UNDERSCORE + constants.UISUBVERSION;
            uijobName_Reportsjob = jobName + constants.UNDERSCORE + constants.UIPUBLISHREPORTS + constants.UNDERSCORE + constants.SUBVERSION;
            uijobName_Sonaranalysisjob = jobName + constants.UIRUNSONARANALYSIS_SUBVERSION;
            uijobName_Multijob = jobName + constants.UNDERSCORE + constants.UITIER;
            uijobName_Deploy = jobName + constants.UISUBVERSION_DEPLOY;
            uijobName_UnitTest = jobName + constants.UISUBVERSION_UNITTEST;
        }
        //Addition of git parametetrs for change in job name
        else if (buildModel.SourceControlTool == constants.GIT) {
            uijobName_Build = jobName + constants.UNDERSCORE + constants.GIT;
            uijobName_Reportsjob = jobName + constants.UNDERSCORE + constants.PUBLISHREPORTS + constants.UNDERSCORE + constants.GIT;
            uijobName_Sonaranalysisjob = jobName + constants.RUNSONARANALYSIS_GIT;
            uijobName_Multijob = jobName + constants.UNDERSCORE + constants.UITIER;
            uijobName_Deploy = jobName + constants.GIT_DEPLOY;
            uijobName_UnitTest = jobName + constants.GIT_UNITTEST;
        }
        
        var objJenkins = new Jenkins;
        
        objJenkins.CreateUIJob(buildModel, uijobName_Build, constants.BUILD, EditMode, function (error, resultdata) {
            
            if (error != null) {
                console.log(constants.CREATE_APP_BUILD_JOB_ERROR_MSG + error);
                callback(error, resultdata);
                return;
            }
            else {
                console.log(constants.CREATE_APP_BUILD_JOB_SUCCESS_MSG);
                
                if (buildModel.EnableUnitTestUI) {
                    // Create multi job
                    objJenkins.CreateUIJob(buildModel, uijobName_UnitTest, constants.UNITTEST, EditMode, function (error, resultdata) {
                        if (error != null) {
                            console.log(constants.CREATE_APP_UNITTEST_JOB_ERROR_MSG + error);
                            callback(error, resultdata);
                            return;
                        }
                        else {
                            console.log(constants.CREATE_APP_UNITTEST_JOB_SUCCESS_MSG);
                            
                            // Check if quality reports are enabled
                            // Create reports job
                            if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI) || (buildModel.EnableUnitTestUI)) {
                                objJenkins.CreateUIJob(buildModel, uijobName_Reportsjob, constants.PUBLISHREPORTS, EditMode, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.CREATE_APP_REPORTS_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                        return;
                                    }
                                    else {
                                        console.log(constants.CREATE_APP_REPORTS_JOB_SUCCESS_MSG);
                                        
                                        // Check if sonar analysis is enabled
                                        if (buildModel.EnableSonarAnalysisUI) {
                                            // Create sonar analysis job
                                            objJenkins.CreateUIJob(buildModel, uijobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.CREATE_APP_SONAR_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                    return;
                                                }
                                                else {
                                                    console.log(constants.CREATE_APP_SONAR_JOB_SUCCESS_MSG);
                                                    
                                                    if (buildModel.EnableJenDeployPackageUI) {
                                                        objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                                return;
                                                            }
                                                            else {
                                                                console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                                    if (error != null) {
                                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                                        callback(error, resultdata);
                                                                    }
                                                                    else {
                                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                                        callback(null, resultdata);

                                                                    }
                                                                });
                                                            }
                                                        });
                                                    }
                                                    else {
                                                        if (EditMode == true) {
                                                            if (buildModel.EnableJenDeployPackageUI) {
                                                                objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                                    if (error != null) {
                                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                                        callback(error, resultdata);
                                                                        return;
                                                                    }
                                                                    else {
                                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                                    }
                                                                //callback(null, resultdata);
                                                                });
                                                            }
                                                        }
                                                        // Create multi job
                                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                            }
                                                            else {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                                callback(null, resultdata);

                                                            }
                                                        });
                                                    }

                                                }
                                            });
                                        }
                                        else {
                                            if (EditMode == true) {
                                                if (buildModel.EnableSonarAnalysisUI) {
                                                    objjenkinsapi.Deletejob(uijobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                        if (error != null) {
                                                            console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                            callback(error, resultdata);
                                                            return;
                                                        }
                                                        else {
                                                            console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                        }
                                                    //callback(null, resultdata);
                                                    });
                                                }
                                            }
                                            if (buildModel.EnableJenDeployPackageUI) {
                                                objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                        // Create multi job
                                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                            }
                                                            else {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                                callback(null, resultdata);

                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                            else {
                                                if (EditMode == true) {
                                                    if (buildModel.EnableJenDeployPackageUI) {
                                                        objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                                return;
                                                            }
                                                            else {
                                                                console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                            }
                                                        //callback(null, resultdata);
                                                        });
                                                    }
                                                }
                                                // Create multi job
                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                        callback(null, resultdata);

                                                    }
                                                });
                                            }

                                        }
                                    }
                                });
                            }
                            else {
                                if (EditMode == true) {
                                    if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI)) {
                                        objjenkinsapi.Deletejob(uijobName_Reportsjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.DELETE_APP_REPORTS_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                                return;
                                            }
                                            else {
                                                console.log(constants.DELETE_APP_REPORTS_JOB_SUCCESS_MSG);

                                            }
                                        //callback(null, resultdata);
                                        });
                                    }
                                }
                                // Create sonar analysis job
                                if (buildModel.EnableSonarAnalysisUI) {
                                    objJenkins.CreateUIJob(buildModel, uijobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_APP_SONAR_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_APP_SONAR_JOB_SUCCESS_MSG);
                                            
                                            if (buildModel.EnableJenDeployPackageUI) {
                                                objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                            }
                                                            else {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                                callback(null, resultdata);

                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                            else {
                                                
                                                objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                        return;
                                                    }
                                                    else {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                    }
                                                    //callback(null, resultdata);
                                                });
                                                
                                                // Create multi job
                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                        callback(null, resultdata);

                                                    }
                                                });
                                            }

                                        }
                                    });
                                }
                                else {
                                    if (EditMode == true) {
                                        if (buildModel.EnableSonarAnalysisUI) {
                                            objjenkinsapi.Deletejob(uijobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constans.DELETE_APP_SONAR_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                    return;
                                                }
                                                else {
                                                    console.log(constants.DELETE_APP_SONAR_JOB_SUCCESS_MSG);

                                                }
                                            //callback(null, resultdata);
                                            });
                                        }
                                    }
                                    
                                    if (buildModel.EnableJenDeployPackageUI == true) {
                                        objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                // Create multi job
                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                        callback(null, resultdata);

                                                    }
                                                });
                                            }
                                        });
                                    }
                                    else {
                                        if (EditMode == true) {
                                            if (buildModel.EnableJenDeployPackageUI) {
                                                objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                        return;
                                                    }
                                                    else {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                    }
                                                //callback(null, resultdata);
                                                });
                                            }
                                        }
                                        // Create multi job
                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                callback(null, resultdata);
                                            }
                                        });
                                    }
                                }
                            }
                        }
                    });
                }
                else {
                    if (EditMode == true) {
                        if (buildModel.EnableUnitTestUI) {
                            objjenkinsapi.Deletejob(uijobName_UnitTest, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.DELETE_APP_UNITTEST_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                    return;
                                }
                                else {
                                    console.log(constants.DELETE_APP_UNITTEST_JOB_SUCCESS_MSG);
                                }
                            //callback(null, resultdata);
                            });
                        }
                    }
                    // Check if quality reports are enabled
                    // Create reports job
                    if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI) || (buildModel.EnableUnitTestUI)) {
                        objJenkins.CreateUIJob(buildModel, uijobName_Reportsjob, constants.PUBLISHREPORTS, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log(constants.CREATE_APP_REPORTS_JOB_ERROR_MSG + error);
                                callback(error, resultdata);
                            }
                            else {
                                console.log(constants.CREATE_APP_REPORTS_JOB_SUCCESS_MSG);
                                
                                // Check if sonar analysis is enabled
                                if (buildModel.EnableSonarAnalysisUI) {
                                    // Create sonar analysis job
                                    objJenkins.CreateUIJob(buildModel, uijobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_APP_SONAR_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_APP_SONAR_JOB_SUCCESS_MSG);
                                            
                                            if (buildModel.EnableJenDeployPackageUI) {
                                                objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                            }
                                                            else {
                                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                                callback(null, resultdata);

                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                            else {
                                                if (EditMode == true) {
                                                    if (buildModel.EnableJenDeployPackageUI) {
                                                        objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                            if (error != null) {
                                                                console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                                return;
                                                            }
                                                            else {
                                                                console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                            }
                                                        //callback(null, resultdata);
                                                        });
                                                    }
                                                }
                                                // Create multi job
                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                        callback(null, resultdata);

                                                    }
                                                });
                                            }

                                        }
                                    });
                                }
                                else {
                                    if (EditMode == true) {
                                        if (buildModel.EnableSonarAnalysisUI) {
                                            objjenkinsapi.Deletejob(uijobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                    return;
                                                }
                                                else {
                                                    console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                }
                                            //callback(null, resultdata);
                                            });
                                        }
                                    }
                                    if (buildModel.EnableJenDeployPackageUI) {
                                        objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                // Create multi job
                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                        callback(null, resultdata);

                                                    }
                                                });
                                            }
                                        });
                                    }
                                    else {
                                        if (EditMode == true) {
                                            if (buildModel.EnableJenDeployPackageUI) {
                                                objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                        return;
                                                    }
                                                    else {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                    }
                                                //callback(null, resultdata);
                                                });
                                            }
                                        }
                                        // Create multi job
                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                callback(null, resultdata);

                                            }
                                        });
                                    }

                                }
                            }
                        });
                    }
                    else {
                        if (EditMode == true) {
                            if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI)) {
                                objjenkinsapi.Deletejob(uijobName_Reportsjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.DELETE_APP_REPORTS_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                        return;
                                    }
                                    else {
                                        console.log(constants.DELETE_APP_REPORTS_JOB_SUCCESS_MSG);

                                    }
                                //callback(null, resultdata);
                                });
                            }
                        }
                        
                        // Create sonar analysis job
                        if (buildModel.EnableSonarAnalysisUI) {
                            objJenkins.CreateUIJob(buildModel, uijobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_SONAR_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_SONAR_JOB_SUCCESS_MSG);
                                    
                                    if (buildModel.EnableJenDeployPackageUI) {
                                        objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                        callback(null, resultdata);

                                                    }
                                                });
                                            }
                                        });
                                    }
                                    else {
                                        if (EditMode == true) {
                                            if (buildModel.EnableJenDeployPackageUI) {
                                                objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                        return;
                                                    }
                                                    else {
                                                        console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                                    }
                                            //callback(null, resultdata);
                                                });
                                            }
                                        }
                                        // Create multi job
                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                callback(null, resultdata);

                                            }
                                        });
                                    }

                                }
                            });
                        }
                        else {
                            if (EditMode == true) {
                                if (buildModel.EnableSonarAnalysisUI) {
                                    objjenkinsapi.Deletejob(uijobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constans.DELETE_APP_SONAR_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                            return;
                                        }
                                        else {
                                            console.log(constants.DELETE_APP_SONAR_JOB_SUCCESS_MSG);

                                        }
                                    //callback(null, resultdata);
                                    });
                                }
                            }
                            
                            if (buildModel.EnableJenDeployPackageUI == true) {
                                objJenkins.CreateUIJob(buildModel, uijobName_Deploy, constants.DEPLOY, EditMode, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.CREATE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                    }
                                    else {
                                        console.log(constants.CREATE_APP_DEPLOY_JOB_SUCCESS_MSG);
                                        // Create multi job
                                        objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                                callback(null, resultdata);

                                            }
                                        });
                                    }
                                });
                            }
                            else {
                                if (EditMode == true) {
                                    if (buildModel.EnableJenDeployPackageUI) {
                                        objjenkinsapi.Deletejob(uijobName_Deploy, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.DELETE_APP_DEPLOY_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                                return;
                                            }
                                            else {
                                                console.log(constants.DELETE_APP_DEPLOY_JOB_SUCCESS_MSG);

                                            }
                                        //callback(null, resultdata);
                                        });
                                    }
                                }
                                // Create multi job
                                objJenkins.CreateUIJob(buildModel, uijobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.CREATE_APP_MULTI_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                    }
                                    else {
                                        console.log(constants.CREATE_APP_MULTI_JOB_SUCCESS_MSG);
                                        callback(null, resultdata);

                                    }
                                });
                            }
                        }

                    }


                }

            }

        });

    },
    CreateCDMainJobAndLoopInNxtStage: function (buildModel, stageMain_DependentJobs, i, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateCDMainJobAndLoopInNxtStage", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkins = new Jenkins;
        var mainJobName = buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.Stage[i].Stage + constants.UNDERSCORE_MAIN;
        objJenkins.CreateCDMainJob(buildModel, stageMain_DependentJobs, mainJobName, function (error, resultdata) {
            if (error != null) {
                console.log("Error in Main Job Creation");
                callback(error, resultdata);
                return;
            }
            else {
                console.log("Main Job Created");
                //call same function for next stage. increment i by 1
                if (i < buildModel.DeployStages.length - 1) {
                    i = i + 1;
                    objJenkins.CreateAppTierCDJobsRecursive(buildModel, i, EditMode, function (error, resultdata) {
                        if (error != null) {
                            console.log("create jobs loop failed inside if block" + error);
                            callback(error, resultdata);
                            return;
                        }
                        else {
                            callback(null, resultdata);
                        }
                    });
                } 
                else {
                    callback(null, resultdata);
                }                ;
            }
        });
    },
    CreateAppTierCDJobsAppDeploy: function (buildModel, i, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateAppTierCDJobsAppDeploy", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ? 'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort
        : 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var objjenkinsapi = new jenkinsapi;
        var jobName_AppDeploy_Main = "";
        
        var jobName_DownloadArtifacts = "";
        var subJobType = "";
        var objJenkins = new Jenkins;
        
        jobName_DownloadArtifacts = buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.ACTIVITY_NEXUS;
        jobName_AppDeploy_Main = buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.APPDEPLOY;
        jobName_Application_Deployment_Main = buildModel.CDApplicationName + constants.UNDERSCORE + constants.APPLICATIONDEPLOYMENT + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.MAIN;
        
        subJobType = constants.NEXUS;
        objJenkins.CreateCDJob(buildModel, jobName_DownloadArtifacts, constants.DOWNLOADARTIFACTS, subJobType, EditMode, i, function (error, resultdata) {
            if (error != null) {
                console.log("Download artifact failed" + error);
                callback(error, resultdata);
            }
            else {
                console.log("created nexus job");
                subJobType = constants.APPDEPLOY;
                for (j = 0; j < buildModel.DeployStages[i].AppDeployment.ApplicationDeploy.length ; j++) {
                    jobName_Application_Deployment_AnsiblePlaybook = buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[j].AppDeployName;
                    objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_AnsiblePlaybook, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log("App Deploy job errored");
                            callback(error, resultdata);
                        }
                        else {
                            console.log("App Deploy job created");
                        }
                    });
                }
                subJobType = constants.MAIN;
                objJenkins.CreateCDJob(buildModel, jobName_AppDeploy_Main, constants.APPDEPLOY, subJobType, EditMode, i, function (error, resultdata) {
                    if (error != null) {
                        console.log("App Deploy main job error");
                        callback(error, resultdata);
                    }
                    else {
                        console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                        subJobType = constants.MAIN;
                        objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_Main, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                            if (error != null) {
                                console.log("App Deploy main job created");
                                callback(error, resultdata);
                            }
                            else {
                                callback(null, resultdata);
                            }
                        });
                    }
                });
            }
        });

    },
    
    CreateAppTierCDJobsRecursive: function (buildModel, i, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateAppTierCDJobsRecursive", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ? 'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort
        : 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var objjenkinsapi = new jenkinsapi;
        // Initialise variables        
        var jobName = "";
        var subJobType = "";
        
        var jobName_Platform_Provisioning_AnsiblePlaybook = "";
        var jobName_Application_Deployment_AnsiblePlaybook = "";
        var jobName_Platform_Provisioning_Main = "";
        var jobName_Application_Deployment_Main = "";
        
        jobName = buildModel.CDApplicationName;
        var mainJobName = jobName + constants.UNDERSCORE + buildModel.Stage[i].Stage + constants.UNDERSCORE_MAIN;
        //buildModel.BuildDefinitionName;
        //buildModel.BuildDefinitionName = buildModel.CDJobName;
        
        var objJenkins = new Jenkins;
        var stageMain_DependentJobs = [];
        if (typeof (buildModel.DeployStages[i].PlatformProvisioning) != constants.UNDEFINED) {
            jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.OperatingSystem;
        }
        
        jobName_Application_Deployment_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.APPLICATIONDEPLOYMENT;
        jobName_Platform_Provisioning_Main = jobName + constants.UNDERSCORE + constants.PLATFORMPROVISIONING + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.MAIN;
        jobName_Application_Deployment_Main = jobName + constants.UNDERSCORE + constants.APPLICATIONDEPLOYMENT + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.MAIN;
        
        if (buildModel.DeployStages[i].EnablePlatformProvisioning) {
            //Create platform jobs and main jobs
            stageMain_DependentJobs.push(jobName_Platform_Provisioning_Main);
            for (j = 0; j < buildModel.DeployStages[i].PlatformProvisioning.Platform.length; j++) {
                if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.JDK.toUpperCase()) {
                    subJobType = constants.JDK.toUpperCase();
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                    objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log("create platform prov sub job failed" + subJobType + error);
                            callback(error, resultdata);
                        } else {
                            console.log("create platform prov sub job created" + subJobType);
                        }
                    });
                }
                else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.JRE.toUpperCase()) {
                    subJobType = constants.JRE.toUpperCase();
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                    objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log("create platform prov sub job failed" + +subJobType + error);
                            callback(error, resultdata);
                        } else {
                            console.log("create platform prov sub job created" + subJobType);
                        }
                    });
                }
                else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.TOMCAT.toUpperCase()) {
                    subJobType = constants.TOMCAT.toUpperCase();
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                    objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log("create platform prov sub job failed" + subJobType + error);
                            callback(error, resultdata);
                        } else {
                            console.log("create platform prov sub job created" + subJobType);
                        }
                    });
                }
                else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.DOCKER.toUpperCase()) {
                    subJobType = constants.DOCKER.toUpperCase();
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                    objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log("create platform prov sub job failed" + subJobType + error);
                            callback(error, resultdata);
                        } else {
                            console.log("create platform prov sub job created" + subJobType);
                        }
                    });
                }
                
                else {
                    subJobType = constants.CUSTOM_PLAYBOOK.toUpperCase();
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                    objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log("create platform prov sub job failed" + subJobType + error);
                            callback(error, resultdata);
                        } else {
                            console.log("create platform prov sub job created" + subJobType);
                        }
                    });
                }

                
            }
            subJobType = constants.MAIN;
            objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_Main, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                if (error != null) {
                    console.log("create platform prov main job failed" + error);
                    callback(error, resultdata);
                } else {
                    console.log("create platform prov main job created");
                    if (buildModel.DeployStages[i].EnableApplicationDeployment) {
                        stageMain_DependentJobs.push(jobName_Application_Deployment_Main);
                        objJenkins.CreateAppTierCDJobsAppDeploy(buildModel, i, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log("create app deploy function call failed" + error);
                                callback(error, resultdata);
                            } else {
                                //create mains jobs
                                console.log("create app deploy function call success" + error);
                                objJenkins.CreateCDMainJobAndLoopInNxtStage(buildModel, stageMain_DependentJobs, i, EditMode, function (error, resultdata) {
                                    if (error != null) {
                                        console.log("create app deploy function call failed" + error);
                                        callback(error, resultdata);
                                    } else {
                                        callback(null, resultdata);
                                    }
                                });

                            }
                        });
                    } else {
                        objJenkins.CreateCDMainJobAndLoopInNxtStage(buildModel, stageMain_DependentJobs, i, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log("create app deploy function call failed" + error);
                                callback(error, resultdata);
                            } else {
                                callback(null, resultdata);
                            }
                        });
                    }
                }
            });
        } 
        else {
            stageMain_DependentJobs.push(jobName_Application_Deployment_Main);
            objJenkins.CreateAppTierCDJobsAppDeploy(buildModel, i, EditMode, function (error, resultdata) {
                if (error != null) {
                    console.log("create app deploy function call failed" + error);
                    callback(error, resultdata);
                } else {
                    //create mains jobs
                    console.log("create app deploy function call success" + error);
                    objJenkins.CreateCDMainJobAndLoopInNxtStage(buildModel, stageMain_DependentJobs, i, EditMode, function (error, resultdata) {
                        if (error != null) {
                            console.log("create app deploy function call failed" + error);
                            callback(error, resultdata);
                        } else {
                            callback(null, resultdata);
                        }
                    });
                }
            });
        }

    },
    
    CreateAppTierCDJobs: function (buildModel, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateAppTierCDJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ? 'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort
        : 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var objjenkinsapi = new jenkinsapi;
        // Initialise variables        
        var jobName = "";
        var subJobType = "";
        var jobName_DownloadArtifacts = "";
        var jobName_Platform_Provisioning_AnsiblePlaybook = "";
        var jobName_Application_Deployment_AnsiblePlaybook = "";
        var jobName_AppDeploy_Main = "";
        var jobName_Platform_Provisioning_Main = "";
        var jobName_Application_Deployment_Main = "";
        var mainJobName = "";
        var i = 0;
        
        jobName = buildModel.CDApplicationName;//buildModel.BuildDefinitionName;
        //buildModel.BuildDefinitionName = buildModel.CDJobName;
        
        var objJenkins = new Jenkins;
        var cnt = 0;
        var stageMain_DependentJobs = [];
        var stageMainJobs = [];
        
        if (buildModel.Servicetype == constants.CD) {
            for (i = 0; i < buildModel.DeployStages.length; i++) {
                
                stageMain_DependentJobs = [];
                stageMainJobs = [];
                mainJobName = jobName + constants.UNDERSCORE + buildModel.Stage[i].Stage + constants.UNDERSCORE_MAIN;
                stageMainJobs.push(mainJobName);
                if (typeof (buildModel.DeployStages[i].PlatformProvisioning) != constants.UNDEFINED) {
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.OperatingSystem;
                }
                jobName_DownloadArtifacts = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.ACTIVITY_NEXUS;
                jobName_Application_Deployment_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.APPLICATIONDEPLOYMENT;
                jobName_Platform_Provisioning_Main = jobName + constants.UNDERSCORE + constants.PLATFORMPROVISIONING + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.MAIN;
                jobName_AppDeploy_Main = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.APPDEPLOY;
                jobName_Application_Deployment_Main = jobName + constants.UNDERSCORE + constants.APPLICATIONDEPLOYMENT + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + constants.MAIN;
                
                if (buildModel.DeployStages[i].EnablePlatformProvisioning) {
                    
                    stageMain_DependentJobs.push(jobName_Platform_Provisioning_Main);
                    cnt = i;
                    subJobType = constants.JDK.toUpperCase();
                    jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[0].PlatformName;
                    objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                            callback(error, resultdata);
                        }
                        else {
                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                            i = cnt;
                            subJobType = constants.MAIN;
                            objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_Main, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                    
                                    i = cnt;
                                    if (buildModel.DeployStages[i].EnableApplicationDeployment) {
                                        // Download artifacts from nexus
                                        //#############################################################################################################################
                                        stageMain_DependentJobs.push(jobName_Application_Deployment_Main);
                                        
                                        i = cnt;
                                        subJobType = constants.NEXUS;
                                        objJenkins.CreateCDJob(buildModel, jobName_DownloadArtifacts, constants.DOWNLOADARTIFACTS, subJobType, EditMode, i, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                                
                                                i = cnt;
                                                for (var j = 0; j < buildModel.DeployStages[i].AppDeployment.ApplicationDeploy.length; j++) {
                                                    i = cnt;
                                                    subJobType = constants.APPDEPLOY;
                                                    jobName_Application_Deployment_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[j].AppDeployName;
                                                    objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_AnsiblePlaybook, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                                                        if (error != null) {
                                                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                                            callback(error, resultdata);
                                                        }
                                                        else {
                                                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                                        }
                                                    });
                                            
                                                }
                                                i = cnt;
                                                subJobType = constants.MAIN;
                                                objJenkins.CreateCDJob(buildModel, jobName_AppDeploy_Main, constants.APPDEPLOY, subJobType, EditMode, i, function (error, resultdata) {
                                                    if (error != null) {
                                                        console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                                        callback(error, resultdata);
                                                    }
                                                    else {
                                                        console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                                        i = cnt;
                                                        subJobType = constants.MAIN;
                                                        objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_Main, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                                                            
                                                            if (error != null) {
                                                                console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                                                callback(error, resultdata);
                                                            }
                                                            else {
                                                                console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                                                
                                                                objJenkins.CreateCDMainJob(buildModel, stageMain_DependentJobs, mainJobName, function (error, resultdata) {
                                                                    if (error != null) {
                                                                        console.log("Error in Stage Main Job Creation");
                                                                        callback(error, resultdata);
                                                                    }
                                                                    else {
                                                                        console.log("Stage Main Job Created");
                                                                        if (stageMainJobs.length > 0 && i == buildModel.DeployStages.length - 1) {
                                                                            var mainJobName = jobName + constants.UNDERSCORE_MAIN;
                                                                            objJenkins.CreateCDMainJob(buildModel, stageMainJobs, mainJobName, function (error, resultdata) {
                                                                                if (error != null) {
                                                                                    console.log("Error in Main Job Creation");
                                                                                    callback(error, resultdata);
                                                                                }
                                                                                else {
                                                                                    console.log("Main Job Created");
                                                                                    callback(null, resultdata);
                                                                                }
                                                                            });
                                                                        }
                                                                    }

                                                                });
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        });
                                    }                          
                                    else {
                                        i = cnt;
                                        subJobType = constants.MAIN;
                                        objJenkins.CreateCDMainJob(buildModel, stageMain_DependentJobs, mainJobName, function (error, resultdata) {
                                            if (error != null) {
                                                console.log("Error in Stage Main Job Creation");
                                                callback(error, resultdata);
                                            }
                                            else {
                                                console.log("Stage Main Job Created");
                                                if (stageMainJobs.length > 0 && i == buildModel.DeployStages.length - 1) {
                                                    var mainJobName = jobName + constants.UNDERSCORE_MAIN;
                                                    objJenkins.CreateCDMainJob(buildModel, stageMainJobs, mainJobName, function (error, resultdata) {
                                                        if (error != null) {
                                                            console.log("Error in Main Job Creation");
                                                            callback(error, resultdata);
                                                        }
                                                        else {
                                                            console.log("Main Job Created");
                                                            callback(null, resultdata);
                                                        }
                                                    });
                                                }
                                            }

                                        });
                                    }
                                }
                            });
                        }
                    });

                   /* for (var j = 0; j < buildModel.DeployStages[i].PlatformProvisioning.Platform.length; j++) {
                        i = cnt;
                        if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.JDK.toUpperCase()) {
                            subJobType = constants.JDK.toUpperCase();
                            jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                            objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                }
                            });
                        }
                        else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.JRE.toUpperCase()) {
                            subJobType = constants.JRE.toUpperCase();
                            jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                            objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                }
                            });
                        }
                        else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.TOMCAT.toUpperCase()) {
                            subJobType = constants.TOMCAT.toUpperCase();
                            jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                            objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                }
                            });
                        }
                        else if (buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName.toUpperCase() == constants.DOCKER.toUpperCase()) {
                            subJobType = constants.DOCKER.toUpperCase();
                            jobName_Platform_Provisioning_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].PlatformProvisioning.Platform[j].PlatformName;
                            objJenkins.CreateCDJob(buildModel, jobName_Platform_Provisioning_AnsiblePlaybook, constants.PLATFORMPROVISIONING, subJobType, EditMode, i, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                }
                            });
                        }
                    }*/

                    
                }
                else if (buildModel.DeployStages[i].EnableApplicationDeployment) {
                    cnt = i;
                    // Download artifacts from nexus
                    stageMain_DependentJobs.push(jobName_Application_Deployment_Main);
                    
                    subJobType = constants.NEXUS;
                    objJenkins.CreateCDJob(buildModel, jobName_DownloadArtifacts, constants.DOWNLOADARTIFACTS, subJobType, EditMode, i, function (error, resultdata) {
                        if (error != null) {
                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                            callback(error, resultdata);
                        }
                        else {
                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                            
                            i = cnt;
                            subJobType = constants.APPDEPLOY;
                            jobName_Application_Deployment_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[0].AppDeployName;
                            objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_AnsiblePlaybook, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                    i = cnt;
                                    subJobType = constants.MAIN;
                                    objJenkins.CreateCDJob(buildModel, jobName_AppDeploy_Main, constants.APPDEPLOY, subJobType, EditMode, i, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                            i = cnt;
                                            subJobType = constants.MAIN;
                                            objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_Main, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                                                
                                                if (error != null) {
                                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                }
                                                else {
                                                    console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                                    
                                                    objJenkins.CreateCDMainJob(buildModel, stageMain_DependentJobs, mainJobName, function (error, resultdata) {
                                                        if (error != null) {
                                                            console.log("Error in Stage Main Job Creation");
                                                            callback(error, resultdata);
                                                        }
                                                        else {
                                                            console.log("Stage Main Job Created");
                                                            if (stageMainJobs.length > 0 && i == buildModel.DeployStages.length - 1) {
                                                                var mainJobName = jobName + constants.UNDERSCORE_MAIN;
                                                                objJenkins.CreateCDMainJob(buildModel, stageMainJobs, mainJobName, function (error, resultdata) {
                                                                    if (error != null) {
                                                                        console.log("Error in Main Job Creation");
                                                                        callback(error, resultdata);
                                                                    }
                                                                    else {
                                                                        console.log("Main Job Created");
                                                                        callback(null, resultdata);
                                                                    }
                                                                });
                                                            }
                                                        }

                                                    });
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                            /*for (var j = 0; j < buildModel.DeployStages[i].AppDeployment.ApplicationDeploy.length; j++) {
                                i = cnt;
                                
                                subJobType = constants.APPDEPLOY;
                                jobName_Application_Deployment_AnsiblePlaybook = jobName + constants.UNDERSCORE + buildModel.DeployStages[i].StageName + constants.UNDERSCORE + buildModel.DeployStages[i].AppDeployment.ApplicationDeploy[j].AppDeployName;
                                objJenkins.CreateCDJob(buildModel, jobName_Application_Deployment_AnsiblePlaybook, constants.APPLICATIONDEPLOYMENT, subJobType, EditMode, i, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                    }
                                    else {
                                        console.log(constants.CREATE_APP_ARTIFACTS_DOWNLOAD_JOB_SUCCESS_MSG);
                                    }
                                });                                
                            }*/
                        }
                    });
                }
            } // End of for loop
        } // End of Service Type If
    },
    
    CreateCDMainJob: function (buildModel, dependentJobs, mainJob, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateCDMainJob", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //var jenkinsHostedUrl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;;
        //var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var configxml = "";
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var objcreatejobconfig = new createjobconfig;
        
        configxml = objcreatejobconfig.deploy_mainjob_createconfig(buildModel, dependentJobs, mainJob);
        
        //Frame the build url using urlbuilder               
        buildurl = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url(NEWJOB + mainJob, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort)
        : urlbuilder.build_url(NEWJOB + mainJob, buildModel.BuildServerName, buildModel.BuildServerPort);
        objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
            if (error != null) {
                callback(error, resultdata);
                return;
            }
            callback(null, resultdata);
        });
        

    },
    CreateMiddleJob: function (buildModel, jobName, jobType, EditMode, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateMiddleJob", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = 'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var configxml = "";
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var objcreatejobconfig = new createjobconfig;
        
        if (jobType == constants.BUILD) {
            // Get config xml of Middle tier build job
            configxml = objcreatejobconfig.middle_build_createconfig(buildModel);
        } 
        else if (jobType == constants.UNITTEST) {
            // Get config xml of middle tier build job
            configxml = objcreatejobconfig.middle_unittest_createconfig(buildModel);
        }
        else if (jobType == constants.PUBLISHREPORTS) {
            // Get config xml of Middle tier reports job
            configxml = objcreatejobconfig.middle_publishreports_createconfig(buildModel);
        }
        else if (jobType == constants.SONARANALYSIS) {
            // Get config xml of Middle tier sonar analysis job
            configxml = objcreatejobconfig.middle_sonaranalysis_createconfig(buildModel);
        }              
        else if (jobType == constants.CI) {
            // Get config xml of Middle tier multi job
            configxml = objcreatejobconfig.middle_multijob_createconfig(buildModel);
        }
        
        //Frame the build url using urlbuilder               
        buildurl = urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort);
        if (EditMode == false) {
            objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                callback(null, resultdata);
            });
        }
        else {
            
            objjenkinsapi.JobInfo(jobName, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                if (resultdata != null) {
                    if (resultdata.displayName == jobName) {
                        exists = true;
                    }
                    else if (resultdata.statusMessage == constants.NOT_FOUND) {
                        exists = false;
                    }
                }
                if (exists == false) {
                    objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }
                        callback(null, resultdata);
                    });
                }
                else if (exists == true) {
                    objjenkinsapi.ModifyJob(jobName, jenkinsHostedUrl, configxml, function (error, resultdata) {
                        if (error != null) {
                            callback(error, null);
                            return;
                        }
                        callback(null, resultdata);
                    });
                }
              

           
            });


        }
    },
    
    CreateMiddleTierJobs : function (buildModel, EditMode, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateMiddleTierJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        // Initialise variables
        var objjenkinsapi = new jenkinsapi;
        var buildurl = "";
        var middle_build_configxml = "";
        var middle_reportsjob_configxml = "";
        var middle_multijob_configxml = "";
        var jobName = "";
        var middlejobName_Build = "";
        var middlejobName_Reportsjob = "";
        var middlejobName_Sonaranalysisjob = "";
        var middlejobName_Multijob = "";
        var middlejobName_UnitTestjob = "";
        
        
        jobName = buildModel.ApplicationName;
        
        if (buildModel.SourceControlTool == constants.SVN || buildModel.SourceControlTool == constants.GIT) {
            middlejobName_Build = jobName + constants.MIDDLESUBVERSION;
            middlejobName_Reportsjob = jobName + constants.MIDDLEPUBLISHREPORTS_SUBVERSION;
            middlejobName_Sonaranalysisjob = jobName + constants.MIDDLERUNSONARANALYSIS_SUBVERSION;
            middlejobName_Multijob = jobName + constants.UNDERSCORE + constants.MIDDLETIER;
            middlejobName_UnitTestjob = jobName + constants.MIDDLESUBVERSION_UNITTEST;
        }
        
        var objJenkins = new Jenkins;
        
        objJenkins.CreateMiddleJob(buildModel, middlejobName_Build, constants.BUILD, EditMode, function (error, resultdata) {
            if (error != null) {
                console.log(constants.CREATE_MIDDLE_BUILD_JOB_ERROR_MSG + error);
                callback(error, resultdata);
            }            
            else {
                console.log(constants.CREATE_MIDDLE_BUILD_JOB_SUCCESS_MSG);
                if (buildModel.EnableUnitTestMiddle) {
                    // Create multi job
                    objJenkins.CreateMiddleJob(buildModel, middlejobName_UnitTestjob, constants.UNITTEST, EditMode, function (error, resultdata) {
                        if (error != null) {
                            console.log(constants.CREATE_MIDDLE_UNITTEST_JOB_ERROR_MSG + error);
                            callback(error, resultdata);
                        }
                        else {
                            console.log(constants.CREATE_MIDDLE_UNITTEST_JOB_SUCCESS_MSG);
                            
                            // Check if quality reports are enabled
                            // Create reports job
                            if ((buildModel.EnableCodeAnalysisMiddle) || (buildModel.EnableCodeMetricsMiddle) || (buildModel.EnableCodeCoverageMiddle) || (buildModel.EnableSecAnalysisMiddle) || (buildModel.EnableRiskAnalysisMiddle) || (buildModel.EnableUnitTestMiddle)) {
                                objJenkins.CreateMiddleJob(buildModel, middlejobName_Reportsjob, constants.PUBLISHREPORTS, EditMode, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.CREATE_MIDDLE_REPORTS_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                    }
                                    else {
                                        console.log(constants.CREATE_MIDDLE_REPORTS_JOB_SUCCESS_MSG);
                                        
                                        // Check if sonar analysis is enabled
                                        if (buildModel.EnableSonarAnalysisMiddle) {
                                            // Create sonar analysis job
                                            objJenkins.CreateMiddleJob(buildModel, middlejobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.CREATE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                }
                                                else {
                                                    console.log(constants.CREATE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                                    
                                                    // Create multi job
                                                    objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                        if (error != null) {
                                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                                            callback(error, resultdata);
                                                        }
                                                        else {
                                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                                            callback(null, resultdata);
                                                            
                                                        }
                                                    });
                                                   
                                                    
                                                }
                                            });
                                        }
                                        else {
                                            if (EditMode == true) {
                                                if (buildModel.EnableSonarAnalysisUI) {
                                                    objjenkinsapi.Deletejob(middlejobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                        if (error != null) {
                                                            console.log(constants.DELETE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                                            callback(error, resultdata);
                                                            return;
                                                        }
                                                        else {
                                                            console.log(constants.DELETE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                                        }
                                           //callback(null, resultdata);
                                                    });
                                                }
                                            }
                                            
                                            
                                            
                                            
                                            // Create multi job
                                            objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                }
                                                else {
                                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                                    callback(null, resultdata);
                                        
                                                }
                                            });
                                            
                                        }
                                    }
                                });
                            }
                            else {
                                if (EditMode == true) {
                                    if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI)) {
                                        objjenkinsapi.Deletejob(middlejobName_Reportsjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                            if (error != null) {
                                                console.log(constants.DELETE_MIDDLE_REPORTS_JOB_ERROR_MSG + error);
                                                callback(error, resultdata);
                                                return;
                                            }
                                            else {
                                                console.log(constants.DELETE_MIDDLE_REPORTS_JOB_SUCCESS_MSG);
                                            }
                                    //callback(null, resultdata);
                                        });
                                    }
                                }
                                if (buildModel.EnableSonarAnalysisMiddle) {
                                    objJenkins.CreateMiddleJob(buildModel, middlejobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                            
                                            
                                            // Create multi job
                                            objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                }
                                                else {
                                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                                    callback(null, resultdata);
                                                            
                                                }
                                            });
                                          
                                                    
                                        }
                                    });
                                }
                                else {
                                    if (EditMode == true) {
                                        if (buildModel.EnableSonarAnalysisUI) {
                                            objjenkinsapi.Deletejob(middlejobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.DELETE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                    return;
                                                }
                                                else {
                                                    console.log(constants.DELETE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                                            
                                                }
                                    //callback(null, resultdata);
                                            });
                                        }
                                    }
                                    
                                    // Create multi job
                                    objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                            callback(null, resultdata);
                            
                                        }
                                    });
                                   
                                }
                            }
                            
                        }
                    });
                }
                else {
                    if (EditMode == true) {
                        if (buildModel.EnableUnitTestUI) {
                            objjenkinsapi.Deletejob(middlejobName_UnitTestjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.DELETE_MIDDLE_UNITTEST_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                    return;
                                }
                                else {
                                    console.log(constants.DELETE_MIDDLE_UNITTEST_JOB_SUCCESS_MSG);
                                                            
                                }
                            //callback(null, resultdata);
                            });
                        }
                    }
                    
                    // Check if quality reports are enabled
                    // Create reports job
                    if ((buildModel.EnableCodeAnalysisMiddle) || (buildModel.EnableCodeMetricsMiddle) || (buildModel.EnableCodeCoverageMiddle) || (buildModel.EnableSecAnalysisMiddle) || (buildModel.EnableRiskAnalysisMiddle) || (buildModel.EnableUnitTestMiddle)) {
                        objJenkins.CreateMiddleJob(buildModel, middlejobName_Reportsjob, constants.PUBLISHREPORTS, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log(constants.CREATE_MIDDLE_REPORTS_JOB_ERROR_MSG + error);
                                callback(error, resultdata);
                            }
                            else {
                                console.log(constants.CREATE_MIDDLE_REPORTS_JOB_SUCCESS_MSG);
                                
                                // Check if sonar analysis is enabled
                                if (buildModel.EnableSonarAnalysisMiddle) {
                                    // Create sonar analysis job
                                    objJenkins.CreateMiddleJob(buildModel, middlejobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                            
                                            // Create multi job
                                            objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                }
                                                else {
                                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                                    callback(null, resultdata);
                                                    
                                                }
                                            });
                                            
                                           
                                        }
                                    });
                                }
                                else {
                                    if (EditMode == true) {
                                        if (buildModel.EnableSonarAnalysisUI) {
                                            objjenkinsapi.Deletejob(middlejobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.DELETE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                    return;
                                                }
                                                else {
                                                    console.log(constants.DELETE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                                }
                                           //callback(null, resultdata);
                                            });
                                        }
                                    }
                                    
                                    // Create multi job
                                    objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                            callback(null, resultdata);
                                        
                                        }
                                    });
                                   
                                }
                            }
                        });
                    }
                    else {
                        if (EditMode == true) {
                            if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI)) {
                                objjenkinsapi.Deletejob(middlejobName_Reportsjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.DELETE_MIDDLE_REPORTS_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                        return;
                                    }
                                    else {
                                        console.log(constants.DELETE_MIDDLE_REPORTS_JOB_SUCCESS_MSG);
                                    }
                                    //callback(null, resultdata);
                                });
                            }
                        }
                        
                        if (buildModel.EnableSonarAnalysisMiddle) {
                            objJenkins.CreateMiddleJob(buildModel, middlejobName_Sonaranalysisjob, constants.SONARANALYSIS, EditMode, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                                    
                                    // Create multi job
                                    objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                            callback(null, resultdata);
                                                            
                                        }
                                    });
                                    
                                                    
                                }
                            });
                        }
                        else {
                            if (EditMode == true) {
                                if (buildModel.EnableSonarAnalysisUI) {
                                    objjenkinsapi.Deletejob(middlejobName_Sonaranalysisjob, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.DELETE_MIDDLE_SONAR_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                            return;
                                        }
                                        else {
                                            console.log(constants.DELETE_MIDDLE_SONAR_JOB_SUCCESS_MSG);
                            
                                        }
                                    //callback(null, resultdata);
                                    });
                                }
                            }
                            
                            // Create multi job
                            objJenkins.CreateMiddleJob(buildModel, middlejobName_Multijob, constants.CI, EditMode, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_MIDDLE_MULTI_JOB_SUCCESS_MSG);
                                    callback(null, resultdata);

                                }
                            });
                            
                        }
                    }
                
                   
                }
                
            }
        });

        
    },
    
    CreateDataJob: function (buildModel, jobName, EditMode, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateDataJob", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var configxml = "";
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var objcreatejobconfig = new createjobconfig;
        
        // Get config xml of Data tier job
        configxml = objcreatejobconfig.datajob_createconfig(buildModel);
        
        //Frame the build url using urlbuilder               
        buildurl = urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerName, buildModel.BuildServerPort);
        if (EditMode == false) {
            objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                callback(null, resultdata);
            });
        }
        else {
            callback(null, configxml);
        }

    },
    
    CreateCDJob: function (buildModel, jobName, jobType, subJobType, EditMode, i, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateCDJob", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ?
        'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort : 
        'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var configxml = "";
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var objcreatejobconfig = new createjobconfig;
        
        
        if (jobType == constants.PLATFORMPROVISIONING && (subJobType == constants.OS || subJobType == constants.JDK.toUpperCase() || subJobType == constants.JRE.toUpperCase() || subJobType == constants.TOMCAT.toUpperCase() || subJobType == constants.DOCKER.toUpperCase() || subJobType == constants.CUSTOM_PLAYBOOK.toUpperCase())) {
            // Get config xml of platform provisioning job
            configxml = objcreatejobconfig.Deploy_playbook_platformprovisioning_job_config(buildModel, subJobType, i);
        }
        
        if (jobType == constants.PLATFORMPROVISIONING && subJobType == constants.MAIN) {
            // Get config xml of platform provisioning job
            configxml = objcreatejobconfig.platformprovisioning_main_job_config(buildModel, i);
        }
        else if (jobType == constants.DOWNLOADARTIFACTS && subJobType == constants.NEXUS) {
            
            // Get config xml of application deployment job
            configxml = objcreatejobconfig.Nexusjob_createconfig(buildModel, i);
        }
        else if (jobType == constants.APPLICATIONDEPLOYMENT && subJobType == constants.APPDEPLOY) {
            // Get config xml of App tier build job
            configxml = objcreatejobconfig.Deploy_playbook_applicationdeployment_job_config(buildModel, jobName, i);
        }
        else if (jobType == constants.APPDEPLOY && subJobType == constants.MAIN) {
            var type = "";
            // Get config xml of platform provisioning job
            configxml = objcreatejobconfig.application_deployment_main_job_config(buildModel, type, i);
        }
        else if (jobType == constants.APPLICATIONDEPLOYMENT && subJobType == constants.MAIN) {
            // Get config xml of platform provisioning job
            configxml = objcreatejobconfig.application_deployment_main_job_config(buildModel, constants.APPDEPLOY, i);
        }
        
        
        //Frame the build url using urlbuilder
        buildurl = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort)
        :urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerName, buildModel.BuildServerPort);
        if (EditMode == false) {
            if (configxml != "") {
                objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                    if (error != null) {
                        callback(error, resultdata);
                        return;
                    }
                    callback(null, resultdata);
                });
            }
            else {
                callback(null, "");
            }
        }
        else {
            callback(null, configxml);
        }
    },
    
    CreateMainJob: function (buildModel, jobName, jobType, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateMainJob", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = (buildModel.BuildServerUserID != constants.EMPTY || buildModel.BuildServerUserID != null) ?
        'http://' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort : 
        'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var configxml = "";
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var objcreatejobconfig = new createjobconfig;
        if (jobType == constants.MAIN_WITHOUT_SPACE) {
            configxml = objcreatejobconfig.main_multijob_createconfig(buildModel);
        }
        //Frame the build url using urlbuilder               
        buildurl = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort)
        : urlbuilder.build_url(NEWJOB + jobName, buildModel.BuildServerName, buildModel.BuildServerPort);
        if (EditMode == false) {
            objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                callback(null, resultdata);
            });
        }
        else {
            
            objjenkinsapi.JobInfo(jobName, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                if (resultdata != null) {
                    if (resultdata.displayName == jobName) {
                        exists = true;
                    }
                    else if (resultdata.statusMessage == constants.NOT_FOUND) {
                        exists = false;
                    }
                }
                if (exists == false) {
                    objjenkinsapi.CreateJob(configxml, buildurl, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }
                        callback(null, resultdata);
                    });
                }
                else if (exists == true) {
                    objjenkinsapi.ModifyJob(jobName, jenkinsHostedUrl, configxml, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }
                        callback(null, resultdata);
                       
                    });
                }
            });
        }
    },
    
    DeleteBuildDefinition: function DeleteBuildDefinition(buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteBuildDefinition", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkins = new Jenkins();
        
        if (buildModel.EnableAppTier == true) {
            objJenkins.DeleteUIJobs(buildModel, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                if (resultdata == true && buildModel.EnableMiddleTier == false) {
                    objJenkins.DeleteMainJobs(buildModel, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }

                    });

                }
                callback(null, resultdata);

            });
        }
        
        
        if (buildModel.EnableMiddleTier == true) {
            objJenkins.DeleteMiddleJobs(buildModel, function (error, resultdata) {
                if (error != null) {
                    callback(error, resultdata);
                    return;
                }
                if (resultdata == true) {
                    objJenkins.DeleteMainJobs(buildModel, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }

                    });

                }
                callback(null, resultdata);

            });
        }
         
    },
    
    DeleteCDApplication: function DeleteCDApplication(buildModel, serverDetails, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteCDApplication", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkins = new Jenkins();
        objJenkins.DeleteCDJobs(buildModel, serverDetails, function (error, resultdata) {
            if (error != null) {
                callback(error, resultdata);
                return;
            }
            
            callback(null, resultdata);

        });
        
            
    },
    
    DeleteCDJobs : function (buildModel, serverDetails, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteCDJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //var serverInfo = JSON.parse(serverDetails);
        //var jenkinsHostedUrl = 'http://' + serverInfo[0] + ':' + serverInfo[1];
        //var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var jobNamePrefix = "";
        var jobNames = [];
        var objjenkinsapi = new jenkinsapi;
        jobNamePrefix = buildModel.CDApplicationName;
        objjenkinsapi.AllJobs(serverDetails.DeployServer[0].BuildServerName, serverDetails.DeployServer[0].BuildServerPort, serverDetails.DeployServer[0].BuildServerUserID, serverDetails.DeployServer[0].BuildServerPassword, function (error, jobsList) {
            for (i = 0; i < jobsList.length; i++) {
                if (jobsList[i].name.indexOf(jobNamePrefix) === 0 && jobsList[i].name.indexOf(jobNamePrefix) > -1) {
                    var CDAppname = jobsList[i].name;
                    var lastConfigname = CDAppname.split(jobNamePrefix).slice(1).join(jobNamePrefix);
                    if ((jobNamePrefix + lastConfigname) == CDAppname) {
                        jobNames.push(jobsList[i].name);
                    }

                }
            }
            for (i = 0; i < jobNames.length; i++) {
                objjenkinsapi.Deletejob(jobNames[i], serverDetails.DeployServer[0].BuildServerName, serverDetails.DeployServer[0].BuildServerPort, serverDetails.DeployServer[0].BuildServerUserID, serverDetails.DeployServer[0].BuildServerPassword, function (error, resultdata) {
                    if (error != null) {
                        console.log(constants.APP_TIER_ERROR + jobNames[i] + constants.DELETE_JOB + error);
                        callback(error, resultdata);
                        return;
                    }
                });
            }
        
        });
        
        callback(null, true);
    },
    
    DeleteUIJobs : function (buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteUIJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var jobNamePrefix = "";
        var unitTestName = constants.EMPTY;
        var publishReportsName = constants.EMPTY;
        var sonarName = constants.EMPTY;
        var deployName = constants.EMPTY;
        var jobNames = [];
        var objjenkinsapi = new jenkinsapi;
        jobNamePrefix = buildModel.ApplicationName;
        
        if (buildModel.SourceControlTool == constants.SVN) {
            unitTestName = constants.UISUBVERSION_UNITTEST;
            publishReportsName = constants.UIPUBLISHREPORTS_SUBVERSION;
            sonarName = constants.UIRUNSONARANALYSIS_SUBVERSION;
            deployName = constants.UISUBVERSION_DEPLOY;
            jobNames.push(jobNamePrefix + constants.UNDERSCORE + constants.UISUBVERSION);

        }
        else if (buildModel.SourceControlTool == constants.GIT) {
            unitTestName = constants.GIT_UNITTEST;
            publishReportsName = constants.PUBLISHREPORTS_GIT;
            sonarName = constants.RUNSONARANALYSIS_GIT;
            deployName = constants.GIT_DEPLOY;
            jobNames.push(jobNamePrefix + constants.UNDERSCORE + constants.GIT);
        }
        
        
        if (buildModel.EnableUnitTestUI) {
            jobNames.push(jobNamePrefix + unitTestName);

        }
        
        if ((buildModel.EnableCodeAnalysisUI) || (buildModel.EnableCodeMetricsUI) || (buildModel.EnableCodeCoverageUI) || (buildModel.EnableSecAnalysisUI) || (buildModel.EnableRiskAnalysisUI) || (buildModel.EnableUnitTestUI) || (buildModel.EnableSonarAnalysisUI)) {
            jobNames.push(jobNamePrefix + publishReportsName);

        }
        
        if (buildModel.EnableSonarAnalysisUI) {
            jobNames.push(jobNamePrefix + sonarName);

        }
        if (buildModel.EnableJenDeployPackageUI) {
            jobNames.push(jobNamePrefix + deployName);

        }
        jobNames.push(jobNamePrefix + constants.UNDERSCORE + constants.UITIER);
        
        
        
        for (i = 0; i < jobNames.length; i++) {
            
            objjenkinsapi.Deletejob(jobNames[i], buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                if (error != null) {
                    console.log(constants.APP_TIER_ERROR + jobNames[i] + constants.DELETE_JOB + error);
                    callback(error, resultdata);
                    return;
                }
                else {
                    console.log(constants.APP_TIER + jobNames[i] + constants.JOB_DELETED);
                                                            
                }
                //callback(null, resultdata);
            });
                
                
        }
        callback(null, true);
    },
    
    DeleteMainJobs : function (buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteMainJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jobNamePrefix = "";
        var jobNames = [];
        var objjenkinsapi = new jenkinsapi;
        jobNamePrefix = buildModel.ApplicationName;
        if (buildModel.SourceControlTool == constants.SVN || buildModel.SourceControlTool == constants.GIT) {
            jobNames = [
                jobNamePrefix + constants.UNDERSCORE_MAIN,
            ]
        }
        
        for (i = 0; i < jobNames.length; i++) {
            
            objjenkinsapi.Deletejob(jobNames[i], buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                
                var MainName = "";
                if (jobNames.length == 1) {
                    MainName = jobNames[0];
                }
                else {
                    MainName = jobNames[i];
                }
                if (error != null) {
                    console.log(constants.MAIN_ERROR + MainName + constants.DELETE_JOB + error);
                    callback(error, resultdata);
                    return;
                }
                else {
                    console.log(constants.MAIN + MainName + constants.JOB_DELETED);
                                                            
                }
                callback(null, true);
            });
        }
    },
    
    DeleteMiddleJobs : function (buildModel, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteMiddleJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jenkinsHostedUrl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;;
        var jenkinsnpm = require('jenkins')(jenkinsHostedUrl);
        var jobNamePrefix = "";
        var jobNames = [];
        
        jobNamePrefix = buildModel.ApplicationName;
        if (buildModel.SourceControlTool == constants.SVN || buildModel.SourceControlTool == constants.GIT) {
            jobNames = [
                jobNamePrefix + constants.MIDDLESUBVERSION,
                jobNamePrefix + constants.MIDDLEPUBLISHREPORTS_SUBVERSION,
                jobNamePrefix + constants.MIDDLERUNSONARANALYSIS_SUBVERSION,
                jobNamePrefix + constants.UNDERSCORE + constants.MIDDLETIER,
                jobNamePrefix + constants.MIDDLESUBVERSION_UNITTEST
            ]
        }
        var objjenkinsapi = new jenkinsapi;
        
        for (i = 0; i < jobNames.length; i++) {
            objjenkinsapi.Deletejob(jobNames[i], buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                if (error != null) {
                    console.log(constants.MIDDLE_TIER_ERROR + jobNames[i] + constants.DELETE_JOB + error);
                    callback(error, resultdata);
                    return;
                }
                else {
                    console.log(constants.MIDDLE_TIER + jobNames[i] + constants.JOB_DELETED);
                                                            
                }
                //callback(null, resultdata);
            });
            
        }
        callback(null, true);
    },
    
    
    DeleteBuildConfigEntireNode: function DeleteBuildConfigEntireNode(buildModel, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "DeleteBuildConfigEntireNode", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var data, fd, mainjob, isexists, configxml;
        var jobconfigfilePath = "";
        jobconfigfilePath = path.join(__dirname, '../../config', constants.CMJENKINSJOBCONFIGURATIONXML);
        var exists = fs.existsSync(jobconfigfilePath);
        var etree;
        var et = require('elementtree');
        var applicationName = "";
        if (exists) {
            if (etree == undefined || etree == '') {
                fd = fs.openSync(jobconfigfilePath, 'a');
                data = fs.readFileSync(jobconfigfilePath).toString();
                etree = et.parse(data);
            }
            applicationName = buildModel.ApplicationName;
            mainjob = etree.findall('*/Job/Application');
            
            for (var i = 0; i < mainjob.length; i++) {
                if (mainjob[i].text.indexOf(applicationName) > -1) {
                    var DOMParser = require('xmldom').DOMParser;
                    var doc = new DOMParser().parseFromString(data, 'text/xml');
                    var childNod = doc.getElementsByTagName("Job")[i];
                    childNod.parentNode.removeChild(childNod);
                    fs.writeFileSync(jobconfigfilePath, doc);
                    break;
                }
            }
        }
        if (fd != undefined && fd != '' && fd != null) {
            fs.closeSync(fd);
            callback(null, true);
        }
    },
    
    //Overriding 
    CreateJobs: function CreateJobs(buildModel, EditMode, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateJobs", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildurl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(buildurl);
        //var objJenkinsConfigXml = new createjobconfigxml;
        
        // Generate config xml 
        //objJenkinsConfigXml.Generate_Job_Config_XML(buildurl, buildModel);
        
        // Initialise variables
        var jobName = "";
        var datajobName = "";
        var mainjobName = "";
        
        // decoding path fields
        buildModel.InstalledPath = decodeURIComponent(decodeURIComponent(buildModel.InstalledPath));
        buildModel.BuildOutputPath = decodeURIComponent(decodeURIComponent(buildModel.BuildOutputPath));
        
        jobName = buildModel.ApplicationName;
        
        
        
        mainjobName = jobName + constants.UNDERSCORE_MAIN;
        datajobName = jobName + constants.UNDERSCORE + constants.DATATIER;
        var objJenkins = new Jenkins;
        var objjenkinsapi = new jenkinsapi;
        
        // Check if App tier is enabled
        if (buildModel.EnableAppTier) {
            objJenkins.CreateAppTierJobs(buildModel, EditMode, function (error, resultdata) {
                
                if (error != null) {
                    console.log(constants.APP_TIER_JOBS_ERROR_MSG + error);
                    callback(error, resultdata);
                }            
                else {
                    // Check if Middle tier is enabled
                    if (buildModel.EnableMiddleTier) {
                        objJenkins.CreateMiddleTierJobs(buildModel, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                                callback(error, resultdata);
                            }            
                            else {
                                // Check if Data tier is enabled
                                if ((buildModel.EnableDataTier) && (buildModel.IsDeployDBScriptsReqd == constants.TRUE)) {
                                    
                                    objJenkins.CreateDataJob(buildModel, datajobName, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_DATA_BUILD_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }            
                                        else {
                                            console.log(constants.CREATE_DATA_BUILD_JOB_SUCCESS_MSG);
                                            objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                                                if (error != null) {
                                                    console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                                                    callback(error, resultdata);
                                                }
                                                else {
                                                    console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB1");
                                                    callback(null, resultdata);
                                                }
                                            });
                                        }
                                    });
                                }
                                else {
                                    
                                    objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB2");
                                            callback(null, resultdata);
                                        }
                                    });
                                }
                                

                            }
                        });
                    }
                    else {
                        //if (EditMode == true) {
                        //    objJenkins.DeleteMiddleJobs(buildModel, function (error, resultdata) {
                        //        if (error != null) {
                        //            console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                        //            callback(error, resultdata);
                        //        }
                        //    });
                        //}
                        // Check if Data tier is enabled
                        if ((buildModel.EnableDataTier) && (buildModel.IsDeployDBScriptsReqd == constants.TRUE)) {
                            
                            objJenkins.CreateDataJob(buildModel, datajobName, EditMode, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_DATA_BUILD_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }            
                                else {
                                    console.log(constants.CREATE_DATA_BUILD_JOB_SUCCESS_MSG);
                                    objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                                        if (error != null) {
                                            console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                                            callback(error, resultdata);
                                        }
                                        else {
                                            console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB3");
                                            callback(null, resultdata);
                                        }
                                    });
                                }
                            });
                        }
                        else {
                            
                            //callback(null, resultdata);
                            objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                                if (error != null) {
                                    console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                                    callback(error, resultdata);
                                }
                                else {
                                    console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB4");
                                    callback(null, resultdata);
                                    return;
                                }
                            });
                        }
                        
                    }
                }
            });
        }
        
        // Check if Middle tier is enabled
        else if (buildModel.EnableMiddleTier) {
            if (EditMode == true) {
                objJenkins.DeleteUIJobs(buildModel, function (error, resultdata) {
                    if (error != null) {
                        console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                        callback(error, resultdata);
                    }
                });
            }
            objJenkins.CreateMiddleTierJobs(buildModel, EditMode, function (error, resultdata) {
                if (error != null) {
                    console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                    callback(error, resultdata);
                }            
                else {
                    // Check if Data tier is enabled
                    if ((buildModel.EnableDataTier) && (buildModel.IsDeployDBScriptsReqd == constants.TRUE)) {
                        
                        objJenkins.CreateDataJob(buildModel, datajobName, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log(constants.CREATE_DATA_BUILD_JOB_ERROR_MSG + error);
                                callback(error, resultdata);
                            }            
                            else {
                                console.log(constants.CREATE_DATA_BUILD_JOB_SUCCESS_MSG);
                                objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                                    if (error != null) {
                                        console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                                        callback(error, resultdata);
                                    }
                                    else {
                                        console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB5");
                                        callback(null, resultdata);
                                    }
                                });
                            }
                        });
                    }
                    else {
                        if (EditMode == true) {
                            
                            objjenkinsapi.Deletejob(datajobName, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                                if (error != null) {
                                    callback(error, resultdata);
                                    return;
                                }
                                //callback(null, resultdata);
                            });
                               
                        }
                        objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                            if (error != null) {
                                console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                                callback(error, resultdata);
                            }
                            else {
                                console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB6");
                                callback(null, resultdata);
                            }
                        });
                    }
                }
            });
        }

        // Check if Data tier is enabled
        else if ((buildModel.EnableDataTier) && (buildModel.IsDeployDBScriptsReqd == constants.TRUE)) {
            if (EditMode == true) {
                objJenkins.DeleteUIJobs(buildModel, function (error, resultdata) {
                    if (error != null) {
                        console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                        callback(error, resultdata);
                    }
                });
                objJenkins.DeleteMiddleJobs(buildModel, function (error, resultdata) {
                    if (error != null) {
                        console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                        callback(error, resultdata);
                    }
                });
            }
            
            objJenkins.CreateDataJob(buildModel, datajobName, EditMode, function (error, resultdata) {
                if (error != null) {
                    console.log(constants.CREATE_DATA_BUILD_JOB_ERROR_MSG + error);
                    callback(error, resultdata);
                }            
                else {
                    console.log(constants.CREATE_DATA_BUILD_JOB_SUCCESS_MSG);
                    objJenkins.CreateMainJob(buildModel, mainjobName, constants.MAIN_WITHOUT_SPACE, EditMode, function (error, resultdata) {
                        if (error != null) {
                            console.log(constants.CREATE_MAIN_MULTI_JOB_ERROR_MSG + error);
                            callback(error, resultdata);
                        }
                        else {
                            console.log(constants.CREATE_MAIN_MULTI_JOB_SUCCESS_MSG + " : CB7");
                            callback(null, resultdata);
                        }
                    });
                }
            });
        }
        else {
            if (EditMode == true) {
                objJenkins.DeleteUIJobs(buildModel, function (error, resultdata) {
                    if (error != null) {
                        console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                        callback(error, resultdata);
                    }
                });
                objJenkins.DeleteMiddleJobs(buildModel, function (error, resultdata) {
                    if (error != null) {
                        console.log(constants.MIDDLE_TIER_JOBS_ERROR_MSG + error);
                        callback(error, resultdata);
                    }
                });
                
                objjenkinsapi.Deletejob(datajobName, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                    if (error != null) {
                        callback(error, resultdata);
                        return;
                    }
                    objjenkinsapi.Deletejob(mainjobName, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
                        if (error != null) {
                            callback(error, resultdata);
                            return;
                        }
                        console.log("Delete Job Success : CB8");
                        callback(null, resultdata);
                    });
                });
            }
            console.log("Main Call Back : CB9");
            callback(null, resultdata);
            return;
        }
    },
    
    CreateBuildDefinition: function CreateBuildDefinition(buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateBuildDefinition", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkins = new Jenkins;
        
        var buildurl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(buildurl);
        //var objJenkinsConfigXml = new createjobconfigxml;
        var objjenkinsapi = new jenkinsapi;
        
        var i = 0;
        var stagemainJobs = [];
        //Frame the build server url using urlbuilder
        if (buildModel.Servicetype == "CD") {
            //objJenkins.CreateAppTierCDJobs(buildModel, false, function (error, resultdata) {
            var mainJobName = buildModel.CDApplicationName + constants.UNDERSCORE_MAIN;
            for (j = 0; j < buildModel.DeployStages.length; j++) {
                stagemainJobs.push(buildModel.CDApplicationName + constants.UNDERSCORE + buildModel.Stage[j].Stage + constants.UNDERSCORE_MAIN);
            }
            objJenkins.CreateAppTierCDJobsRecursive(buildModel, i, false, function (error, resultdata) {
                if (error != null) {
                    console.log(constants.CREATE_CREATING_JOB_ERROR_MSG + error);
                    callback(error, resultdata);
                }
                else {
                    console.log(constants.CREATE_CREATING_JOB_SUCCESS_MSG);
                    objJenkins.CreateCDMainJob(buildModel, stagemainJobs, mainJobName, function (error, resultdata) {
                        if (error != null) {
                            console.log("Error in Main Job Creation");
                            callback(error, resultdata);
                        }
                        else {
                            console.log("Main Job Created");
                            // Generate config xml 
                            //objJenkinsConfigXml.Generate_Job_Config_XML(buildurl, buildModel);
                            callback(null, resultdata);
                        }
                    });

                }
            });
        }
        else {
            objJenkins.CreateJobs(buildModel, false, function (error, resultdata) {
                if (error != null) {
                    console.log(constants.CREATE_CREATING_JOB_ERROR_MSG + error);
                    callback(error, resultdata);
                }
                else {
                    console.log(constants.CREATE_CREATING_JOB_SUCCESS_MSG);
                    
                    // Generate config xml 
                    //objJenkinsConfigXml.Generate_Job_Config_XML(buildurl, buildModel);
                    callback(null, resultdata);
                    return;
                }
            });
        }
                
    },
    CreateBuildDeployment: function CreateBuildDeployment(buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CreateBuildDeployment", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkins = new Jenkins;
        
        var buildurl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        var jenkinsnpm = require('jenkins')(buildurl);
        //var objJenkinsConfigXml = new createjobconfigxml;
        
        //Frame the build server url using urlbuilder
        //objJenkinsConfigXml.Generate_Job_Config_XML(buildurl, buildModel);
        callback(null, resultdata);
    },
    
    EditBuildDefinition: function EditBuildDefinition(buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "EditBuildDefinition", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        // decoding URL and path fields
        buildModel.SourceControlUrl = decodeURIComponent(buildModel.SourceControlUrl);
        buildModel.InstalledPath = decodeURIComponent(decodeURIComponent(buildModel.InstalledPath));
        buildModel.BuildOutputPath = decodeURIComponent(decodeURIComponent(buildModel.BuildOutputPath));
        // App tier
        buildModel.ItemsToBuildUI = decodeURIComponent(buildModel.ItemsToBuildUI);
        buildModel.TestSettingsFileNameUI = decodeURIComponent(buildModel.TestSettingsFileNameUI);
        // Middle tier
        buildModel.ItemsToBuildMiddle = decodeURIComponent(buildModel.ItemsToBuildMiddle);
        buildModel.TestSettingsFileNameMiddle = decodeURIComponent(buildModel.TestSettingsFileNameMiddle);
        
        //var jenkinsnpm = require('jenkins')('http://localhost:8080');
        //jenkinsnpm.job.exists('TestJob-Banu-1', function (err, exists) {
        //    debugger;
        //    if (err) throw err;
        
        //    console.log('TestJob-Banu-1', exists);
        //});
        //jenkinsnpm.job.destroy('TestJob-Banu-1', function (err) {
        //    debugger;
        //    if (err) throw err;
        //});
        
        var objJenkins = new Jenkins;
        var buildurl = 'http://' + buildModel.BuildServerName + ':' + buildModel.BuildServerPort;
        //var objJenkinsConfigXml = new createjobconfigxml;
        //Frame the build server url using urlbuilder
        objJenkins.CreateJobs(buildModel, true, function (error, resultdata) {
            
            if (error != null) {
                
                console.log(constants.CREATE_EDITING_JOB_ERROR_MSG + error);
                callback(error, resultdata);
            }
            else {
                console.log(constants.CREATE_EDITING_JOB_SUCCESS_MSG);
                //objJenkinsConfigXml.Generate_Job_Config_XML(buildurl, buildModel);
                callback(null, resultdata);
            }
        });
        
        
        //var http = require('http');
        //var serviceHost = 'localhost';
        ////var serviceHost = 'localhost';
        //var servicePath = '/ODataTFS/DefaultCollection/GenerateJenkinsBuildConfigurationXML';
        //var body = '';
        //var postData = JSON.stringify(buildModel);
        //var options = {
        //    hostname: serviceHost,
        //    path: servicePath,
        //    port: 80,
        //    method: 'POST',
        //    async:false,
        //    headers: {
        //        'OData-Version': '2.3.0',
        //        'OData-MaxVersion': '2.3.0',
        //        'Content-Type': 'application/json',
        //        'Content-Length': postData.length,                       
        //        'Authorization': 'Basic ' + new Buffer('wipro\\wiproat3:Wipro@123').toString('Base64'),
        //        //'Authorization': 'Basic ' + new Buffer(buildModel.BuildServerDomain + '\\' + buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword).toString('Base64'),
        //        'Accept' : 'application/json'
        //    }
        //}
        //var req = http.request(options, function (res) {
            
        //    res.on('data', function (chunk) {
                
        //        body += chunk;
                
        //    });
        //    res.on('end', function () {
                
        //        callback(body);
                
               
        //    });
               
        //});
        //req.on('error', function (e) {
        //    console.log('ERROR: ' + e.message);
        //});
        //req.write(postData);
        //req.end();
        
    },
    
    // Trigger Build
    TriggerBuild : function (buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "TriggerBuild", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildurl = "";
        var objjenkinsapi = new jenkinsapi;
        var jobName = buildModel.ApplicationName;
        buildurl = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url('%s/job/' + jobName + '_Main/build' , buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort)
        : urlbuilder.build_url('%s/job/' + jobName + '_Main/build' , buildModel.BuildServerName, buildModel.BuildServerPort);
        objjenkinsapi.BuildJob(buildurl, function (error, resultdata) {
            if (error != null) {
                callback(error, resultdata);
                return;
            }
            callback(null, resultdata);
        });
    },
    //Get specific job build details
    GetBuildDetails: function GetBuildDetails(buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetBuildDetails", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var calls = [];
        var arrBuilds = [];
        var builds = [];
        var selectedjob;
        var buildurl;
        var objJenkinsBuilds;
        var i;
        
        
        buildModel.JOBName.forEach(function (job) {
            calls.push(function (callback) {
                if (job.Type == 'CD') {
                    selectedjob = job.DeployApplicationName;
                } else {
                    selectedjob = job.ApplicationName;
                }
                
                buildurl = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort, selectedjob + constants.UNDERSCORE_MAIN)
                : urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, selectedjob + constants.UNDERSCORE_MAIN);
                //console.log("buildurl " + buildurl);
                objJenkinsBuilds = new Jenkins();
                objJenkinsBuilds.GetLastBuild(buildurl, selectedjob, buildModel, job.ApplicationName, function (resultdata) {
                    //debugger;
                    if (resultdata != "")
                        arrBuilds.push(resultdata);
                    
                    callback(null, arrBuilds);
                });
            });
        });
        
        async.parallel(calls, function (err, result) {
            //debugger;
            arrBuilds.sort(objJenkinsBuilds.dynamicSort("-activityStartTime"));
            
            if (buildModel.NoOfBuilds > arrBuilds.length) {
                builds = [];
                builds = arrBuilds;
                callback(null, builds);
            }
            else if ((arrBuilds.length > 0) && (buildModel.NoOfBuilds > 0)) {
                builds = [];
                for (i = 0; i < buildModel.NoOfBuilds; i++) {
                    builds[i] = arrBuilds[i];
                }
                callback(null, builds);
            }
            else if ((arrBuilds.length > 0) && (buildModel.NoOfBuilds == 0)) {
                builds = [];
                callback(null, builds);
            }
            else {
                callback(null, arrBuilds);
            }
        });
    },
    GetLatestBuild: function GetLatestBuild(buildurl, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetLatestBuild", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objStatus = "";
        var objResult = "";
        var isBuildRunning = false;
        var objJenkinsBuilds;
        var buildStatus;
        
        
        request({ method: 'GET', url: buildurl }, function (error, response, body) {
            //debugger;
            objJenkinsBuilds = new Jenkins();
            if (error || response.statusCode !== 200) {
                callback("");
                return;
            }
            data = JSON.parse(body.toString());
            objStatus = data.building;
            objResult = data.result;
            
            if (objStatus != null) {
                isBuildRunning = Boolean(objStatus);
                
                if (isBuildRunning) {
                    buildStatus = constants.INPROGRESS;
                } 
                else {
                    buildStatus = "";
                    if (objResult != null) {
                        if (objResult == constants.FAILURE) buildStatus = constants.FAILED;
                        else if (objResult == constants.SUCCESS) buildStatus = constants.SUCCEEDED;
                    }
                }
            }
            
            callback(buildStatus);
            
        });
    },
    GetLastBuild: function GetLastBuild(buildurl, selectedjob, buildModel, applicationName, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetLastBuild", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objDisplayBuildNo = "";
        var objDate = "";
        //var objTimeStamp = "";
        var objDuration = "";
        var objStatus = "";
        var objResult = "";
        var isBuildRunning = false;
        var inputDate = "";
        var objJenkins;
        var logFile;
        
        //logFile = "\\\\" + buildModel.BuildServerName + "\\" + buildModel.InstalledPath.replace("%3A", "").replace("%5C", "\\").toString() + "\\jobs\\" + selectedjob + constants.UNDERSCORE_MAIN + "\\builds\\";
        var installedPath = buildModel.InstalledPath;
        logFile = "\\\\" + buildModel.BuildServerName + "\\" + installedPath.substring(installedPath.indexOf("%5C") + 3, installedPath.length).replace("%5C", "\\") + "\\jobs\\" + selectedjob + constants.UNDERSCORE_MAIN + "\\builds\\";
        
        request({ method: 'GET', url: buildurl }, function (error, response, body) {
            //debugger;
            if (error || response.statusCode !== 200) {
                callback("");
                return;
            }
            //get json data
            
            data = JSON.parse(body.toString());
            objJenkins = new Jenkins();
            
            objJenkins.index = 1;
            objJenkins.teamProject = selectedjob;
            objJenkins.buildNumber = data.number;
            objDisplayBuildNo = data.fullDisplayName;
            
            objDate = data.timestamp;
            //objTimeStamp = data.timestamp;
            objDuration = data.duration;
            objStatus = data.building;
            objResult = data.result;
            objJenkins.userName = data.actions[0].causes[0].userName;
            
            if (objDisplayBuildNo != null) {
                var temp = objDisplayBuildNo;
                temp = temp.replace(selectedjob, "");
                temp = temp.replace("#", "");
                objJenkins.buildDefinition = selectedjob;
                console.log("buildno--" + objJenkins.buildDefinition);
                
                objDisplayBuildNo = objDisplayBuildNo.replace(" ", "_").toString();
                objJenkins.buildNumberWithName = objDisplayBuildNo.replace("#", "").toString();
                objJenkins.applicationName = applicationName;
            }
            
            //objJenkins.LogFileName = "";
            objJenkins.LogFileName = logFile + objDate + "\\log";//"";
            //objDate = objDate.replace("_", " ").toString();
            //var dateandtime = objDate.split("_");
            //objDate = dateandtime[0] + " " + dateandtime[1].replace("-", ":").toString();
            var date = new Date(objDate);
            //Jenkins 1.5 last build response gets build start time but 2.0 gets Build Number in ID field, hence the timestamp field converted to Datetime
            objJenkins.activityStartTime = [date.getMonth() + 1,
                date.getDate(),
                date.getFullYear()].join('/') + ' ' +
              [date.getHours(),
                date.getMinutes(),
                date.getSeconds()].join(':');
            //objJenkins.activityStartTime = moment(objDate).format('MM/DD/YYYY HH:mm:ss');
            
            //if (objTimeStamp != null) {
            //    inputDate = new Date(objTimeStamp.toString());
            //    objJenkins.activityStartTime = moment(inputDate, "MM/DD/YYYY hh:mm:ss");
            
            //} else if (objDate != null) {
            //    inputDateInString = new Date(objDate.toString());
            //    inputDate = moment(inputDateInString, "YYYY-MM-DD_HH-MM-SS");
            //    objJenkins.activityStartTime = moment(inputDate, "MM/DD/YYYY hh:mm:ss");
            //}
            
            var objJenkinsService = new Jenkins;
            objJenkins.activityEndTime = objJenkinsService.formatDate(new Date(new Date(objJenkins.activityStartTime).getTime() + objDuration));
            
            //if (objDuration != null) {
            //    //inputDate = moment(objJenkins.activityStartTime, constants.DATETIMEFORMAT);
            //    inputDate = new Date(objJenkins.activityStartTime);
            //    var endDateinTimeStamp = inputDate.getTime() + 477621;
            //    var endDate = new Date(endDateinTimeStamp);
            //    objJenkins.activityEndTime = moment(endDate, constants.DATETIMEFORMAT);
            //}
            //else {
            //    inputDate = new Date();
            //    objJenkins.activityEndTime = moment(inputDate, constants.DATETIMEFORMAT);
            //}
            
            if (objStatus != null) {
                isBuildRunning = Boolean(objStatus);
                
                if (isBuildRunning) {
                    objJenkins.currentActivity = constants.RUNNING;
                    objJenkins.activityStatus = constants.INPROGRESS;
                }
                else {
                    objJenkins.activityStatus = constants.NOTRUNNING;
                    if (objResult != null) {
                        if (objResult == constants.FAILURE) { objJenkins.activityStatus = constants.FAILED }
                        else if (objResult == constants.SUCCESS)
                            objJenkins.activityStatus = constants.SUCCEEDED;
                    }
                }
            }
            
            
            callback(objJenkins);
        });
    },
    
    formatDate: function formatDate(date) {
        return ('{0}/{1}/{2} {3}:{4}:{5}').replace('{0}', date.getMonth() + 1).replace('{1}', date.getDate()).replace('{2}', date.getFullYear()).replace('{3}', date.getHours()).replace('{4}', date.getMinutes()).replace('{5}', date.getSeconds());
    },
    
    
    dynamicSort: function dynamicSort(property) {
        
        var sortOrder = 1;
        if (property[0] == "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        
        return function (a, b) {
            var sortResult = (a[property].valueOf() < b[property].valueOf()) ? -1 : (a[property].valueOf() > b[property].valueOf()) ? 1 : 0;
            return sortResult * sortOrder;
        }
    },
    
    GetStageActivities: function GetStageActivities(buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetStageActivities", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //debugger;
        var objJenkinsService = new Jenkins;
        try {
            objJenkinsService.ReadJsonData(buildModel, pipeLineModel, function (stageActivities) {
                var distinctStages = [];
                
                for (var i = 0; i < stageActivities.length; i++) {
                    var str = stageActivities[i].Stage;
                    if (distinctStages.indexOf(str) == -1) {
                        distinctStages.push(str);
                    }
                }
                callback(null, distinctStages);
            });
            
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    GetStageStatus: function GetStageStatus(buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetStageStatus", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //debugger;
        var objJenkinsService = new Jenkins;
        var redisCacheBuildActivities = buildModel.JOBName + '_' + buildModel.BuildNumber;
        try {
            //debugger;x`
            if (buildModel.Source == constants.CMSERVICEJENKINS) {
                objJenkinsService.ReadCMBuildConfig(buildModel, function (stageActivities) {
                    //debugger;
                    objJenkinsService.GetCMActivityStatus(stageActivities, buildModel, function (buildActivities) {
                        //debugger;
                        callback(null, buildActivities);
                    });
                });
            }
            else {
                objJenkinsService.ReadJsonData(buildModel, pipeLineModel, function (stageActivities) {
                    //debugger;
                    //read from redis cache, if not available get to actual method
                    //if (buildModel.setCache == true) {
                        /*client.get(redisCacheBuildActivities, function (err, reply) {
                            // reply is null when the key is missing 
                            if (reply == null || reply == '[]') {
                                var objJenkinsService = new Jenkins;
                                objJenkinsService.GetActivityStatus(stageActivities, buildModel, function (buildActivities) {
                                    if (buildActivities.length > 0)
                                        client.set(redisCacheBuildActivities, JSON.stringify(buildActivities));
                                    //// Expire in 2 hours - 7200 seconds
                                    //client.expire(redisCacheBuildActivities, 7200);
                                    callback(null, buildActivities);
                                });
                            } else {
                                callback(null, JSON.parse(reply));
                            }
                        });*/
                    //}
                    //else {
                        objJenkinsService.GetActivityStatus(stageActivities, buildModel, function (buildActivities) {
                            callback(null, buildActivities);
                       });
                   //}
                });
            }
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    ReadJsonData: function ReadJsonData(buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "ReadJsonData", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var stageActivities = [];
        var activities = [];
        var activityURL = "";
        var objJenkinsService = new Jenkins;
        
        try {
            if (pipeLineModel.BuildPipeline.length > 0) {
                for (i = 0; i < pipeLineModel.BuildPipeline.length ; i++) {
                    activities = pipeLineModel.BuildPipeline[i].ActivityTrackings;
                    if (buildModel.Type == constants.STAGE) {
                        for (activity = 0; activity < activities.length; activity++) {
                            activityURL = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort, pipeLineModel.BuildPipeline[i].ActivityTrackings[activity].JobName)
                            :urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, pipeLineModel.BuildPipeline[i].ActivityTrackings[activity].JobName);
                            activityURL = activityURL.replace(constants.LASTBUILD, buildModel.BuildNumber);
                            
                            stageActivities.push({
                                URL: activityURL,
                                Stage: pipeLineModel.BuildPipeline[i].StageName,
                                Order: i,
                                AltName: "",
                                isActivity: 'NO',
                                JobName : pipeLineModel.BuildPipeline[i].ActivityTrackings[activity].JobName
                            });
                        }
                    }
                    else if (buildModel.Type == constants.ACTIVITY && pipeLineModel.BuildPipeline[i].StageName == buildModel.SubType) {
                        var activityTrackings = pipeLineModel.BuildPipeline[i].ActivityTrackings;
                        for (activityTracking = 0; activityTracking < activityTrackings.length; activityTracking++) {
                            if (buildModel.InnerType == constants.ACTIVITY && buildModel.IsActivityAltNameGet == constants.NO) {
                                activityURL = '';
                                if (pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].JobName != "") {
                                    activityURL = buildModel.BuildServerUserID != constants.EMPTY ? urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerUserID + ':' + buildModel.BuildServerPassword + '@' + buildModel.BuildServerName, buildModel.BuildServerPort, pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].JobName)
                                    :urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].JobName);
                                    activityURL = activityURL.replace(constants.LASTBUILD, buildModel.BuildNumber);
                                }
                                
                                stageActivities.push({
                                    URL: activityURL,
                                    Stage: pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].JobName.length == 0 ? "" : pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].DisplayText,
                                    Order: activityTracking,
                                    AltName: pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].DisplayText,
                                    isActivity: pipeLineModel.BuildPipeline[i].ActivityTrackings[activityTracking].JobName.length == 0 ? 'YES' : 'NO',
                                    Type: pipeLineModel.BuildPipeline[i].StageName
                                });

                            }
                            else if (buildModel.InnerType == constants.REPORT && pipeLineModel.BuildPipeline[i].Reports.length > 0) {
                                var reports = pipeLineModel.BuildPipeline[i].Reports;
                                for (report = 0; report < reports.length; report++) {
                                    var uilnk = "//" + reports[report].Link + ":" + reports[report].Port + "/" + buildModel.JOBName + "/" + buildModel.BuildNumber + "/" 
                                                 + reports[report].Directory + "/" + reports[report].ReportName;
                                    link = "//" + reports[report].Link + ":" + reports[report].Port;
                                    var reportdtl = [
                                        {
                                            ReportName: reports[report].DisplayText,
                                            ReportPath: reports[report].DisplayText.indexOf(constants.SONAR_REPORT) > -1 ? link : uilnk,
                                            Type: "UI"
                                        }
                                    ];
                                    stageActivities[report] = reportdtl;
                                }
                            }

                            else if (buildModel.InnerType == constants.UNITTEST) {
                                var stageActivityCount = 0;
                                var unitTestPath = "";
                                if (buildModel.UITierAppType == "Java") {
                                    unitTestPath = reportsSharePath + buildModel.JOBName + "/" + buildModel.BuildNumber + "/" + constants.BUILDSUTCRESULTS + "/" + buildModel.ProjectFolderUI + 'TestResults.html';
                                    unitTestPath = unitTestPath.replace(buildModel.ProjectFolderUI + 'TestResults.html', 'overview-summary.html');
                                    stageActivities = objJenkinsService.ReadUnitTestResults(unitTestPath, "", stageActivityCount, stageActivities);
                                }
                                else if (buildModel.UITierAppType == ".NET") {
                                    unitTestPath = reportsSharePath + buildModel.JOBName + "/" + buildModel.BuildNumber + "/" + constants.BUILDSUTCRESULTS + "/" + buildModel.ProjectFolderUI + 'TestResults.html';
                                    stageActivities = objJenkinsService.ReadUnitTestResults(unitTestPath, "", stageActivityCount, stageActivities);
                                }
                            }

                            else if (buildModel.InnerType == constants.RISK && pipeLineModel.BuildPipeline[i].Reports.length > 0) {
                                var reports = pipeLineModel.BuildPipeline[i].Reports;
                                for (report = 0; report < reports.length; report++) {
                                    if (reports[report] == constants.RISK_ANALYSIS) {
                                        link = reportsSharePath + buildModel.JOBName + "/" + buildModel.BuildNumber + "/" 
                                                        + reports[report].Directory + "/" + reports[report].ReportName;
                                        
                                        //link = "C:/Build/Reports/BuildsRiskAnalysisReport/BuildAnalysis.html";
                                        if (fs.existsSync(link)) {
                                            var riskdtl = [
                                                { ReportPath: link }
                                            ];
                                            stageActivities[risk] = riskdtl;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            callback(stageActivities);
        }
        catch (ex) {
            console.log("Error occured while executing function : ReadJsonData");
        }
    },
    
    ReadBuildConfig: function ReadBuildConfig(buildModel, pipeLineModel, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "ReadBuildConfig", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var filePath = path.join(__dirname, '../../config/', constants.JENKINSJOBCONFIGURATIONXML);
        var xml2js = require('xml2js');
        var parser = new xml2js.Parser();
        var xmlData;
        var fileData;
        var activities = [];
        var jobs = [];
        var stageActivities = [];
        var activityURL = "";
        var fs = require('fs');
        
        try {
            fileData = fs.readFileSync(filePath, 'ascii');
            //fileData = fileData.substring(3, fileData.length);
            var arrayLen = 0;
            parser.parseString(fileData, function (err, result) {
                xmlData = result;
            });
            if (xmlData != null) {
                
                jobs = xmlData.JobConfiguration.JobInformation[0].Job;
                for (var jobIndex = 0; jobIndex < jobs.length; jobIndex++) {
                    if (xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].JobName[0] == buildModel.JOBName) {
                        //var jobName = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].JobName[0];
                        //var pipelinesStages = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].PipeLines[0].PipeLine;
                        
                        var jobName = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].JobName[0];
                        var ServiceType = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].ServiceType[0];
                        if (ServiceType == 'CI') {
                            var pipelinesStages = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].CI[0].PipeLines[0].PipeLine;
                        }
                        if (ServiceType == 'CD') {
                            var pipelinesStages = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].CD[0].PipeLines[0].PipeLine;
                        }
                        //if (ServiceType == 'CD') {
                        //    var pipelinesStages = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].CD[0].PipeLines[0].PipeLine;
                        //}
                        //if (ServiceType == 'CICD') {
                        //    var pipelinesStages = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].CD[0].PipeLines[0].PipeLine;
                        //}
                        
                        for (var i = 0; i < pipelinesStages.length; i++) {
                            var activityTrackings = pipelinesStages[i].ActivityTrackings[0].ActivityTracking;
                            var objJenkinsService = new Jenkins;
                            //debugger;
                            if (buildModel.Type == constants.STAGE) {
                                activities = pipelinesStages[i].Activities[0].Activity;
                                for (activity = 0; activity < activities.length; activity++) {
                                    activityURL = urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, activities[activity].$.Name);
                                    activityURL = activityURL.replace(constants.LASTBUILD, buildModel.BuildNumber)
                                    
                                    stageActivities.push({
                                        URL: activityURL,
                                        Stage: pipelinesStages[i].Stage[0],
                                        Order: i,
                                        AltName: "",
                                        isActivity: 'NO',
                                        JobName : activities [activity].$.Name
                                    });
                                }
                            }
                            else if (buildModel.IsActivityAltNameGet == constants.YES && pipelinesStages[i].Stage[0] == buildModel.SubType) {
                                //debugger;                          
                                for (activityTracking = 0; activityTracking < activityTrackings.length; activityTracking++) {
                                    if (activityTrackings[activityTracking].Type[0] == constants.REPORT) {
                                        var reports = activityTrackings[activityTracking].Reports[0].Report;
                                        for (report = 0; report < reports.length; report++) {
                                            if (reports[report].$.Type == buildModel.ActivityAltName) {
                                                var uilnk = reports[report].$.Link + jobName + "/" + buildModel.BuildNumber + "/" 
                                                    + reports[report].$.Directory + "/" + reports[report].$.Name;
                                                
                                                var uilnktmp = "http://10.1.0.8:8082" + "/" + buildModel.BuildNumber + "/" 
                                                + reports[report].$.Directory + "/" + reports[report].$.Name;
                                                //link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + "/" 
                                                //        + reports[report].$.Directory + "/" + reports[report].$.Name;
                                                
                                                //  if (fs.existsSync(link)) {
                                                stageActivities = {
                                                    ReportName: reports[report].$.Text,
                                                    ReportPath: uilnk,
                                                    Type: "UI"
                                                };
                                                // }
                                                //else {
                                                //    var mtLnk = reports[report].$.Link + jobName + "/" + buildModel.BuildNumber + "/"
                                                //        + reports[report].$.Directory + "/" + reports[report].$.Name;
                                                //    link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + constants.SLASH_MIDDLETIER 
                                                //        + reports[report].$.Directory + "/" + reports[report].$.Name;
                                                
                                                //    if (fs.existsSync(link)) {
                                                //        stageActivities = {
                                                //            ReportName: reports[report].$.Text + "(MT)",
                                                //            ReportPath: mtLnk,
                                                //            Type: "MT"
                                                //        };
                                                //    }
                                                //}
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (buildModel.Type == constants.ACTIVITY && pipelinesStages[i].Stage[0] == buildModel.SubType) {
                                var activityTrackings = pipelinesStages[i].ActivityTrackings[0].ActivityTracking;
                                for (activityTracking = 0; activityTracking < activityTrackings.length; activityTracking++) {
                                    if (buildModel.InnerType == constants.ACTIVITY && activityTrackings[activityTracking].Type[0] == buildModel.InnerType 
                                        && buildModel.IsActivityAltNameGet == constants.NO) {
                                        //debugger;
                                        activities = activityTrackings[activityTracking].Activities[0].Activity;
                                        
                                        for (activity = 0; activity < activities.length; activity++) {
                                            //debugger;
                                            activityURL = activities[activity].$.Name != "" ? urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, activities[activity].$.Name) : "";
                                            activityURL = activityURL.replace(constants.LASTBUILD, buildModel.BuildNumber)
                                            stageActivities.push({
                                                URL: activityURL,
                                                Stage: activities[activity].$.Name.length == 0 ? activities[activity].$.AltName : activities[activity].$.Type,
                                                Order: activities[activity].$.Id,
                                                AltName: activities[activity].$.Type,
                                                isActivity: activities[activity].$.Name.length == 0 ? 'YES' : 'NO',
                                                Type: activities[activity].$.Text
                                            });
                                           
                                        }
                                    }
                                    else if (buildModel.InnerType == constants.REPORT && activityTrackings[activityTracking].Type[0] == buildModel.InnerType) {
                                        //debugger;
                                        var reports = activityTrackings[activityTracking].Reports[0].Report;
                                        var reportsCount = 0;
                                        
                                        for (report = 0; report < reports.length; report++) {
                                            
                                            var uilnk = reports[report].$.Link + jobName + "/" + buildModel.BuildNumber + "/" 
                                                 + reports[report].$.Directory + "/" + reports[report].$.Name;
                                            link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + "/" 
                                                + reports[report].$.Directory + "/" + reports[report].$.Name;
                                            
                                            var tmplink = "http://10.1.0.7:9000";
                                            
                                            
                                            
                                            //link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + "/"
                                            //    + reports[report].$.Directory + "/" + reports[report].$.Name;
                                            
                                            //var tmplink = "http://10.1.0.8:9000/" + jobName + "/" + buildModel.BuildNumber + "/" 
                                            //    + reports[report].$.Directory + "/" + reports[report].$.Name;
                                            
                                            //if (fs.existsSync(link)) {
                                            var reportdtl = [
                                                {
                                                    ReportName: reports[report].$.Text,
                                                    ReportPath: reports[report].$.Text.indexOf(constants.SONAR_REPORT) > -1 ? reports[report].$.Link : uilnk,
                                                    Type: "UI"
                                                }
                                            ];
                                            stageActivities[reportsCount] = reportdtl;
                                            reportsCount = reportsCount + 1;
                                            //}
                                            //else {
                                            //    var mtLnk = reports[report].$.Link + "/" + buildModel.BuildNumber + constants.SLASH_MIDDLETIER
                                            //        + reports[report].$.Directory + "/" + reports[report].$.Name;
                                            //    link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + constants.SLASH_MIDDLETIER 
                                            //            + reports[report].$.Directory + "/" + reports[report].$.Name;
                                                
                                            //    if (fs.existsSync(link)) {
                                            //        var reportdtl = [
                                            //            {
                                            //                ReportName: reports[report].$.Text + "(MT)",
                                            //                ReportPath: reports[report].$.Text.indexOf(constants.SONAR_REPORT) > -1 ? reports[report].$.Link : mtLnk,
                                            //                Type: "MT"
                                            //            }
                                            //        ];
                                            //        stageActivities[reportsCount] = reportdtl;
                                            //        reportsCount = reportsCount + 1;
                                            //    }
                                            //}
                                        }
                                    }
                                    
                                    else if (buildModel.InnerType == constants.RISK && activityTrackings[activityTracking].Type[0] == buildModel.InnerType) {
                                        var risks = activityTrackings[activityTracking].Risks[0].Risk;
                                        for (risk = 0; risk < risks.length; risk++) {
                                            
                                            link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + "/" 
                                                        + risks[risk].$.Directory + "/" + risks[risk].$.Name;
                                            
                                            //link = "C:/Build/Reports/BuildsRiskAnalysisReport/BuildAnalysis.html";
                                            if (fs.existsSync(link)) {
                                                var riskdtl = [
                                                    { ReportPath: link }
                                                ];
                                                stageActivities[risk] = riskdtl;
                                            }
                                            else {
                                                link = reportsSharePath + jobName + "/" + buildModel.BuildNumber + constants.SLASH_MIDDLETIER 
                                                        + risks[risk].$.Directory + "/" + risks[risk].$.Name;
                                                
                                                if (fs.existsSync(link)) {
                                                    var riskdtl = [
                                                        { ReportPath: link }
                                                    ];
                                                    stageActivities[risk] = riskdtl;
                                                }
                                            }
                                        }
                                    }
                                    else if (buildModel.InnerType == constants.UNITTEST && activityTrackings[activityTracking].Type[0] == buildModel.InnerType) {
                                        var stageActivityCount = 0;
                                        var unitTestPath = "";
                                        if (buildModel.UITierAppType == "Java") {
                                            unitTestPath = reportsSharePath + jobName + "/" + buildModel.BuildNumber + "/" + constants.BUILDSUTCRESULTS + "/" + buildModel.ProjectFolderUI + 'TestResults.html';
                                            unitTestPath = unitTestPath.replace(buildModel.ProjectFolderUI + 'TestResults.html', 'overview-summary.html');
                                            stageActivities = objJenkinsService.ReadUnitTestResults(unitTestPath, "", stageActivityCount, stageActivities);
                                        }
                                        else if (buildModel.UITierAppType == ".NET") {
                                            unitTestPath = reportsSharePath + jobName + "/" + buildModel.BuildNumber + "/" + constants.BUILDSUTCRESULTS + "/" + buildModel.ProjectFolderUI + 'TestResults.html';
                                            stageActivities = objJenkinsService.ReadUnitTestResults(unitTestPath, "", stageActivityCount, stageActivities);
                                        }
                                    }
                                }
                            }
                            
                        }
                        callback(stageActivities);
                        break;
                    }
                }
            }
        }
        catch (ex) {
        }
    },
    
    ReadUnitTestResults: function ReadUnitTestResults(reportPath, reportType, stageActivityCount, stageActivities) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "ReadUnitTestResults", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkinsService = new Jenkins;
        
        if (fs.existsSync(reportPath)) {
            if (reportPath.indexOf('overview-summary.html') > -1) {
                utcFile = fs.readFileSync(reportPath).toString();
                parsedHTML = cherio.load(utcFile);
                parsedHTML('th').each(function (th_index, th) {
                    var th_text = parsedHTML(this).text();
                    var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                    if (prop_name == constants.TESTS_LOWERCASE) {
                        if (stageActivities.filter(objJenkinsService.checkPropertyNameExists.bind(null, "Total UTCs (" + reportType + ")")) == false) {
                            var index = parsedHTML(this).index();
                            var tot_tests = parsedHTML(this).parent().next().find("td").eq(index).text();
                            if (tot_tests != null)
                                testsTotal = tot_tests;
                            else testsTotal = constants.ZERO;
                            
                            builddtl = {
                                ActivityName: "Total UTCs (" + reportType + ")",                          
                                Status: testsTotal
                            };
                            
                            stageActivities[stageActivityCount] = builddtl;
                            stageActivityCount++;
                        }
                    }
                    else if (prop_name == constants.ERRORS) {
                        if (stageActivities.filter(objJenkinsService.checkPropertyNameExists.bind(null, "UTCs Passed (" + reportType + ")")) == false) {
                            var index = parsedHTML(this).index();
                            var errored_tests = parsedHTML(this).parent().next().find("td").eq(index).text();
                            if (errored_tests != null) {
                                if (testsFailed != null) {
                                    testsPassed = testsTotal - (testsFailed + errored_tests);
                                }
                                else testsPassed = testsTotal - errored_tests;
                            }
                            else testsPassed = constants.ZERO;
                            
                            builddtl = {
                                ActivityName: "UTCs Passed (" + reportType + ")",                           
                                Status: testsPassed
                            };
                            stageActivities[stageActivityCount] = builddtl;
                            stageActivityCount++;
                        }
                    }
                    else if (prop_name == constants.FAILURES) {
                        if (stageActivities.filter(objJenkinsService.checkPropertyNameExists.bind(null, "UTCs Failed (" + reportType + ")")) == false) {
                            var index = parsedHTML(this).index();
                            var failed_tests = parsedHTML(this).parent().next().find("td").eq(index).text();
                            if (failed_tests != null)
                                testsFailed = failed_tests;
                            else testsFailed = constants.ZERO;
                            
                            builddtl = {
                                ActivityName: "UTCs Failed (" + reportType + ")",                       
                                Status: testsFailed
                            };
                            stageActivities[stageActivityCount] = builddtl;
                            stageActivityCount++;
                        }
                    }
                });
            }        
            else if (reportPath.indexOf('TestResults.html') > -1) {
                var utcFile = fs.readFileSync(reportPath).toString();
                var parsedHTML = cherio.load(utcFile);
                //debugger;
                parsedHTML('#tMainSummary th').each(function (th_index, th) {
                    var th_text = parsedHTML(this).text();
                    var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                    if (prop_name == constants.TOTALTESTS) {
                        var index = parsedHTML(this).index();
                        var tot_tests = parsedHTML(this).parent().next().find("td").eq(index).text();
                        if (tot_tests != null)
                            testsTotal = tot_tests;
                        else testsTotal = constants.ZERO;
                        
                        builddtl = {
                            ActivityName: "Total UTCs (" + reportType + ")",           
                            Status: testsTotal
                        };
                        stageActivities[stageActivityCount] = builddtl;
                        stageActivityCount++;
                    }
                    else if (prop_name == constants.PASSEDNAME) {
                        var index = parsedHTML(this).index();
                        var passed_tests = parsedHTML(this).parent().next().find("td").eq(index).text();
                        if (passed_tests != null)
                            testsPassed = passed_tests;
                        else testsPassed = constants.ZERO;
                        
                        builddtl = {
                            ActivityName: "UTCs Passed (" + reportType + ")",                  
                            Status: testsPassed
                        };
                        stageActivities[stageActivityCount] = builddtl;
                        stageActivityCount++;
                    }
                    else if (prop_name == constants.FAILEDNAME) {
                        var index = parsedHTML(this).index();
                        var failed_tests = parsedHTML(this).parent().next().find("td").eq(index).text();
                        if (failed_tests != null)
                            testsFailed = failed_tests;
                        else testsFailed = constants.ZERO;
                        
                        builddtl = {
                            ActivityName: "UTCs Failed (" + reportType + ")",
                            Status: testsFailed
                        };
                        stageActivities[stageActivityCount] = builddtl;
                        stageActivityCount++;
                    }
                });
            }
        }
        return stageActivities;
    },
    
    checkPropertyNameExists: function checkPropertyNameExists(stageActivity, propertyName) {
        return stageActivity == propertyName.ActivityName ? true : false;
    },
    
    GetStatus: function GetStatus(buildurl, buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetStatus", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objStatus;
        var isBuildRunning = false;
        var buildStatus;
        var objResult;
        var objLogID;
        var JobName;
        var objJenkinsService = new Jenkins;
        //debugger;
        if (buildurl != "") {
            //debugger;
            buildModel.IsActivityAltNameGet = constants.NO;
            request({ method: 'GET', url: buildurl }, function (error, response, body) {
                if (error || response.statusCode !== 200) {
                    if (buildModel.Type == constants.STAGE)
                        callback(constants.EMPTY);
                    else
                        callback(constants.EMPTY);
                    return;
                }
                
                var data = JSON.parse(body.toString());
                objStatus = data.building;
                objResult = data.result;
                objLogID = data.id;
                JobName = data.fullDisplayName.split(' ')[0];
                
                if (objStatus != null) {
                    isBuildRunning = Boolean(objStatus);
                    
                    if (isBuildRunning) {
                        buildStatus = constants.INPROGRESS;
                    } 
                    else {
                        buildStatus = "";
                        if (objResult != null) {
                            if (objResult == constants.FAILURE) buildStatus = constants.FAILED;
                            else if (objResult == constants.SUCCESS) buildStatus = constants.SUCCEEDED;
                        }
                    }
                }
                
                callback(buildStatus, objLogID, JobName);
            });
        }
        else {
            //debugger;            
            objJenkinsService.GetBuildActivityDetail(buildModel.ActivityAltName, buildModel, function (result) {
                //debugger;
                callback(result);
            });
        }
    },
    
    GetJobStatusSyncMain: function GetJobStatusSyncMain(stageActivities, buildModel, i, buildActivities, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetJobStatusSyncMain", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildurl;
        var objJenkinsBuilds;
        var x = i;
        var processItems = function (x) {
            if (x < stageActivities.length) {
                buildurl = urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, stageActivities[i].JobName);
                if (stageActivities.length > 0) {
                    objJenkinsBuilds = new Jenkins();
                    objJenkinsBuilds.GetLatestBuild(buildurl, function (resultdata) {
                        if (resultdata != "")
                            buildActivities.push({
                                Stage: stageActivities[x].Stage,
                                Status: resultdata,
                                Order: stageActivities[x].Order,
                                AltName: stageActivities[x].AltName,
                                isActivity: stageActivities[x].isActivity,
                                isStage: buildModel.Type,
                                Type: stageActivities[x].Type
                            });
                        
                        processItems(x + 1);

                    });
                }
            }
            else {
                callback(null, buildActivities);
            }
        };
    },
    
    GetJobStatusSync: function GetJobStatusSync(stageActivities, buildModel, i, buildActivities, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetJobStatusSync", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var buildurl;
        var objJenkinsBuilds;
        var x = i;
        buildurl = urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, stageActivities[i].JobName);
        if (stageActivities.length > 0) {
            objJenkinsBuilds = new Jenkins();
            objJenkinsBuilds.GetLatestBuild(buildurl, function (resultdata) {
                if (resultdata != "")
                    buildActivities.push({
                        Stage: stageActivities[x].Stage,
                        Status: resultdata,
                        Order: stageActivities[x].Order,
                        AltName: stageActivities[x].AltName,
                        isActivity: stageActivities[x].isActivity,
                        isStage: buildModel.Type,
                        Type: stageActivities[x].Type
                    });
                
                if ((stageActivities.length - 1) > i) {
                    i = i + 1;
                    //objJenkinsBuilds.GetJobStatusSync(stageActivities, buildModel, i, buildActivities, function (error,resultdata) {
                    //send the callback to calling method after last loop.
                    //callback(null, resultdata);
                    //});
                    callback(null, buildActivities);
                }
                else {
                    callback(null, buildActivities);
                }
            });
        }
    },
    
    GetActivityStatus: function GetActivityStatus(stageActivities, buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetActivityStatus", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var calls = [];
        var preResults = [];
        var buildActivities = [];
        
        stageActivities.forEach(function (stageActivity) {
            calls.push(function (callback) {
                //debugger;
                var objJenkinsService = new Jenkins;
                //debugger;
                buildModel.ActivityAltName = stageActivity.Stage;
                objJenkinsService.GetStatus(stageActivity.URL, buildModel, function (resultdata, logId, JobName) {
                    //debugger;
                    if (resultdata != "") {
                        preResults.push({
                            Stage: stageActivity.Stage,
                            Status: resultdata,
                            Order: stageActivity.Order,
                            AltName: stageActivity.AltName,
                            isActivity: stageActivity.isActivity,
                            isStage: buildModel.Type,
                            Type: stageActivity.Type,
                            LogId: logId,
                            JobName: JobName
                        });
                    }
                    callback(null, preResults);
                });
            });
        });
        
        async.parallel(calls, function (err, result) {
            //debugger;
            arrayLen = 0;
            if (err)
                return console.log(err);
            //debugger;
            for (i = 0; i < preResults.length; i++) {
                if (i == 0) {
                    builddtl = [
                        {
                            ActivityName: preResults[i].isActivity == "YES" ? preResults[i].AltName :  preResults[i].Stage,
                            Status: preResults[i].Status,
                            Order: preResults[i].Order,
                            Type: preResults[i].Type,
                            LogId: preResults[i].LogId,
                            JobName: preResults[i].JobName
                        }
                    ];
                    buildActivities[arrayLen] = builddtl;
                    arrayLen = arrayLen + 1;
                }
                else {
                    var foundmatch = 0;
                    for (j = 0; j < buildActivities.length; j++) {
                        if (preResults[i].Stage == buildActivities[j][0].ActivityName) {
                            foundmatch = 1;
                            if (buildActivities[j][0].Status == constants.INPROGRESS) break;
                            else if (buildActivities[j][0].Status != constants.SUCCEEDED) break;
                            else
                                buildActivities[j][0].Status = preResults[i].Status;
                            
                            break;
                        }
                        if (j == buildActivities.length - 1 && foundmatch == 0) {
                            builddtl = [
                                {
                                    ActivityName: preResults[i].isActivity == "YES" ? preResults[i].AltName : preResults[i].Stage,
                                    Status: preResults[i].Status,
                                    Order: preResults[i].Order,
                                    Type: preResults[i].Type,
                                    LogId: preResults[i].LogId,
                                    JobName: preResults[i].JobName
                                }
                            ];
                            buildActivities[arrayLen] = builddtl;
                            arrayLen = arrayLen + 1;
                            break;
                        }
                    }
                }
            }
            //debugger;
            buildActivities.sort(function (a, b) {
                //debugger;
                return a[0].Order - b[0].Order
            })
            callback(buildActivities);
        });
        
    },
    
    GetBuildActivities: function GetBuildActivities(buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetBuildActivities", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkinsService = new Jenkins;
        var redisCacheActivities = buildModel.JOBName + constants.UNDERSCORE + buildModel.BuildNumber + constants.UNDERSCORE + buildModel.Type + constants.UNDERSCORE + buildModel.SubType;
        try {
            if (buildModel.Source == constants.CMSERVICEJENKINS) {
                objJenkinsService.ReadCMBuildConfig(buildModel, function (stageActivities) {
                    //debugger;
                    objJenkinsService.GetCMActivityStatus(stageActivities, buildModel, function (buildActivities) {
                        //debugger;
                        callback(null, buildActivities);
                    });
                });
            }
            else {
                buildModel.IsActivityAltNameGet = constants.NO;
                objJenkinsService.ReadJsonData(buildModel, pipeLineModel, function (stageActivities) {
                    //read from redis cache, if not available get to actual method
                    //if (buildModel.setCache == true) {
                     /*   client.get(redisCacheActivities, function (err, reply) {
                            var objJenkinsService = new Jenkins;
                            // reply is null when the key is missing 
                            if (reply == null || reply == '[]') {
                                objJenkinsService.GetActivityStatus(stageActivities, buildModel, function (buildActivities) {
                                    if (buildActivities.length > 0 && buildActivities.length == stageActivities.length)
                                        client.set(redisCacheActivities, JSON.stringify(buildActivities));
                                    callback(null, buildActivities);
                                });
                            } else {
                                callback(null, JSON.parse(reply));
                            }
                        });
                    }*/
                    //else {
                        objJenkinsService.GetActivityStatus(stageActivities, buildModel, function (buildActivities) {
                            callback(null, buildActivities);
                        })
                    //}
                });
            }
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    GetActivityDetails : function GetActivityDetails(stage, buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetActivityDetails", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkinsService = new Jenkins;
        var redisCacheActivities = buildModel.JOBName + constants.UNDERSCORE + buildModel.BuildNumber + constants.UNDERSCORE + buildModel.Type + constants.UNDERSCORE + buildModel.SubType;
        try {
            buildModel.IsActivityAltNameGet = constants.NO;
            objJenkinsService.ReadJsonData(buildModel, pipeLineModel, function (stageActivities) {
                //read from redis cache, if not available get to actual method
              //  if (buildModel.setCache == true) {
                    //client.get(redisCacheActivities, function (err, reply) {
                        // reply is null when the key is missing 
                       // if (reply == null || reply == '[]') {
                           // var objJenkinsService = new Jenkins;
                            //objJenkinsService.GetActivityStatus(stageActivities, buildModel, function (buildActivities) {
                               // if (buildActivities.length > 0 && buildActivities.length == stageActivities.length)
                               //     client.set(redisCacheActivities, JSON.stringify(buildActivities));
                                
                              //  callback(null, buildActivities);
                           // });
                        //} else {
                           // callback(null, JSON.parse(reply));
                       // }
                   // });
              //  }
               // else {
                    objJenkinsService.GetActivityStatus(stageActivities, buildModel, function (buildActivities) {
                        callback(null, buildActivities);
                    });
               // }
            });
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },   
    
    GetReportDetails : function GetReportDetails(stage, buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetReportDetails", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var objJenkinsService = new Jenkins;
        try {
            buildModel.InnerType = constants.REPORT;
            if (buildModel.Source == constants.CMSERVICEJENKINS) {
                objJenkinsService.ReadCMBuildConfig(buildModel, function (stageActivities) {
                    callback(null, stageActivities);
                });
            }
            else {
                objJenkinsService.ReadJsonData(buildModel, pipeLineModel, function (stageActivities) {
                    callback(null, stageActivities);
                });
            }
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },      
    
    GetBuildTestResults : function GetBuildTestResults(buildModel, pipeLineModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetBuildTestResults", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        buildModel.InnerType = constants.UNITTEST;
        var objJenkinsService = new Jenkins;
        try {
            buildModel.IsActivityAltNameGet = constants.NO;
            objJenkinsService.ReadJsonData(buildModel, pipeLineModel, function (stageActivities) {
                callback(null, stageActivities);
            });
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    GetRiskAnalysisDetails: function GetRiskAnalysisDetails(stage, buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetRiskAnalysisDetails", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        buildModel.Type = constants.ACTIVITY;
        buildModel.InnerType = constants.RISK;
        buildModel.SubType = stage;
        var riskIcon = "";
        var RiskInput1 = "";
        var RiskInput2 = "";
        var UTCHTML_Path, utcFile, parsedHTML;
        var objJenkinsService;
        var CoverageInput = buildModel.CoverageInputUI == "" ? buildModel.CoverageInputMiddle : buildModel.CoverageInputUI;
        var MetricInput = buildModel.MetricInputUI == "" ? buildModel.MetricInputMiddle : buildModel.MetricInputUI;
        var callBackString = {};
        
        try {
            objJenkinsService = new Jenkins;
            objJenkinsService.ReadBuildConfig(buildModel, function (stageActivities) {
                UTCHTML_Path = stageActivities[0][0].ReportPath;
                utcFile = fs.readFileSync(UTCHTML_Path, constants.UTF16LE).toString();
                parsedHTML = cherio.load(utcFile);
                parsedHTML('#RiskInd').each(function (th_index, th) {
                    riskIcon = parsedHTML(this)[0].children[0].data;
                });
                parsedHTML('#' + CoverageInput).each(function (th_index, th) {
                    RiskInput1 = parsedHTML(this)[0].children[0].data;
                });
                parsedHTML('#' + MetricInput).each(function (th_index, th) {
                    RiskInput2 = parsedHTML(this)[0].children[0].data;
                });
                
                callBackString.riskIcon = riskIcon;
                callBackString.RiskInput1 = RiskInput1;
                callBackString.RiskInput2 = RiskInput2;
                callback(null, callBackString);
            });
        }
        catch (ex) {
            callback(null, callBackString);
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    GetBuildActivityDetail : function GetBuildActivityDetails(activityAltName, buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetBuildActivityDetail", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //debugger;
        var objJenkinsSer = new Jenkins;
        var reports = [];
        var reportPath = "";
        
        try {
            buildModel.IsActivityAltNameGet = constants.YES;
            objJenkinsSer.ReadBuildConfig(buildModel, function (stageActivities) {
                if (stageActivities == null)
                    callback("");
                
                reportPath = stageActivities.ReportPath;
                //debugger;
                if (buildModel.Type == constants.STAGE) {
                    if (fs.statSync(filePath).isFile())
                        callback(constants.SUCCEEDED);
                    else
                        callback(constants.FAILED);
                }
                else {
                    if (fs.existsSync(reportPath)) {
                        
                        if (stageActivities.Type == activityAltName && stageActivities.Type == constants.UNIT_TEST_UI && buildModel.UITierAppType == ".NET") {
                            reportPath = reportsSharePath + buildModel.ApplicationName + "/" + buildModel.BuildNumber + "/" + constants.BUILDSUTCRESULTS + "/" + buildModel.ProjectFolderUI + 'TestResults.html';
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('#tMainSummary th').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == constants.PERCENT) {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().next().find("td").eq(index).text();
                                    thresholdPercent = thresholdPercent == "" ? "100%" : thresholdPercent;
                                    callback(thresholdPercent);
                                }
                            });
                        }
                        else if (stageActivities.Type == activityAltName && stageActivities.Type == constants.UNIT_TEST_UI && buildModel.UITierAppType == "Java") {
                            reportPath = reportsSharePath + buildModel.ApplicationName + "/" + buildModel.BuildNumber + "/" + constants.BUILDSUTCRESULTS + "/" + buildModel.ProjectFolderUI + 'TestResults.html';
                            reportPath = reportPath.replace(buildModel.ProjectFolderUI + 'TestResults.html', 'overview-summary.html');
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('th').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == constants.SUCCESSRATE) {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().next().find("td").eq(index).text();
                                    callback(thresholdPercent);
                                }
                            });
                        }
                        if (stageActivities.Type == activityAltName && stageActivities.Type == constants.UNIT_TEST_MT && buildModel.BusinessTierAppType == ".NET") {
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('#tMainSummary th').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == constants.PERCENT) {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().next().find("td").eq(index).text();
                                    thresholdPercent = thresholdPercent == "" ? "100%" : thresholdPercent;
                                    callback(thresholdPercent);
                                }
                            });
                        }
                        else if (stageActivities.Type == activityAltName && stageActivities.Type == constants.UNIT_TEST_MT && buildModel.BusinessTierAppType == "Java") {
                            reportPath = reportPath.replace(buildModel.UTReportPathMT + 'TestResults.html', 'overview-summary.html');
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('th').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == constants.SUCCESSRATE) {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().next().find("td").eq(index).text();
                                    callback(thresholdPercent);
                                }
                            });
                        }
                        else if (stageActivities.Type == activityAltName && stageActivities.Type == constants.CODE_COVERAGE_UI && buildModel.UITierAppType == ".NET") {
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('th').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == constants.COVERAGE) {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().find("td").eq(index).text();
                                    callback(thresholdPercent);
                                }
                            });
                        }
                        else if (stageActivities.Type == activityAltName && stageActivities.Type == constants.CODE_COVERAGE_MT && buildModel.UITierAppType == "Java") {
                            reportPath = reportPath.replace('index.html', 'frame-summary.html');
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('td').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == "branchcoverage") {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().find("td").eq(index).text();
                                    callback("0.00%");
                                }
                            });
                        }
                        else if (stageActivities.Type == activityAltName && stageActivities.Type == constants.CODE_COVERAGE_UI && buildModel.BusinessTierAppType == ".NET") {
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('th').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == constants.COVERAGE) {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().find("td").eq(index).text();
                                    callback(thresholdPercent);
                                }
                            });
                        }
                        else if (stageActivities.Type == activityAltName && stageActivities.Type == constants.CODE_COVERAGE_MT && buildModel.BusinessTierAppType == "Java") {
                            reportPath = reportPath.replace('index.html', 'frame-summary.html');
                            utcFile = fs.readFileSync(reportPath).toString();
                            parsedHTML = cherio.load(utcFile);
                            parsedHTML('td').each(function (th_index, th) {
                                var th_text = parsedHTML(this).text();
                                var prop_name = th_text.trim().toLowerCase().replace(/[^a-z]/g, "");
                                if (prop_name == "branchcoverage") {
                                    var index = parsedHTML(this).index();
                                    thresholdPercent = parsedHTML(this).parent().find("td").eq(index).text();
                                    callback("0.00%");
                                }
                            });
                        }
                        else
                            callback("");
                    }
                    else
                        callback("");
                }
                
            });
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
        
    },      
    
    ReadCMBuildConfig: function ReadCMBuildConfig(buildModel, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "ReadCMBuildConfig", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var filePath = path.join(__dirname, '../../config/', constants.CMJENKINSJOBCONFIGURATIONXML);
        var xml2js = require('xml2js');
        var parser = new xml2js.Parser();
        var xmlData;
        var fileData;
        var activities = [];
        var jobs = [];
        var stageActivities = [];
        var activityURL = "";
        var fs = require('fs');
        var objJenkinsService = new Jenkins;
        try {
            fileData = fs.readFileSync(filePath, 'ascii');
            //fileData = fileData.substring(3, fileData.length);
            var arrayLen = 0;
            parser.parseString(fileData, function (err, result) {
                xmlData = result;
            });
            if (xmlData != null) {
                jobs = xmlData.JobConfiguration.JobInformation[0].Job;
                for (var jobIndex = 0; jobIndex < jobs.length; jobIndex++) {
                    if (xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].JobName[0] == buildModel.SelectedBuildDefinition) {
                        var jobName = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].JobName[0];
                        var pipelinesStages = xmlData.JobConfiguration.JobInformation[0].Job[jobIndex].PipeLines[0].PipeLine;
                        
                        for (var i = 0; i < pipelinesStages.length; i++) {
                            if (buildModel.Type == constants.STAGE || (buildModel.Type == constants.ACTIVITY && pipelinesStages[i].Stage[0] == buildModel.SubType)) {
                                activities = pipelinesStages[i].Activities[0].Activity;
                                for (activity = 0; activity < activities.length; activity++) {
                                    activityURL = urlbuilder.build_url_job(LAST_BUILD, buildModel.BuildServerName, buildModel.BuildServerPort, activities[activity].$.Name);
                                    activityURL = activityURL.replace(constants.LASTBUILD, buildModel.BuildNumber)
                                    
                                    stageActivities.push({
                                        URL: activityURL,
                                        Stage: buildModel.Type == constants.STAGE ? pipelinesStages[i].Stage[0] : activities[activity].$.DisplayText,
                                        Order: i,
                                        AltName: "",
                                        isActivity: 'NO'
                                    });
                                }
                            }                            
                            else if (buildModel.Type == constants.REPORTS && pipelinesStages[i].Stage[0] == buildModel.SubType) {
                                var reports = pipelinesStages[i].Reports[0].Report;
                                var reportsCount = 0;
                                var riskIcon = "";
                                
                                for (report = 0; report < reports.length; report++) {
                                    if (reports[report].$.Report == "Unit Testing") {
                                        objJenkinsService.GetReportsDetails(reports[report].$.Report, reports[report].$.Tool,
                                             reports[report].$.Directory + "\\" + reports[report].$.FileName, function (result) {
                                            riskIcon = result;
                                        });
                                    }
                                    
                                    stageActivities.push({
                                        ReportName: reports[report].$.DisplayText,
                                        ReportPath: reports[report].$.Link,
                                        RiskIndicator: riskIcon
                                    });
                                    riskIcon = "";
                                }
                            }
                        }
                        callback(stageActivities);
                        break;
                    }
                }
            }
        }
        catch (ex) {
        }
    },
    
    GetCMActivityStatus: function GetCMActivityStatus(stageActivities, buildModel, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetCMActivityStatus", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var calls = [];
        var preResults = [];
        var buildActivities = [];
        
        stageActivities.forEach(function (stageActivity) {
            calls.push(function (callback) {
                //debugger;
                var objJenkinsService = new Jenkins;
                //debugger;
                buildModel.ActivityAltName = stageActivity.Stage;
                objJenkinsService.GetStatus(stageActivity.URL, buildModel, function (resultdata) {
                    //debugger;
                    if (resultdata != "") {
                        preResults.push({
                            Stage: stageActivity.Stage,
                            Status: resultdata,
                            Order: stageActivity.Order,
                            AltName: stageActivity.AltName,
                            isActivity: stageActivity.isActivity,
                            isStage: buildModel.Type
                        });
                    }
                    callback(null, preResults);
                });
            });
        });
        
        async.parallel(calls, function (err, result) {
            //debugger;
            arrayLen = 0;
            if (err)
                return console.log(err);
            //debugger;
            for (i = 0; i < preResults.length; i++) {
                if (i == 0) {
                    buildActivities[arrayLen] = {
                        ActivityName: preResults[i].isActivity == "YES" ? preResults[i].AltName :  preResults[i].Stage,
                        Status: preResults[i].Status,
                        Order: preResults[i].Order,
                        Type: "Build"
                    };
                    arrayLen = arrayLen + 1;
                }
                else {
                    var foundmatch = 0;
                    for (j = 0; j < buildActivities.length; j++) {
                        if (preResults[i].Stage == buildActivities[j].ActivityName) {
                            foundmatch = 1;
                            if (buildActivities.Status == constants.INPROGRESS) break;
                            else if (buildActivities.Status != constants.SUCCEEDED) break;
                            else
                                buildActivities.Status = preResults[i].Status;
                            
                            break;
                        }
                        if (j == buildActivities.length - 1 && foundmatch == 0) {
                            buildActivities[arrayLen] = {
                                ActivityName: preResults[i].isActivity == "YES" ? preResults[i].AltName : preResults[i].Stage,
                                Status: preResults[i].Status,
                                Order: preResults[i].Order,
                                Type: "Build"
                            };
                            arrayLen = arrayLen + 1;
                            break;
                        }
                    }
                }
            }
            //debugger;
            buildActivities.sort(function (a, b) {
                //debugger;
                return a.Order - b.Order
            })
            callback(buildActivities);
        });
        
    },
    
    CMConfigurationApi : function CMConfigurationApi(apiType, buildModel, callback) {
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CMConfigurationApi", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        var jobNamePrefix = "";
        var jobNames = "";
        var objJenkinsBuilds;
        //objJenkinsBuilds = new Jenkins();
        var objjenkinsapi = new jenkinsapi;
        jobNamePrefix = buildModel.ApplicationName;
        jobname = jobNamePrefix;//jobNamePrefix + "_Main";
        if (apiType == "getActivity") {
            objjenkinsapi.GetConfigXML(jobname, buildModel.BuildServerName, buildModel.BuildServerPort, function (error, resultdata) {
                if (error != null) {
                    console.log("GetConfigXML" + error);
                    callback(error, resultdata);
                    
                    return;
                }
                else {
                    console.log("GetConfigXML success");
                    
                    
                    var data, fd, mainjob, isexists, configxml;
                    
                    var etree;
                    var et = require('elementtree');
                    var applicationName = "";
                    
                    if (etree == undefined || etree == '') {
                        //fd = fs.openSync(jobconfigfilePath, 'a');
                        //data = fs.readFileSync(jobconfigfilePath).toString();
                        etree = et.parse(resultdata);
                    }
                    var lstActivities = [];
                    if (etree != null) {
                        if (etree._root.tag == "project") {
                            //mainjob = etree.findall('*/builders')
                            lstActivities.push({
                                Name: buildModel.ApplicationName,
                                PhaseName: '',
                                SequenceNo: 1,
                                SubJobName: buildModel.ApplicationName,
                                ContinuationCondition: '',
                                Type: "Non multi job",
                            });
                        }
                        else if (etree._root.tag == "com.tikal.jenkins.plugins.multijob.MultiJobProject") {
                            for (var i = 0; i < etree._root._children.length; i++) {
                                if (etree._root._children[i].tag == "builders") {
                                    
                                    for (var j = 0; j < etree._root._children[i]._children.length; j++) {
                                        if (etree._root._children[i]._children[j].tag == "com.tikal.jenkins.plugins.multijob.MultiJobBuilder") {
                                            if (etree._root._children[i]._children[j]._children[1]._children[0]._children[0].text != "") {
                                                
                                                lstActivities.push({
                                                    Name: etree._root._children[i]._children[j]._children[1]._children[0]._children[0].text,
                                                    PhaseName: etree._root._children[i]._children[j]._children[0].text,
                                                    SequenceNo: j,
                                                    SubJobName: etree._root._children[i]._children[j]._children[1]._children[0]._children[0].text,
                                                    ContinuationCondition: etree._root._children[i]._children[j]._children[2].text,
                                                    Type: "Multi job",
                                                });
                                            }
                                            
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (lstActivities != null) {
                            callback(null, lstActivities);
                        }
                    
                    }
                }
                callback(null, true);
            });
        }
        if (apiType == "alljobs") {
            objjenkinsapi.AllJobs(buildModel.BuildServerName, buildModel.BuildServerPort, function (error, resultdata) {
                if (error != null) {
                    console.log("AllJobs" + error);
                    callback(error, resultdata);
                    return;
                }
                else {
                    console.log("AllJobs success");
                    callback(error, resultdata);
                }
                callback(null, true);
            });
        }
        
    },
    
    GetReportsDetails: function GetReportsDetails(reportType, toolName, path, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "GetReportsDetails", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        if (reportType == "Risk Analysis") {
            var UTCHTML_Path = path;
            utcFile = fs.readFileSync(UTCHTML_Path, constants.UTF16LE).toString();
            parsedHTML = cherio.load(utcFile);
            parsedHTML('#RiskInd').each(function (th_index, th) {
                riskIcon = parsedHTML(this)[0].children[0].data;
                callback(riskIcon);
            });
        }
    },
    
    CheckCDApplicationAvailability: function CheckCDApplicationAvailability(buildModel, server, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CheckCDApplicationAvailability", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //debugger;
        var jobNamePrefix = "";
        var jobNames = [];
        var objjenkinsapi = new jenkinsapi;
        //var serverInfo = JSON.parse(server);
        
        jobNamePrefix = buildModel.DeployServerConfigname[0].CDApplicationName;
        jobNames = [
            jobNamePrefix + constants.UNDERSCORE_MAIN,
        ]
        
        objjenkinsapi.JobInfo(jobNames, server.DeployServer[0].BuildServerName, server.DeployServer[0].BuildServerPort, server.DeployServer[0].BuildServerUserID, server.DeployServer[0].BuildServerPassword, function (error, resultdata) {
            
            if (error != null) {
                callback(error, resultdata);
                return;
            }
            if (resultdata != null) {
                if (resultdata.displayName == (jobNamePrefix + constants.UNDERSCORE_MAIN)) {
                    callback(error, constants.TRUE);
                }
                else if (resultdata.statusMessage == constants.NOT_FOUND) {
                    callback(error, constants.FALSE);
                }
            }
               
        });
    },
    
    CheckBuildDefinition: function CheckBuildDefinition(buildModel, callback) {
        //log
        if (constants.TRACE_ENABLED) {
            var loginfo = { levelName: "trace", methodName: "CheckBuildDefinition", SourceFile : SourceFileName };
            customlogger.trace({ loginfo: loginfo });
        }
        //debugger;
        var jobNamePrefix = "";
        var jobNames = [];
        var objjenkinsapi = new jenkinsapi;
        jobNamePrefix = buildModel.ApplicationName;
        if (buildModel.SourceControlTool == constants.SVN || buildModel.SourceControlTool == constants.GIT) {
            jobNames = [
                jobNamePrefix + constants.UNDERSCORE_MAIN,
            ]
        }
        objjenkinsapi.JobInfo(jobNames, buildModel.BuildServerName, buildModel.BuildServerPort, buildModel.BuildServerUserID, buildModel.BuildServerPassword, function (error, resultdata) {
            
            if (error != null) {
                callback(error, resultdata);
                return;
            }
            if (resultdata != null) {
                if (resultdata.displayName == (jobNamePrefix + constants.UNDERSCORE_MAIN)) {
                    callback(error, constants.TRUE);
                }
                else if (resultdata.statusMessage == constants.NOT_FOUND) {
                    callback(error, constants.FALSE);
                }
            }
               
        });
    },
};

module.exports = Jenkins;
