﻿function fn_java_multijob() {
    this.fn_app_java_multijob = {
        _name: 'com.tikal.jenkins.plugins.multijob.MultiJobProject',
        _content:
 [
            {
                _name : 'keepDependencies',
                _content : 'false'
            },        
            {
                _name : 'scm',
                _content : {},
                _attrs : { 'class' : 'hudson.scm.NullSCM' }
            },
            {
                _name : 'canRoam',
                _content : 'true',
                _attrs : null
            },
            {
                _name : 'disabled',
                _content : 'false',
                _attrs : null
            },
            {
                _name : 'blockBuildWhenDownstreamBuilding',
                _content : 'false',
                _attrs : null
            },
            {
                _name : 'blockBuildWhenUpstreamBuilding',
                _content : 'false',
                _attrs : null
            },
            {
                _name : 'triggers',
                _content : {},
                _attrs : { 'class': 'vector' }
            },
            {
                _name : 'concurrentBuild',
                _content : 'false',
                _attrs : null
            },
            {
                _name : 'builders',
                _content : 
 [
                    {
                        _name : 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content : 
 [
                            {
                                _name : 'phaseName',
                                _content : 'Build Test',
                                _attrs : null
                            },
                            {
                                _name : 'phaseJobs',
                                _content : {
                                    _name : 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                    _content : [
                                        { _name : 'jobName', _content : 'NerdDinner_Subversion' },
                                        { _name : 'currParams', _content : 'true' },
                                        { _name : 'exposedSCM', _content : 'false' },
                                        { _name : 'configs', _content : {}, _attrs : { 'class' : 'empty-list' } }
                                    ]
                                }
                            },
                            {
                                _name : 'continuationCondition',
                                _content : 'COMPLETED'
                            }
                        ]
                    },
                    {
                        _name : 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content : 
 [
                            {
                                _name : 'phaseName',
                                _content : 'Unit Test',
                                _attrs : null
                            },
                            {
                                _name : 'phaseJobs',
                                _content : {
                                    _name : 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                    _content : [
                                        { _name : 'jobName', _content : 'NerdDinner_Subversion_UnitTest' },
                                        { _name : 'currParams', _content : 'true' },
                                        { _name : 'exposedSCM', _content : 'false' },
                                        { _name : 'configs', _content : {}, _attrs : { 'class' : 'empty-list' } }
                                    ]
                                }
                            },
                            {
                                _name : 'continuationCondition',
                                _content : 'COMPLETED'
                            }
                        ]
                    },
                    {
                        _name : 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content :
 [
                            {
                                _name : 'phaseName',
                                _content : 'Publish',
                                _attrs : null
                            },
                            {
                                _name : 'phaseJobs',
                                _content : [
                                    {
                                        _name : 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                        _content : [
                                            { _name : 'jobName', _content : 'NerdDinnerPublishReports_Subversion' },
                                            { _name : 'currParams', _content : 'true' },
                                            { _name : 'exposedSCM', _content : 'false' },
                                            { _name : 'configs', _content : {}, _attrs : { 'class' : 'empty-list' } }
                                        ]
                                    },
                                    {
                                        _name : 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                        _content : [
                                            { _name : 'jobName', _content : 'NerdDinnerRunSonarAnalysis' },
                                            { _name : 'currParams', _content : 'true' },
                                            { _name : 'exposedSCM', _content : 'false' },
                                            { _name : 'configs', _content : {}, _attrs : { 'class' : 'empty-list' } }
                                        ]
                                    }
                                ]
                            },
                            {
                                _name : 'continuationCondition',
                                _content : 'COMPLETED'
                            }
                        ]
                    },
                    {
                        _name : 'com.tikal.jenkins.plugins.multijob.MultiJobBuilder',
                        _content : 
 [
                            {
                                _name : 'phaseName',
                                _content : 'Repository',
                                _attrs : null
                            },
                            {
                                _name : 'phaseJobs',
                                _content : {
                                    _name : 'com.tikal.jenkins.plugins.multijob.PhaseJobsConfig',
                                    _content : [
                                        { _name : 'jobName', _content : 'NerdDinner_Subversion_Deploy' },
                                        { _name : 'currParams', _content : 'true' },
                                        { _name : 'exposedSCM', _content : 'false' },
                                        { _name : 'configs', _content : {}, _attrs : { 'class' : 'empty-list' } }
                                    ]
                                }
                            },
                            {
                                _name : 'continuationCondition',
                                _content : 'SUCCESSFUL'
                            }
                        ]
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\Subversion\\SubversionLogHistory'
                        }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : 
 {
                            _name : 'command',
                            _content : 'C:\\Jenkins\\JenkinReportbat\\Subversion\\EnterpriseCustomEmail'
                        }
                    }
                ]
            },
            {
                _name : 'properties',
                _content :                     
 {
                    _name : 'EnvInjectJobProperty',
                    _content : 
 [
                        {
                            _name : 'info',
                            _content :  
 {
                                "propertiesFilePath": "C:\\Jenkins\\JenkinReportbat\\buildevttxt.txt",
                                "scriptFilePath": "C:\\Jenkins\\JenkinReportbat\\Subversion\\BuildVersioning.bat %BUILD_NUMBER%",
                                "loadFilesFromMaster": "false"
                            },
                        },
                        {
                            _name : 'on',
                            _content : 'true'
                        },
                        {
                            _name: 'keepJenkinsSystemVariables',
                            _content : 'true'
                        },
                        {
                            _name : 'keepBuildVariables',
                            _content : 'true'
                        }
                    ],
                    _attrs : { 'plugin' : 'envinject' }
                }
            }
        ],
        _attrs: { 'plugin' : 'jenkins-multijob-plugin' }

    }
};
module.exports = fn_java_multijob;