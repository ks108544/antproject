﻿function fn_middle_svndeploy() {
    this.middle_svndeploy_json = {
        _name : 'project',
        _content : 
 [
            {
                _name : 'description',
                _content : {}
            },
            {
                _name : 'actions',
                _content : {}
            },
            {
                _name : 'keepDependencies',
                _content : 'false'
            },
            {
                _name : 'properties',
                _content : {}
            },
            {
                _name : 'scm',
                _content : 'false',
                _attrs : { 'class': 'hudson.scm.NullSCM' }
            
            },    
            {
                _name : 'canRoam',
                _content : 'true'
            },
            {
                _name : 'disabled',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenDownstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenUpstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'triggers',
                _attrs : { 'class': 'vector' }
            },
            {
                _name : 'concurrentBuild',
                _content : 'false'
            },
            {
                _name : 'builders',
                _content : 
 [
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : { 'command': 'REM Downloading source from SVN to Workspace' }
                    },
                    {
                        _name : 'hudson.tasks.Ant',
                        _content : 
 [
                            {
                                _name : 'targets',
                                _content : ''
                            },

                            {
                                _name : 'antName',
                                _content : '(Default)'
                            },
                            {
                                _name : 'buildFile',
                                _content : 'C:\\jenkins_instdir\\jobs\\NerddinnerWS_Subversion\\workspace\\NerdDinnerRestFulWS\\build.xml'
                            }
                        ],
                        _attrs : { 'plugin' : 'ant' }
                    }
                ]
            },
            {
                _name : 'publishers',
                _content : 
 [
                    {
                        _name : 'hudson.plugins.deploy.DeployPublisher',
                        _content : 
 [
                            {
                                _name : 'adapters',
                                _content : {
                                    _name : 'hudson.plugins.deploy.tomcat.Tomcat7xAdapter',
                                    _content : [
                                        { _name : 'userName', _content : 'deploymgr' },
                                        { _name : 'passwordScrambled', _content : 's3cret' },
                                        { _name : 'url', _content : 'http://pheonixdevops02:9090' }
                                    ]
                                }
                            },
                            {
                                _name : 'contextPath',
                                _content : '/NerdDinnerRestFulWS'
                            },
                            {
                                _name : 'war',
                                _content : 'NerdDinnerRestFulWS\\build\\war\\nerd.war'
                            }, 
                            {
                                _name : 'onFailure',
                                _content : 'false'
                            }
                        ]
                    },
                ], _attrs : { 'plugin' : 'DeployPublisher' }
            },
            {
                _name : 'buildWrappers',
                _content : {}
            }
        ]

    }
};
		
module.exports = fn_middle_svndeploy;