﻿function fn_container_tooldetails_json() {   
    
    this.container_tooldetails_json = {
       	"VMName": "",
		"VMUserName": "",
		"VMPassword": "",
		"ContainerType": "",
		"ContainerName": "",
		"Version": "",
		"UserName": "",
		"Password": "",
		"Port": "",
		"Status": ""
        }
    
};

module.exports = fn_container_tooldetails_json;