﻿function fn_app_common_json() {
    
    
    //Null Content for SCM
    this.ScmNull_build_json = {
        _name: 'scm',
        _content: 'false',
        _attrs: {
            'class': 'hudson.scm.NullSCM'
        }

    }
    
};



module.exports = fn_app_common_json;