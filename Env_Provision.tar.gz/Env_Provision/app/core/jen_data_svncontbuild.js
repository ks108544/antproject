﻿function fn_data_svncontbuild() {
    this.data_svncontbuild_json = {
        _name : 'project',
        _content : 
 [
            {
                _name : 'description',
                _content : {}
            },
            {
                _name : 'actions',
                _content : {}
            },
            {
                _name : 'keepDependencies',
                _content : 'false'
            },
            {
                _name : 'properties',
                _content : {}
            },
            {
                _name : 'scm',
                _content :
 [
                    {
                        _name: 'locations',
                        _content :                     
 {
                            _name : 'hudson.scm.SubversionSCM_-ModuleLocation',
                            _content : 
 [
                                {
                                    _name : 'remote',
                                    _content : 'http://webserver.wipro.com:81/svn/CICDRepository/StandardizeDBScripts/branches'
                                },
                                {
                                    _name : 'local',
                                    _content : '.'
                                },
                                {
                                    _name : 'depthOption',
                                    _content : 'infinity'
                                },
                                {
                                    _name : 'ignoreExternalsOption',
                                    _content : 'false'
                                }
                            ]
                        }
                    },
                    {
                        _name : 'excludedRegions',
                        _content : {}
                    },
                    {
                        _name : 'includedRegions',
                        _content : {}
                    },
                    {
                        _name : 'excludedUsers',
                        _content : {}
                    },
                    {
                        _name : 'excludedRevprop',
                        _content : {}
                    },
                    {
                        _name : 'excludedCommitMessages',
                        _content : {}
                    },
                    {
                        _name : 'workspaceUpdater',
                        _attrs : { 'class' : 'hudson.scm.subversion.UpdateUpdater' }
                    },
                    {
                        _name : 'ignoreDirPropChanges',
                        _content : 'false'
                    },
                    {
                        _name : 'filterChangelog',
                        _content : 'false'
                    }
                ],            
                
                _attrs : 
            
 {
                    'class': 'hudson.scm.SubversionSCM',
                    'plugin': 'subversion'
                }
            },    
            {
                _name : 'canRoam',
                _content : 'true'
            },
            {
                _name : 'disabled',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenDownstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'blockBuildWhenUpstreamBuilding',
                _content : 'false'
            },
            {
                _name : 'triggers',
                _attrs : { 'class': 'vector' }
            },
            {
                _name : 'concurrentBuild',
                _content : 'false'
            },
            {
                _name : 'builders',
                _content : 
 [
                    {
                        _name : 'hudson.tasks.Ant',
                        _content : 
 [
                            {
                                _name : 'targets',
                                _content : ''
                            },

                            {
                                _name : 'antName',
                                _content : '(Default)'
                            },
                            {
                                _name : 'buildFile',
                                _content : 'C:\\jenkins_instdir\\jobs\NerddinnerWSDeployDB_Subversion\\workspace\\StandardizeDBScripts\\build.xml'
                            }
                        ],
                        _attrs : { 'plugin' : 'ant' }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : { 'command': 'xcopy /y buildartifacts %1' }
                    },
                    {
                        _name : 'hudson.tasks.BatchFile',
                        _content : { 'command': 'C:\\Jenkins\\JenkinReportbat\\SVNLogHistory.bat' }
                    }
                ]
            },
            {
                _name : 'publishers',
                _content : {}
            },
            {
                _name : 'buildWrappers',
                _content : {}
            }
        ]

    }
};
		
module.exports = fn_data_svncontbuild;