﻿// Abstract base class
function Build() {
    //To do
    //Add base class properties
};

// Abstract methods of class ClsBuild
Build.prototype = {
    
    //Create build definition
        CreateBuildDefinition: function CreateBuildDefinition(type,obj) {        

    }
    
};

module.exports = Build;