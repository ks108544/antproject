﻿function fn_app_build_json() {
    
    //Json for build job creation
    this.app_buildjob_json = {
        _name: 'project',
        _content: [{
                _name: 'description',
                _content: {}
            },
            {
                _name: 'actions',
                _content: {}
            },
            {
                _name: 'keepDependencies',
                _content: 'false'
            },
            {
                _name: 'properties',
                _content: {}
            },
            //Plugin content need to replaced with repo
             {
                _name: 'scm',
                _content: 'false',
                _attrs: {
                    'class': 'hudson.scm.NullSCM'
                }

            },
            {
                _name: 'canRoam',
                _content: 'true'
            },
            {
                _name: 'disabled',
                _content: 'false'
            },
            {
                _name: 'blockBuildWhenDownstreamBuilding',
                _content: 'false'
            },
            {
                _name: 'blockBuildWhenUpstreamBuilding',
                _content: 'false'
            },
            {
                _name: 'triggers',
                _attrs: {
                    'class': 'vector'
                }
            },
            {
                _name: 'concurrentBuild',
                _content: 'false'
            },
            {
                _name: 'builders',
                _content: [{
                        _name: 'hudson.tasks.BatchFile',
                        _content: {
                            'command': 'REM Downloading source from SVN to Workspace'
                        }
                    },
                    {
                        _name: 'hudson.tasks.Ant',
                        _content: [{
                                _name: 'targets',
                                _content: ''
                            },

                            {
                                _name: 'antName',
                                _content: '(Default)'
                            },
                            {
                                _name: 'buildFile',
                                _content: 'C:\\jenkins_instdir\\jobs\\NerddinnerWS_Subversion\\workspace\\NerdDinnerRestFulWS\\build.xml'
                            }
                        ],
                        _attrs: {
                            'plugin': 'ant'
                        }
                    },
                    {
                        _name: 'hudson.tasks.BatchFile',
                        _content: {
                            'command': 'xcopy /y buildartifacts %1'
                        }
                    },
                    {
                        _name: 'hudson.tasks.Ant',
                        _content: [{
                                _name: 'targets',
                                _content: 'report-checkstyle'
                            },

                            {
                                _name: 'antName',
                                _content: '(Default)'
                            },
                            {
                                _name: 'buildFile',
                                _content: 'C:\\jenkins_instdir\\jobs\\NerddinnerWS_Subversion\\workspace\\NerdDinnerRestFulWS\\build.xml'
                            }
                        ],
                        _attrs: {
                            'plugin': 'ant'
                        }
                    },
                    {
                        _name: 'hudson.tasks.Ant',
                        _content: [{
                                _name: 'targets',
                                _content: 'report-findbugs'
                            },

                            {
                                _name: 'antName',
                                _content: '(Default)'
                            },
                            {
                                _name: 'buildFile',
                                _content: 'C:\\jenkins_instdir\\jobs\\NerddinnerWS_Subversion\\workspace\\NerdDinnerRestFulWS\\build.xml'
                            }
                        ],
                        _attrs: {
                            'plugin': 'ant'
                        }
                    },
                    {
                        _name: 'hudson.tasks.BatchFile',
                        _content: {
                            'command': 'C:\\Jenkins\\JenkinReportbat\\SVNLogHistory.bat'
                        }
                    }
                ]
            },
            {
                _name: 'publishers',
                _content: {}
            },
            {
                _name: 'buildWrappers',
                _content: {}
            }
        ]

    }
    
   
};

module.exports = fn_app_build_json;