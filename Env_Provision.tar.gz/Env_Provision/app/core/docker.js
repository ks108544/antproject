﻿var env = require('get-env')();
var Ansible = require('node-ansible');
var SourceFileName = "docker.js"

//debugger;
if (env === 'dev' || env === 'development' || env === '') {
    //Imports from containerization_base.js
    var containerizationBase = require('./containerization_base.js');
    //constants
    var constants = require('../../config/serviceconstants.js');
    //logger
    var customlogger = require("../utils/logger.js");
} else if (env === 'prod' || env === 'production') {
    //Imports from containerization_base.min.js
    var containerizationBase = require('./containerization_base.min.js');
    //constants
    var constants = require('../../config/serviceconstants.min.js');
}

//Concreate Docker class inheriting base build class
function Docker() {
    containerizationBase.apply(this, arguments);

    //Add Docker class related properties below if required
}

Docker.prototype = new containerizationBase;

//Docker class overridding base class methods

Docker.prototype = {

    InstallContainerEngine: function (VMName, userName, password, callback) {
        var loginfo = { levelName: "trace", methodName: "InstallContainerEngine", SourceFile: SourceFileName };
        customlogger.trace({ loginfo: loginfo });

        var command = new Ansible.Playbook().playbook('installdocker');
         //.variables({  vmName: VMName, userName: userName, pass: password });
        //var command = new Ansible.AdHoc().module('shell').hosts('TargetNodes').args("ansible-playbook /home/AgileBase/Nodejs/EnvProvisioning/Infra_Scripts/installdocker.yml"); 
        //var command = new Ansible.AdHoc().module('shell').hosts('local').args("sudo ansible local -m ping"); 


        var promise = command.exec({ cwd: "/home/AgileBase/Nodejs/EnvProvisioning/Infra_Scripts" });
        
        promise.then(function (successResult) {           

            var loginfo = { levelName: "trace", methodName: successResult.code, SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            loginfo = { levelName: "trace", methodName: successResult.output, SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            callback(null, successResult);
        }, function (error) {
            var loginfo = { message: error,  levelName: "error", methodName: method, SourceFile: SourceFileName };
            customlogger.error({ loginfo: loginfo });
            if (error != null) {
                callback(error);
                return;
            }    
            })
        
    },

    BuildContainer: function (containerObjModel, callback) {

        var loginfo = { levelName: "trace", methodName: "BuildContainer", SourceFile: SourceFileName };
        customlogger.trace({ loginfo: loginfo });
        debugger;
        var command = new Ansible.Playbook().playbook('dockerJenkins');
            //.variables({ software: containerObjModel.ContainerName, type: containerObjModel.ContainerType, vmName: containerObjModel.VMName, userName: containerObjModel.VMUserName, pass: containerObjModel.VMPassword, Version: containerObjModel.ToolVersion, Port: containerObjModel.ToolPort});

        var promise = command.exec({ cwd: "/home/AgileBase/Nodejs/EnvProvisioning/Infra_Scripts" });
        promise.then(function (successResult) {
            var loginfo = { levelName: "trace", methodName: "BuildContainer:Insidepromise", SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            var loginfo = { levelName: "trace", methodName: successResult.code, SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            loginfo = { levelName: "trace", methodName: successResult.output, SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            callback(null, successResult);
        }, function (error) {
            var loginfo = { message: error,  levelName: "error", methodName: method, SourceFile: SourceFileName };
            customlogger.error({ loginfo: loginfo });
            if (error != null) {
                callback(error);
                return;
            } 
        })

        //playbook.on('stdout', function (data) { console.log(data.toString()); });
        //playbook.on('stderr', function (data) { console.log(data.toString()); });
        //var promise = playbook.exec();
    },
     
    

 BuildDockerImage: function (FolderName, Nexusurl, Dockerurl, Packagename,Dockername ,Imagename,Imagerepo, callback) {
	  var method = "BuildDockerImage";
          //console.log(FolderName, Nexusurl, Dockerurl, Packagename,Dockername ,Imagename,Imagerepo);
	  var command = new Ansible.Playbook().playbook('getartifact').variables({  folder: FolderName, nexusurl: Nexusurl, dockerurl: Dockerurl, packagename: Packagename, dockername: Dockername , imagename: Imagename, imagerepo: Imagerepo });
	 
      var promise = command.exec({ cwd: "/home/kubeuser/Artifact" });

 
       promise.then(function (successResult) {           
        
            var loginfo = { levelName: "trace", methodName: "BuildDockerImage", SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            //console.log(successResult);

            if(successResult.code==0){
              	callback(null, true);
            }
           else
           {
            	callback(null, successResult.code);
           }

             return;
        
  
     }, function (error) {
            var loginfo = { message: error,  levelName: "error", methodName: method, SourceFile: SourceFileName };
            customlogger.error({ loginfo: loginfo });
            if (error != null) {
            callback(error);
            return;
        }    
     })
  },
		   
		

 

    BuildContainerUsingKubernetes: function(DockerImageurl,   stagename, packagename,  applicationname,port, callback) {
      var loginfo = { levelName: "trace", methodName: "BuildContainerUsingKubernetes", SourceFile: SourceFileName };
        customlogger.trace({ loginfo: loginfo });
       console.log(DockerImageurl, packagename,  applicationname);

        var command = new Ansible.Playbook().playbook('deploypodtokubernetes').variables({ imageurl: DockerImageurl, packagename: packagename, namespace: 'default', context: 'agilebase',  applicationname: applicationname , port: port });

        
        var promise = command.exec({ cwd: "/home/kubeuser/Artifact" });

            promise.then(function (successResult) {           
           //console.log(successResult);


            var loginfo = { levelName: "trace", methodName: "BuildContainerUsingKubernetes", SourceFile: SourceFileName };
            customlogger.trace({ loginfo: loginfo });
            //console.log(successResult);

            if(successResult.code==0){
              callback(null, true);
            }
           else
          {
            callback(null, successResult.code);
           }

             return;

        }, function (error) {
          
            var loginfo = { message: error,  levelName: "error", methodName: "BuildContainerUsingKubernetes", SourceFile: SourceFileName };
            customlogger.error({ loginfo: loginfo });
            if (error != null) {
               callback(error);
                return;
            }    
            })
        
    }

       

};

module.exports = Docker;
