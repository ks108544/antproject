﻿var env = require('get-env')();

var https = require('https');
var js2xmlparser = require('js2xmlparser');
var xpath = require('xpath');
var xmldom = require('xmldom');
var domparser = xmldom.DOMParser;
var dom = new domparser();
var fs = require('fs');
var dateformat = require('dateformat');
var path = require('path');
var request = require('request');

if (env === 'dev' || env === 'development' || env === '') {
    //Imports from build.js
    var deploy = require('./deploy.js');
    var builddefnModel = require('../models/builddefinition.js');
    var cmconfigModel = require('../models/cmconfig.js');
    var createdeployconfigxml = require('./udeploy_config_xml.js');
    var constants = require('../../config/serviceconstants.js');
   
} else if (env === 'prod' || env === 'production') {
    //Imports from build.js
    var deploy = require('./deploy.min.js');
    var builddefnModel = require('../models/builddefinition.min.js');
    var cmconfigModel = require('../models/cmconfig.min.js');
    var createdeployconfigxml = require('./udeploy_config_xml.min.js');
    var constants = require('../../config/serviceconstants.min.js');
 }

//Constants
var deployDoc = null;
var deployinfo = new Udeploy();

var mainComponent = null, regressionComponent = null;
var urlForRequest = null, userName = null, password = null;

var outputDateFormat = null, outputTimeFormat = null, outputDuretionFormat = null;

var mainComponentCacheKey = "MainComponent";
var regressionComponentCacheKey = "RegressionTestingComponent";
var lstDeploys = new Array();

function Udeploy() {
    deploy.apply(this, arguments);
    //Add udeploy related properties
    this.releaseVersion = "";
    this.releaseDate = "";
    this.releaseTime = "";
    this.durationTaken = "";
    this.releaseProcess = "";
    this.currentActivity = "";
    this.status = "";
    this.regression = "";
    this.regressionTestsPassed = "";
    this.regressionTestsFailed = "";
    this.regressionTestsExecuted = "";
    this.regressionNotExecuted = "";
    this.regressionReport = "";
    this.reports = "";
    this.appId = "";
}

Udeploy.prototype = new deploy;

Udeploy.prototype = {

    CreateUDeployConfigXML: function CreateUDeployConfigXML(buildModel, callback) {

        var objUdeployConfigXml = null;

        try {
            objUdeployConfigXml = new createdeployconfigxml;

            // Generate config xml 
            objUdeployConfigXml.Generate_Deploy_Config_XML(buildModel);
            callback(null, "success");
        }
        catch (e) {
            callback(null, "error");
        }

        callback(null, "");
    },
    
    GetUdeployApplications: function GetUdeployApplications(buildModel, callback) {
        
        try {
            
            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;            
            
            var udeployObj = new Udeploy();
            var body = '';
            var result = '';
            
            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/application',
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (chunk) {
                    body += chunk;
                });
                
                res.on('end', function () {
                    console.log("_____33________________" + body);
                    
                    
                    try {
                        result = JSON.parse(body);
                    } catch (e) {
                    }
                    
                    callback(null, result);
                });

            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 01");
        }
            catch (ex) {
            callback(null, "");
        }
    },
    
    GetUdeployEnvironments: function GetUdeployEnvironments(buildModel, callback) {
        
        try {
            
            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;
            
            var udeployObj = new Udeploy();
            var body = '';
            var result = '';
            
            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/environment?filterFields=application.id&filterType_application.id=eq&filterValue_application.id=' + buildModel.UDeployApplicationId + '&filterClass_application.id=UUID&outputType=BASIC&outputType=SECURITY&outputType=LINKED&orderField=order',
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (chunk) {
                    body += chunk;
                });
                
                res.on('end', function () {
                    console.log("_____44________________" + body);
                    
                    
                    try {
                        result = JSON.parse(body);
                    } catch (e) {
                    }
                    
                    callback(null, result);
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 02");
        }
            catch (ex) {
            callback(null, "");
        }
    },
    
    GetUdeployApplProcesses: function GetUdeployApplProcesses(buildModel, callback) {
        
        try {
            
            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;
            
            var udeployObj = new Udeploy();
            var body = '';
            var result = '';
            
            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/application/' + buildModel.UDeployApplicationId + '/processes/false',
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (chunk) {
                    body += chunk;
                });
                
                res.on('end', function () {
                    console.log("_____44________________" + body);
                    
                    
                    try {
                        result = JSON.parse(body);
                    } catch (e) {
                    }
                    
                    callback(null, result);
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 03");
        }
            catch (ex) {
            callback(null, "");
        }
    },
    
    GetUdeployResources: function GetUdeployApplProcess(buildModel, callback) {
        
        try {
            
            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;
            
            var udeployObj = new Udeploy();
            var body = '';
            var result = '';
            
            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/environment/' + buildModel.UDeployEnvironmentId + '/resources',
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (chunk) {
                    body += chunk;
                });
                
                res.on('end', function () {
                    console.log("_____44________________" + body);
                    
                    
                    try {
                        result = JSON.parse(body);
                    } catch (e) {
                    }
                    
                    callback(null, result);
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 04");
        }
            catch (ex) {
            callback(null, "");
        }
    },
    
    GetUdeployComponents: function GetUdeployComponents(buildModel, callback) {
        
        try {
            
            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;
            
            var udeployObj = new Udeploy();
            var body = '';
            var result = '';
            
            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/applicationProcess/' + buildModel.UDeployApplProcessId + '/' + buildModel.UDeployApplProcessVersion,
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (chunk) {
                    body += chunk;
                });
                
                res.on('end', function () {
                    console.log("_____44________________" + body);
                    
                    
                    try {
                        result = JSON.parse(body);
                    } catch (e) {
                    }
                    
                    callback(null, result);
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 05");
        }
            catch (ex) {
            callback(null, "");
        }
    },
    
    GetUdeployComponentProcesses: function GetUdeployComponentProcess(buildModel, callback) {
        
        try {
            
            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;
            
            var udeployObj = new Udeploy();
            var body = '';
            var result = '';
            
            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/component/' + buildModel.UDeployComponentName + '/processes/false',
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (chunk) {
                    body += chunk;
                });
                
                res.on('end', function () {
                    console.log("_____44________________" + body);
                    
                    
                    try {
                        result = JSON.parse(body);
                    } catch (e) {
                    }
                    
                    callback(null, result);
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 06");
        }
            catch (ex) {
            callback(null, "");
        }
    },

    GetComputerNameByAgent: function GetComputerNameByAgent(agentId, buildModel, callback) {

        try {

            var udeployserver = buildModel.DeployServerUrl;
            var port = buildModel.DeployServerPort;
            var username = buildModel.DeployServerUserID;
            var password = buildModel.DeployServerPassword;
            var secureSSL = buildModel.DeploySecurityType;

            var udeployObj = new Udeploy();
            var body = '';
            var result = '';

            //Get The Json form Udeploy API
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/agent/' + agentId,
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };

            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);

                res.on('data', function (chunk) {
                    body += chunk;
                });

                res.on('end', function () {
                    console.log("_____44________________" + body);


                    try {
                        result = JSON.parse(body);

                        options = {
                            hostname: udeployserver,
                            port: port,
                            path: '/property/propSheet/agents%26' + agentId + '%26propSheet.' + result.propSheet.version,
                            method: 'GET',
                            auth: username + ':' + password,
                            secureProtocol: secureSSL,
                            rejectUnauthorized: false,
                        };

                        var reqHost = https.request(options, function (resHost) {
                            console.log("statusCode: ", res.statusCode);

                            body = '';
                            resHost.on('data', function (chunk) {
                                body += chunk;
                            });

                            resHost.on('end', function () {
                                console.log("_____55________________" + body);

                                result = '';
                                result = JSON.parse(body);

                                callback(null, result);
                            });
                        });
                        reqHost.end('end', function () {
                            console.log("end here :\n");
                        });

                        reqHost.on('error', function (e) {
                            console.error("error :\n" + e);
                        });


                    } catch (e) {
                        callback(null, result);
                    }
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });

            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 07");
        }
        catch (ex) {
            callback(null, "");
        }
    },
    
    GetStageStatus: function GetStageStatus(deployModel, callback) {
        //debugger;
        var objUdeployService = new Udeploy();
        try {
            objUdeployService.GetDeploymentDetails(deployModel, function (deployActivities) {
                objUdeployService.ReadCMDeployConfig(deployActivities, deployModel, function (stageActivities) {
                    callback(null, stageActivities);
                });
            });
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    GetBuildActivities: function GetBuildActivities(deployModel, callback) {
        //debugger;
        var objUdeployService = new Udeploy();
        try {
            objUdeployService.GetDeploymentDetails(deployModel, function (deployActivities) {
                objUdeployService.ReadCMDeployConfig(deployActivities, deployModel, function (stageActivities) {
                    callback(null, stageActivities);
                });
            });
        }
        catch (ex) {
        }
        finally {
            objJenkinsService = null;
        }
    },
    
    ReadCMDeployConfig: function ReadCMBuildConfig(deployActivities, deployModel, callback) {
        var filePath = path.join(__dirname, '../../config/', constants.CMJENKINSDEPLOYCONFIGURATIONXML);
        var xml2js = require('xml2js');
        var parser = new xml2js.Parser();
        var xmlData;
        var fileData;
        var activities = [];
        var jobs = [];
        var stageActivities = [];
        var activityURL = "";
        var fs = require('fs');
        
        try {
            fileData = fs.readFileSync(filePath, 'ascii');
            fileData = fileData.substring(3, fileData.length);
            var arrayLen = 0;
            parser.parseString(fileData, function (err, result) {
                xmlData = result;
            });
            if (xmlData != null) {
                jobs = xmlData.DeployConfiguration.DeployInformation[0].Deploy;
                for (var jobIndex = 0; jobIndex < jobs.length; jobIndex++) {
                    if (xmlData.DeployConfiguration.DeployInformation[0].Deploy[jobIndex].BuildDefinitionName[0] == deployModel.SelectedBuildDefinition) {
                        var jobName = xmlData.DeployConfiguration.DeployInformation[0].Deploy[jobIndex].BuildDefinitionName[0];
                        var pipelinesStages = xmlData.DeployConfiguration.DeployInformation[0].Deploy[jobIndex].PipeLines[0].PipeLine;
                        var arrayLen = 0;
                        for (var i = 0; i < pipelinesStages.length; i++) {
                            if (deployModel.Type == constants.STAGE) {
                                activities = pipelinesStages[i].Activities[0].Activity;
                                for (activity = 0; activity < activities.length; activity++) {
                                    for (udeployResult = 0 ; udeployResult < deployActivities.length; udeployResult++) {
                                        if (deployActivities[udeployResult].releaseProcess == activities[activity].$.Name) {
                                            stageActivities[arrayLen] = {
                                                ActivityName: pipelinesStages[i].Stage[0],
                                                Status: deployActivities[udeployResult].status,
                                                Order: "",
                                                Type: "Deploy"
                                            };
                                            arrayLen = arrayLen + 1;
                                            break;
                                        }
                                    }
                                }
                            }
                            else if ((deployModel.Type == constants.ACTIVITY && pipelinesStages[i].Stage[0] == deployModel.SubType)) {
                                activities = pipelinesStages[i].ActivityTrackings[0].ActivityTracking[0].Activities[0].Activity;
                                for (activity = 0; activity < activities.length; activity++) {
                                    for (udeployResult = 0 ; udeployResult < deployActivities.length; udeployResult++) {
                                        if (deployActivities[udeployResult].releaseProcess == activities[activity].$.Name) {
                                            stageActivities[arrayLen] = {
                                                ActivityName: activities[activity].$.DisplayText + " - " + activities[activity].$.Agent,
                                                Status: deployActivities[udeployResult].status,
                                                Order: ""
                                            };
                                            arrayLen = arrayLen + 1;
                                            break;
                                        }
                                    }
                                }
                            }                            
                        }
                        callback(stageActivities);
                        break;
                    }
                }
    }
        }
        catch (ex) {
        }
    },
    
    GetDeploymentDetails: function GetDeploymentDetails(deployparam, callback) {
        //input parameters
        //var udeployserver = deployparam.DeployServerUrl;
        //var port = deployparam.DeployServerPort;
        //var username = deployparam.DeployServerUserName;
        //var password = deployparam.DeployServerPassword;
        //var secureSSL = deployparam.secureSSL;
        //var buildNumber = deployparam.buildNumber;
        
        var udeployserver = "10.148.21.120";
        var port = 8443;
        var username = "admin";
        var password = "admin";
        var secureSSL = "SSLv3_method";
        var udeployObj = new Udeploy();
        var lstDeploys = null;
        var udployactivityJson = '';
        
        //Get The Json form Udeploy API
        //url:'https://10.148.21.120:8443/rest/workflow/currentActivity',
        var options = {
            hostname: udeployserver,
            port: port,
            path: '/rest/workflow/currentActivity',
            method: 'GET',
            auth: username + ':' + password,
            secureProtocol: secureSSL,
            rejectUnauthorized: false,
        };
        
        var req = https.request(options, function (res) {
            console.log("statusCode: ", res.statusCode);
            
            res.on('data', function (data) {
                udployactivityJson += data;
            });
            
            res.on('end', function () {
                
                console.log("_____33________________" + udployactivityJson);
                lstDeploys = udeployObj.ReadJson(udployactivityJson, "2.1.155.401");
                console.log("_____Returing the data https");
                callback(lstDeploys);
            });
        });
        req.end('end', function () {
            console.log("end here :\n");
        });
        
        req.on('error', function (e) {
            console.error("error :\n" + e);
        });
        console.log("_____End of dep method : 08");

    },
    
    ReadJson: function ReadJson(udployactivityJson, buildNumber) {
        
        console.log("_____44________________" + udployactivityJson);
        //udployactivityJson = { "id": "08b5d13a-4cb2-4004-af78-fbcbd0726b15", "type": "graph", "name": "cf3c6063-2048-4161-b3c9-e6f9f5c222d8", "state": "EXECUTING", "result": "NONE", "startDate": 1416994259958, "duration": 1049, "paused": false, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "1ff725d8-21bf-4d12-a79d-919422d1e067", "type": "componentEnvironmentIterator", "displayName": "DeployAppNerdDinner_Process", "name": "a01f5cf8e95a874f5fbb19bb7012d0", "state": "EXECUTING", "result": "NONE", "startDate": 1416994259959, "duration": 1048, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "09da6222-b57f-46da-8e1a-677de00710b2", "type": "inventoryVersionDiff", "name": "424d267b-6af9-4d01-add1-77a2508bb301", "state": "EXECUTING", "result": "NONE", "startDate": 1416994260477, "duration": 530, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "e315f21c-4171-437e-bc5e-7cd864826926", "type": "componentProcess", "name": "DeployAppNerdDinner_Process", "state": "EXECUTING", "result": "NONE", "startDate": 1416994260484, "duration": 600, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "componentProcessRequestId": "79947c6d-eb2a-46c4-80cf-fc81be1b262b", "componentProcess": { "id": "09e5ae86-37d5-410d-9cab-b09cfaa241a1", "name": "Deployment To INTServer", "description": "", "defaultWorkingDir": "${p:resource\/work.dir}\/${p:component.name}", "takesVersion": true, "inventoryActionType": "ADD", "status": "Active", "configActionType": "ADD", "active": true, "versionCount": 28, "version": 28, "commit": 261, "path": "components\/b6ee934c-a195-489b-b383-717b77fe2622\/processes\/09e5ae86-37d5-410d-9cab-b09cfaa241a1" }, "specialNameType": "componentProcess", "version": { "id": "800d07d6-d3de-4c64-8139-881b5501f114", "name": "2.1.121.75", "description": "", "type": "FULL", "created": 1416994227827, "active": true, "archived": false }, "component": { "id": "b6ee934c-a195-489b-b383-717b77fe2622", "name": "ucdjenkins", "description": "", "created": 1389000113814, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" } }], "resource": { "id": "bdfba962-0bbb-44c7-98c2-8e0fa31c1107", "name": "ucdjenkins", "path": "\/ResourceQA\/DEV-VM.wipro.com\/ucdjenkins", "active": true, "description": "", "inheritTeam": true, "impersonationPassword": "****", "impersonationUseSudo": false, "impersonationForce": false, "type": "subresource", "status": "ONLINE", "hasAgent": true, "tags": [] }, "specialNameType": "resource" }], "component": { "id": "b6ee934c-a195-489b-b383-717b77fe2622", "name": "ucdjenkins", "description": "", "created": 1389000113814, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 2 },{ "id": "865f207f-6228-425f-8fef-04d2cecc3e53", "type": "componentEnvironmentIterator", "displayName": "RunQTPComponent", "name": "ad905d28f39e921bd254cb3eed5643", "state": "INITIALIZED", "result": "NONE", "duration": 1416994261552, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "component": { "id": "cdcf728a-5e54-46b3-b7e9-1b97a4dc71b0", "name": "RunQTP", "description": "", "created": 1389078938126, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 3 },{ "id": "f46bbba8-44c5-48eb-a7d3-a0d7cf576b8a", "type": "componentEnvironmentIterator", "displayName": "AutomatePromotionToQA", "name": "c91091520d10435aa0e2345f3e62c4", "state": "INITIALIZED", "result": "NONE", "duration": 1416994261553, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "component": { "id": "d2335235-3492-4eb7-8ac3-6e43a3827601", "name": "BuildPromotion", "description": "", "created": 1390890785277, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 1 },{ "id": "9473d808-aa0c-4442-aea6-181a41a028e6", "type": "componentEnvironmentIterator", "displayName": "AutomatePromotionToProd", "name": "0bc000278ddfd84f37f2652ccd34d0", "state": "INITIALIZED", "result": "NONE", "duration": 1416994261554, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "component": { "id": "d2335235-3492-4eb7-8ac3-6e43a3827601", "name": "BuildPromotion", "description": "", "created": 1390890785277, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 4 }], "applicationProcessRequest": { "id": "fe4782f7-902a-4ab3-8d06-a5aaa430a546", "submittedTime": 1416994239993, "traceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "userName": "aarthy (admin)", "onlyChanged": false }, "application": { "id": "6d00b3a3-ab05-499c-80ec-2f24dc80c98a", "name": "NerdDinner", "description": "", "created": 1389009976165, "enforceCompleteSnapshots": false, "active": true, "tags": [], "user": "aarthy (admin)" }, "applicationProcess": { "id": "0c5dfbf6-7db0-4fe1-be26-8b7cf9cf917e", "name": "DeployApplication_NerdDinner", "description": "", "active": true, "inventoryManagementType": "AUTOMATIC", "offlineAgentHandling": "PRE_EXECUTION_CHECK", "versionCount": 15, "version": 15, "commit": 1080, "path": "applications\/6d00b3a3-ab05-499c-80ec-2f24dc80c98a\/processes\/0c5dfbf6-7db0-4fe1-be26-8b7cf9cf917e" }, "environment": { "id": "25f41380-2080-4c8a-95c0-25fcf8e9780f", "name": "QASERVER-ENV", "description": "", "color": "#f4a460", "requireApprovals": false, "lockSnapshots": false, "calendarId": "435f3d81-f8ab-497e-8b5d-13ac6049cf37", "active": true, "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "conditions": [] } };
        if (udployactivityJson == "[]\n") {
            udployactivityJson = { "id": "08b5d13a-4cb2-4004-af78-fbcbd0726b15", "type": "graph", "name": "cf3c6063-2048-4161-b3c9-e6f9f5c222d8", "state": "EXECUTING", "result": "NONE", "startDate": 1416994259958, "duration": 91293, "paused": false, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "1ff725d8-21bf-4d12-a79d-919422d1e067", "type": "componentEnvironmentIterator", "displayName": "DeployAppNerdDinner_Process", "name": "a01f5cf8e95a874f5fbb19bb7012d0", "state": "CLOSED", "result": "SUCCEEDED", "startDate": 1416994259959, "endDate": 1416994347598, "duration": 87639, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "09da6222-b57f-46da-8e1a-677de00710b2", "type": "inventoryVersionDiff", "name": "424d267b-6af9-4d01-add1-77a2508bb301", "state": "CLOSED", "result": "SUCCEEDED", "startDate": 1416994260477, "endDate": 1416994347598, "duration": 87121, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "e315f21c-4171-437e-bc5e-7cd864826926", "type": "componentProcess", "name": "DeployAppNerdDinner_Process", "state": "CLOSED", "result": "SUCCEEDED", "startDate": 1416994260484, "endDate": 1416994347598, "duration": 87114, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "componentProcessRequestId": "79947c6d-eb2a-46c4-80cf-fc81be1b262b", "componentProcess": { "id": "09e5ae86-37d5-410d-9cab-b09cfaa241a1", "name": "Deployment To INTServer", "description": "", "defaultWorkingDir": "${p:resource\/work.dir}\/${p:component.name}", "takesVersion": true, "inventoryActionType": "ADD", "status": "Active", "configActionType": "ADD", "active": true, "versionCount": 28, "version": 28, "commit": 261, "path": "components\/b6ee934c-a195-489b-b383-717b77fe2622\/processes\/09e5ae86-37d5-410d-9cab-b09cfaa241a1" }, "specialNameType": "componentProcess", "version": { "id": "800d07d6-d3de-4c64-8139-881b5501f114", "name": "2.1.121.75", "description": "", "type": "FULL", "created": 1416994227827, "active": true, "archived": false }, "component": { "id": "b6ee934c-a195-489b-b383-717b77fe2622", "name": "ucdjenkins", "description": "", "created": 1389000113814, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" } }], "resource": { "id": "bdfba962-0bbb-44c7-98c2-8e0fa31c1107", "name": "ucdjenkins", "path": "\/ResourceQA\/DEV-VM.wipro.com\/ucdjenkins", "active": true, "description": "", "inheritTeam": true, "impersonationPassword": "****", "impersonationUseSudo": false, "impersonationForce": false, "type": "subresource", "status": "ONLINE", "hasAgent": true, "tags": [] }, "specialNameType": "resource" }], "component": { "id": "b6ee934c-a195-489b-b383-717b77fe2622", "name": "ucdjenkins", "description": "", "created": 1389000113814, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 2 }, { "id": "865f207f-6228-425f-8fef-04d2cecc3e53", "type": "componentEnvironmentIterator", "displayName": "RunQTPComponent", "name": "ad905d28f39e921bd254cb3eed5643", "state": "EXECUTING", "result": "NONE", "startDate": 1416994347598, "duration": 3679, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "0cbb25b8-05c8-405e-9657-a18b8fc045dd", "type": "inventoryVersionDiff", "name": "39964c4d-c5d3-4e7e-92ce-2421be04cc5f", "state": "EXECUTING", "result": "NONE", "startDate": 1416994348341, "duration": 2936, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "children": [{ "id": "e176b542-0edc-4a3f-9840-80d0e8da4f49", "type": "componentProcess", "name": "RunQTPComponent", "state": "EXECUTING", "result": "NONE", "startDate": 1416994348359, "duration": 2918, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "componentProcessRequestId": "bcdaaab1-74a5-4069-a5e4-460cd824d565", "componentProcess": { "id": "50cd2b41-cc79-4bb6-a9af-89bc69ffa2d1", "name": "Run QTP In INTServer", "description": "", "defaultWorkingDir": "${p:resource\/work.dir}\/${p:component.name}", "takesVersion": true, "inventoryActionType": "ADD", "status": "Active", "configActionType": "ADD", "active": true, "versionCount": 11, "version": 11, "commit": 239, "path": "components\/cdcf728a-5e54-46b3-b7e9-1b97a4dc71b0\/processes\/50cd2b41-cc79-4bb6-a9af-89bc69ffa2d1" }, "specialNameType": "componentProcess", "version": { "id": "ee7bab3c-fc52-473d-a34a-455d4267f7e6", "name": "1.0", "description": "", "type": "FULL", "created": 1389078958429, "active": true, "archived": false }, "component": { "id": "cdcf728a-5e54-46b3-b7e9-1b97a4dc71b0", "name": "RunQTP", "description": "", "created": 1389078938126, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" } }], "resource": { "id": "3b3e960f-7949-4b25-8300-138e0e56374d", "name": "RunQTP", "path": "\/ResourceQA\/DEV-VM.wipro.com\/RunQTP", "active": true, "description": "", "inheritTeam": true, "impersonationPassword": "****", "impersonationUseSudo": false, "impersonationForce": false, "type": "subresource", "status": "ONLINE", "hasAgent": true, "tags": [] }, "specialNameType": "resource" }], "component": { "id": "cdcf728a-5e54-46b3-b7e9-1b97a4dc71b0", "name": "RunQTP", "description": "", "created": 1389078938126, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 3 }, { "id": "f46bbba8-44c5-48eb-a7d3-a0d7cf576b8a", "type": "componentEnvironmentIterator", "displayName": "AutomatePromotionToQA", "name": "c91091520d10435aa0e2345f3e62c4", "state": "INITIALIZED", "result": "NONE", "duration": 1416994351280, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "component": { "id": "d2335235-3492-4eb7-8ac3-6e43a3827601", "name": "BuildPromotion", "description": "", "created": 1390890785277, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 1 }, { "id": "9473d808-aa0c-4442-aea6-181a41a028e6", "type": "componentEnvironmentIterator", "displayName": "AutomatePromotionToProd", "name": "0bc000278ddfd84f37f2652ccd34d0", "state": "INITIALIZED", "result": "NONE", "duration": 1416994351281, "workflowTraceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "component": { "id": "d2335235-3492-4eb7-8ac3-6e43a3827601", "name": "BuildPromotion", "description": "", "created": 1390890785277, "importAutomatically": false, "useVfs": true, "active": true, "deleted": false, "defaultVersionType": "FULL", "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "tags": [], "user": "aarthy (admin)" }, "graphPosition": 4 }], "applicationProcessRequest": { "id": "fe4782f7-902a-4ab3-8d06-a5aaa430a546", "submittedTime": 1416994239993, "traceId": "d41b854a-02f2-4ec8-8564-7db64432b6af", "userName": "aarthy (admin)", "onlyChanged": false }, "application": { "id": "6d00b3a3-ab05-499c-80ec-2f24dc80c98a", "name": "NerdDinner", "description": "", "created": 1389009976165, "enforceCompleteSnapshots": false, "active": true, "tags": [], "user": "aarthy (admin)" }, "applicationProcess": { "id": "0c5dfbf6-7db0-4fe1-be26-8b7cf9cf917e", "name": "DeployApplication_NerdDinner", "description": "", "active": true, "inventoryManagementType": "AUTOMATIC", "offlineAgentHandling": "PRE_EXECUTION_CHECK", "versionCount": 15, "version": 15, "commit": 1080, "path": "applications\/6d00b3a3-ab05-499c-80ec-2f24dc80c98a\/processes\/0c5dfbf6-7db0-4fe1-be26-8b7cf9cf917e" }, "environment": { "id": "25f41380-2080-4c8a-95c0-25fcf8e9780f", "name": "QASERVER-ENV", "description": "", "color": "#f4a460", "requireApprovals": false, "lockSnapshots": false, "calendarId": "435f3d81-f8ab-497e-8b5d-13ac6049cf37", "active": true, "cleanupDaysToKeep": 0, "cleanupCountToKeep": 0, "conditions": [] } };
            buildNumber = "2.1.121.75";
        }
        console.log("_____44________________" + buildNumber + "----" + udployactivityJson);
        
        var appid = "", appstatus = "", nerDinnerTraceID = "",
            xmlPathExpression = "", xmlString = "";
        var showGrid = false;
        
        outputDateFormat = "yyyy-MM-dd";
        outputTimeFormat = "hh:mm:ss TT";
        outputDuretionFormat = "hh:mm:ss";
        var lstDeploys = new Array();
        try {
            //##################    ###################
            var mainComponent = 'ucdjenkins', regressionComponent = 'RunSelenium';
            
            if (udployactivityJson != null) {
                
                
                var xmlString = js2xmlparser("root", udployactivityJson);
                deployDoc = dom.parseFromString(xmlString);
                
                showGrid = true;
                
                xmlPathExpression = "//children/component[name='" + mainComponent + "']/../version[name='" + buildNumber + "']/../workflowTraceId";
                var nerDinnerTraceIDNode = xpath.select(xmlPathExpression, deployDoc);
                
                if (nerDinnerTraceIDNode != "" && nerDinnerTraceIDNode != null) {
                    nerDinnerTraceID = nerDinnerTraceIDNode[0].textContent;
                }
                
                xmlPathExpression = "//applicationProcessRequest[traceId='" + nerDinnerTraceID + "']/id";
                var processIDNode = xpath.select(xmlPathExpression, deployDoc);
                if (processIDNode != "" && processIDNode != null) {
                    appid = processIDNode[0].textContent;
                }
            }
            
            var nerdDinnerUdeployVersion = "", startDateTimestamp = "", durationTimestamp = "";
            var startDateDouble = 0, durdouble = 0;
            var processResultNode = null, processStatusNode = null, processNameNode = null, componentNameNode = null, durationNode = null, 
                startDateNode = null, componentNode = null, nerdDinnerUdeployVersionNode = null;
            
            if (deployDoc != null && deployDoc != "") {
                
                if (nerDinnerTraceID != "" && nerDinnerTraceID != null) {
                    
                    xmlPathExpression = "//children[type='componentProcess' and workflowTraceId='" + nerDinnerTraceID + "']";
                    var requiredNodeList = xpath.select(xmlPathExpression, deployDoc);
                    
                    xmlPathExpression = "//children/component[name='" + mainComponent + "']/../version[name='" + buildNumber + "']/name";
                    nerdDinnerUdeployVersionNode = xpath.select(xmlPathExpression, deployDoc);
                    if (nerdDinnerUdeployVersionNode != null) {
                        nerdDinnerUdeployVersion = nerdDinnerUdeployVersionNode[0].textContent;
                    }
                    
                    if ((nerdDinnerUdeployVersionNode != "" && nerdDinnerUdeployVersionNode != null) && 
                        (nerdDinnerUdeployVersion != null) && (nerdDinnerUdeployVersion != "")) {
                        
                        var length = requiredNodeList.length;
                        //console.log("_____99________________" + length);
                        
                        for (var i = 0; i < length; i++) {
                            componentNode = requiredNodeList[i];
                            
                            deployinfo = new Udeploy();
                            
                            deployinfo.currentActivity = showGrid;
                            //to show the deploy grid in html.
                            //collection.Deploys[deployindx] = deployinfo;
                            
                            xmlPathExpression = "//root[workflowTraceId='" + nerDinnerTraceID + "']/startDate";
                            startDateNode = xpath.select(xmlPathExpression, deployDoc);
                            if (startDateNode != "" && startDateNode != null) {
                                startDateTimestamp = startDateNode[0].textContent;
                                startDateDouble = parseInt(startDateTimestamp);
                                
                                var inputDate = new Date(startDateDouble);
                                deployinfo.releaseDate = dateformat(inputDate, "yyyy-MM-dd");
                                deployinfo.releaseTime = dateformat(inputDate, "hh:mm:ss TT");
                            }
                            
                            xmlPathExpression = "//root[workflowTraceId='" + nerDinnerTraceID + "']/duration";
                            durationNode = xpath.select(xmlPathExpression, deployDoc);
                            if (durationNode != "" && durationNode != null) {
                                var duration = "";
                                durationTimestamp = durationNode[0].textContent;
                                durdouble = parseInt(durationTimestamp);
                                if (durdouble > 0) {
                                    var diffArray = new Array(3);
                                    diffArray[0] = (durdouble / (60 * 60 * 1000));	    //hrs
                                    diffArray[1] = durdouble / (60 * 1000) % 60;		//min
                                    diffArray[2] = durdouble / 1000 % 60;				//sec
                                    //diffArray[3] = durdouble / (24 * 60 * 60 * 1000);	//days
                                    
                                    for (var d = 0; d < 3; d++) {
                                        if (diffArray[d] == 0)
                                            duration += "00";
                                        else if (diffArray[d] > 0 && diffArray[d] < 10)
                                            duration += "0" + Math.floor(diffArray[d]);
                                        else
                                            duration += Math.floor(diffArray[d]);
                                        if (d != 2)
                                            duration += ":";
                                    }
                                }
                                deployinfo.durationTaken = duration;
                            }
                            
                            deployinfo.releaseVersion = nerdDinnerUdeployVersion;
                            
                            xmlPathExpression = "component/name";
                            componentNameNode = xpath.select(xmlPathExpression, componentNode);
                            
                            xmlPathExpression = "componentProcess/name";
                            processNameNode = xpath.select(xmlPathExpression, componentNode);
                            
                            if (processNameNode != "" && processNameNode != null) {
                                deployinfo.releaseProcess = processNameNode[0].textContent;
                            }
                            
                            xmlPathExpression = "state";
                            processStatusNode = xpath.select(xmlPathExpression, componentNode);
                            
                            if (componentNameNode != "" && processStatusNode != "" &&
                                  componentNameNode != null && processStatusNode != null && 
                                    (componentNameNode[0].textContent == regressionComponent)) {
                                // && 
                                //processStatusNode[0].textContent == "CLOSED") {
                                
                                deployinfo.regression = "True";
                                
                                // Get QTP Result function
                                deployinfo = deployinfo.getSeleniumResults(deployinfo);

                            }
                            
                            xmlPathExpression = "result";
                            processResultNode = xpath.select(xmlPathExpression, componentNode);
                            if (processStatusNode != null && processResultNode != null) {
                                if (processStatusNode[0].textContent == "CLOSED")
                                    deployinfo.status = processResultNode[0].textContent;
                                else
                                    deployinfo.status = processStatusNode[0].textContent;
                                
                                if (processStatusNode[0].textContent == "EXECUTING" && udployactivityJson == "[]\n") {
                                    deployinfo.status = appstatus;
                                }
                            }
                            
                            deployinfo.appId = appid;
                            //console.log("____________________");
                            //console.log("releaseVersion : " + deployinfo.releaseVersion);
                            //console.log("releaseDate : " + deployinfo.releaseDate);
                            //console.log("releaseTime : " + deployinfo.releaseTime);
                            //console.log("durationTaken : " + deployinfo.durationTaken);
                            //console.log("releaseProcess : " + deployinfo.releaseProcess);
                            //console.log("currentActivity : " + deployinfo.currentActivity);
                            //console.log("status : " + deployinfo.status);
                            //console.log("regression : " + deployinfo.regression);
                            //console.log("regressionTestsPassed : " + deployinfo.regressionTestsPassed);
                            //console.log("regressionTestsFailed : " + deployinfo.regressionTestsFailed);
                            //console.log("regressionTestsExecuted : " + deployinfo.regressionTestsExecuted);
                            //console.log("regressionNotExecuted : " + deployinfo.regressionNotExecuted);
                            //console.log("regressionReport : " + deployinfo.regressionReport);
                            //console.log("reports : " + deployinfo.reports);
                            //console.log("appId : " + deployinfo.appId);
                            //console.log("____________________");                        
                            
                            lstDeploys.push(deployinfo);
                        }
                    }
                }

            }



        }
        catch (ex) { }
        finally {
            
            if (lstDeploys == null || lstDeploys.length == 0) {
                deployinfo = new Udeploy();
                lstDeploys = new Array();
                deployinfo.status = "NoInfo";
                lstDeploys.push(deployinfo);
            }
        }
        return lstDeploys;
    },
    
    getSeleniumResults: function getSeleniumResults(deployinfo) {
        
        var remaining = '';
        var line = "", passed = "", failed = "", notRun = "";
        var passedCount = 0, failedcount = 0;
        
        var data = fs.readFileSync('./app/helper/QTPResultTFS.txt', 'utf8');
        remaining += data;
        var index = remaining.indexOf('\n');
        try {
            while (index > -1) {
                var line = remaining.substring(0, index);
                
                if (line.indexOf("Passed") > -1) {
                    var intinx = line.indexOf(':');
                    passed = line.substring(intinx + 1).trim();
                    if (!isNaN(passed)) {
                        passedCount = parseInt(passed);
                        deployinfo.regressionTestsPassed = passedCount;
                    }
                    
                }
				 
                else if (line.indexOf("Failed") > -1) {
                    var intinx = line.indexOf(':');
                    failed = line.substring(intinx + 1).trim();
                    if (!isNaN(failed)) {
                        failedcount = parseInt(failed);
                        deployinfo.regressionTestsFailed = failedcount;
                    }
                }
				 
                else if (line.indexOf("NR") > -1) {
                    var intinx = line.indexOf(':');
                    notRun = line.substring(intinx + 1).trim();
                    if (!isNaN(notRun)) {
                        deployinfo.regressionNotExecuted = notRun;
                    }
                }
                remaining = remaining.substring(index + 1);
                index = remaining.indexOf('\n');
            }
            deployinfo.regressionTestsExecuted = (passedCount + failedcount);
            deployinfo.regressionReport = "http://10.148.21.120/NerdDinnerReportsJenkins/BuildsQTPResults/QTPResults.html";
        }
    	catch (ex) {    		
        }
        
        return deployinfo;
    },
    
    IsComponentAvailable: function IsComponentAvailable(url, port, username, password, securityType, component, callback) {
        
        try {
            
            var udeployserver = url;
            var port = port;
            var username = username;
            var password = password;
            
            var secureSSL = "";
            if (securityType === "SSL") {
                secureSSL = "SSLv3_method"
            }
            else {
                secureSSL = "TLSv2_method"
            }
            
            //var udeployserver = "10.148.21.120";
            //var port = 8443;
            //var username = "admin";
            //var password = "admin";
            //var secureSSL = "SSLv3_method";
            
            var udeployObj = new Udeploy();
            
            //Get The Json form Udeploy API
            //url:'https://10.148.21.120:8443/rest/workflow/currentActivity',
            var options = {
                hostname: udeployserver,
                port: port,
                path: '/rest/deploy/component',
                method: 'GET',
                auth: username + ':' + password,
                secureProtocol: secureSSL,
                rejectUnauthorized: false,
            };
            
            var req = https.request(options, function (res) {
                console.log("statusCode: ", res.statusCode);
                
                res.on('data', function (componentJson) {
                    console.log("_____33________________" + componentJson);
                    
                    component = component.toUpperCase();
                    componentJson = JSON.parse(componentJson);
                    
                    var index;
                    var entry;
                    
                    component = component.toUpperCase();
                    for (index = 0; index < componentJson.length; ++index) {
                        entry = componentJson[index];
                        if (entry && entry.name && entry.name.toUpperCase() === component) {
                            callback(null, true);
                        }
                    }
                    
                    console.log("_____Returing the data https");
                    callback(null, false);
                });
            });
            req.end('end', function () {
                console.log("end here :\n");
            });
            
            req.on('error', function (e) {
                console.error("error :\n" + e);
            });
            console.log("_____End of dep method : 09");
        }
            catch (ex) {
            callback(null, false);
        }
    },    
};

module.exports = Udeploy;