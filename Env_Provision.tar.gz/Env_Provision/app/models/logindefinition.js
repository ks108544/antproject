﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Login schema
var loginSchema = new Schema({
    
    UserName: String,
    Password: String


}, { collection: 'Login' });

//Login model
var loginModel = mongoose.model('Login', loginSchema);
module.exports = loginModel;
