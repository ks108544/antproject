﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Deploy Server schema
var deployServerSchema = new Schema({
    // template name
    
 DeployServerConfigName: String,

 BuildServerPort: String,
 BuildServerName  : String,
 BuildServerUserID  : String,
 BuildServerPassword  : String,

 ConfigurationTool: String,
 ConfigurationPath  : String,
 ConfigurationUsername  : String,
 ConfigurationPassword  : String,

}, { collection: 'DeployServer' });

//Deploy Server model
var deployServerModel = mongoose.model('DeployServer', deployServerSchema);
module.exports = deployServerModel;
