﻿
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var containersInfo = new Schema({
    Type       : String,
    Name       : String,
    Version    : String,
    UserName   : String,
    Password   : String,
    PortNumber : String   
});

//Schema Setup
var envProvToolsDetailsSchema = new Schema( {
                     ContainerStackName :  String,
                     SourceControl   :  [containersInfo],
                     BuildServer     :  [containersInfo],
                     CompilerTool    :  [containersInfo],
                     CodeArtifactory :  [containersInfo],
                     QualityTool     :  [containersInfo],
                     CodeReviewTool  :  [containersInfo]
                                       
    }, { collection: 'EnvProvToolsDetails' });

//EnvProv Hosting Model
var envProvToolsModel = mongoose.model('EnvProvToolsDetails', envProvToolsDetailsSchema);
module.exports = envProvToolsModel;