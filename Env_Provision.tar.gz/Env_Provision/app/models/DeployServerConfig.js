﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var AppTable = new Schema({
   SeqNo: Number,
   AppDeployName: String,
   CookBookPath: String,
   AddlParameter: String,
   TargetInventory:String,
});
var PlatformTable = new Schema({
   SeqNo: Number,
   PlatformName: String,
   CookBookPath: String,
   AddlParameter: String,
   TargetInventory:String,
});

var ActivityTrackInfo = new Schema({
    JobName: String,
    DisplayText: String,
    JobType: String,
    StageType: String,
    PipelineType: String
});
//Deploy Server schema
var deployServerConfigSchema = new Schema( {
    // template name
    
    ServiceType: String,
    CDApplicationName  : String,
    
    DeployServerConfigname: String,
    //CDJobName  : String,
    ////Stage: [multikeySchema],
    
    //Stage: [{
    DeployStages: [{
            //CIApplicationNameDeploy: String,
            SelectCIApplication: String,
            //CIApplicationNew: String,
            
            CDPipelineTrigger: String,
            StageName: String,
            
            //enable
            EnablePlatformProvisioning: Boolean,
            PlatformProvisioning: {
                OperatingSystem  : String,
                Platform  : [PlatformTable],
            },
           // PlatformTargetInventory : String,

            //enable
            EnableApplicationDeployment: Boolean,
            AppDeployment: {
            AppRespositoryTool: String,
            TargetDeploymentPath  : String,
            Nexus: {
                CDPackageName: String,
                DeployServerUrl: String,
                DeployServerUserName  : String,
                DeployServerPassword  : String,
                Artifact  : String,
                FileFormat: String,
                Version: String,
                Group: String,
                AppTargetInventory : String,
                Noinstance: String,
                DockerportNumber: String,
                Kubernetes: String,
            },
           ApplicationDeploy :[AppTable],
           },     
        }],

    BuildPipeline: [{
            StageName: String,
            ActivityTrackings : [ActivityTrackInfo],
            Reports: [],
            Results: []
        }]
           

}, { collection: 'DeployServerConfig' });

//Deply Server model
var deployServerConfigModel = mongoose.model('DeployServerConfig', deployServerConfigSchema);
module.exports = deployServerConfigModel;

