﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var containersInfo = new Schema({
    Tag    : String,
    Name   : String,
    Type   : String,
    Status : String
 });
 
 
var containerHostingPlanSchema = new Schema({
    ContainerStackName: String,
    VMContainerMapping: [{
            VMName      : String,
            UserName    : String,
            Password    : String,
            Containers  : [containersInfo]
         }]
}, { collection: 'EnvProvVMDetails' });

//container Hosting Model
var envProvVMModel = mongoose.model('EnvProvVMDetails', containerHostingPlanSchema);
module.exports = envProvVMModel;

