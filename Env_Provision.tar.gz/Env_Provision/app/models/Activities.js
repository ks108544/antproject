﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Tools look up schema
var ActivitiesSchema = new Schema({
    Stage: String,
    DisplayText: String,
    JobType: String,
    StageType: String,
    PipelineType: String
}, { collection: 'Activities' });

//Tools look up model
var ActivitiesModel = mongoose.model('Activities', ActivitiesSchema);
module.exports = ActivitiesModel;

 