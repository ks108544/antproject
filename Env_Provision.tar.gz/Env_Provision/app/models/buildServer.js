﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Build definition schema
var buildServerSchema = new Schema({
    // template name
    BuildServerConfigName: String,

 BuildServerTool: String,
 SourceControlTool  : String,

 //both for jenkins and tfs
 BuildServerPort  : String,
 BuildServerName  : String,
 BuildServerUserID  : String,
 BuildServerPassword  : String,

 //GIT
 GitCredentials  : String,

 //tfs
BuildServerUrl  : String,
BuildServerDomain  : String, 
BuildController  : String,
BuildOutputFolder  : String,
BoxBuildAgent  : String, 
ProjectCollectionName: String,

    //jenkins

SourceControlUserID  : String,
SourceControlPassword  : String,
InstalledPath: String,
BuildOutputPath: String

}, { collection: 'BuildServer' });

//Build definition model
var buildServerModel = mongoose.model('BuildServer', buildServerSchema);
module.exports = buildServerModel;
