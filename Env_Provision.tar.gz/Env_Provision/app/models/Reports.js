﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Tools look up schema
var ReportsSchema = new Schema({
    Stage: String,
    Directory: String,
    Link: String,
    Port: String,
    JobType: String,
    DisplayText: String,
    ReportName: String,
    StageType: String,
    PipelineType: String
}, { collection: 'Reports' });

//Tools look up model
var ReportsModel = mongoose.model('Reports', ReportsSchema);
module.exports = ReportsModel;
 