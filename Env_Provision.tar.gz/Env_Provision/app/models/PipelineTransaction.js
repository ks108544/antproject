﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Pipeline transaction schema to store CI CD build transaction details along with approval details
var pipelineTrxnSchema = new Schema({
   
    BuildNumber: String,
    CIApplicationName: String,
    DeployApplicationName: String,
    JobType: String,
    BuildStatus: String,
    CDBuildno: String,
    Stage: String,
    ApprovalRequired: Boolean,
    Approver: String,
    ApprovalStatus: String,
    Comments: String,
    NextStage: String,
    UpdateDt: Date      
}, { collection: 'PipelineTransaction' });

//Pipeline transaction model
var pipelineTrxnModel = mongoose.model('PipelineTransaction', pipelineTrxnSchema);
module.exports = pipelineTrxnModel;
