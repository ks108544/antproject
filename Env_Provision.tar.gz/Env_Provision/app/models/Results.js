﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Tools look up schema
var ResultsSchema = new Schema({
    Stage: String,
    Type: String,
    DisplayText: String,
    StageType: String,
    PipelineType: String 
}, { collection: 'Results' });

//Tools look up model
var ResultsModel = mongoose.model('Results', ResultsSchema);
module.exports = ResultsModel;

 