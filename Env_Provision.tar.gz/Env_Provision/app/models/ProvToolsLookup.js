﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Tools look up schema
var provToolsLkupSchema = new Schema({
    ProvisioningType: String,
    ConfigMgmtTool: String,
    ContainerizationTool: String
}, { collection: 'ProvToolsLookup' });

//Tools look up model
var provToolsLkupModel = mongoose.model('ProvToolsLookup', provToolsLkupSchema);
module.exports = provToolsLkupModel;
