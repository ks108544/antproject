﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//App Look up schema
var appLkupSchema = new Schema({
    apptype: String,
    apptier: String
}, { collection: 'AppLookup' });

//App Look up model
var appLkupModel = mongoose.model('AppLookup', appLkupSchema);
module.exports = appLkupModel;
