﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Tools look up schema
var toolsLkupSchema = new Schema({
    toolname: String,
    toolgroup: String
}, { collection: 'ToolsLookup' });

//Tools look up model
var toolsLkupModel = mongoose.model('ToolsLookup', toolsLkupSchema);
module.exports = toolsLkupModel;
