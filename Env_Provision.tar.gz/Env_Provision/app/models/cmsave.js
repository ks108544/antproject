﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Mongo DB model for save data
var BuildsaveSchema = new Schema({
    CMDataModel : {
        Tool_NM: String,
        Tool_GRP: String,
        Build_url: String,
        Port: String,
        User_Name: String,
        Password: String,
        Domain: String,
        Build_Definition_JobName: String,
        BuildHistoryTimeLine: String,
        BuildService_Agent: String,
        Compilation_ACTVY: String,
        Code_Coverage_RPT: String,        
        Code_Analysis_RPT: String,        
        Code_Metrics_RPT: String,        
        UT_RPT: String,        
        Code_Security_RPT: String,        
        Risk_Analysis_RPT: String,        
        Sonar_RPT: String,
        Report_Path: String,
        Deploy_Tool_NM: String,             
        Deploy_Server_URL: String,    
        Deploy_Server_UName: String,    
        Deploy_Server_Pwd: String,    
        Deploy_Server_Port: String,    
        Deploy_Server_Sec_Typ: String,    
        Deploy_Server_Component: String,
        Created_At: String
    }
}, { collection: 'CM_Data' });

//Tool Model
var saveUserData = mongoose.model('UserSaveData', BuildsaveSchema);
module.exports = saveUserData;