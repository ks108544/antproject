﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//Build definition template schema
var buildDefnTemplateSchema = new Schema({
    TemplateName : String,
    BuildServerTool: String,  
    EnableAppTier  : Boolean,
    UITierAppType  : String,    
    EnableMiddleTier  : Boolean,
    BusinessTierAppType  : String,      
    
    EnableGatedBuildUI: Boolean,
    EnableGatedBuildMiddle: Boolean,

    EnableAssemblyVersion: Boolean,
    EnableAssemblyVersionUI  : Boolean, 
    EnableAssemblyVersionMiddle  : Boolean,    

    EnableUnitTestUI : Boolean,
    UnitTestToolUI: String,
    UnitTestThresholdValueUI : Number,
    EnableUnitTestMiddle : Boolean,
    UnitTestToolMiddle: String,
    UnitTestThresholdValueMiddle: String,

    EnableCodeCoverageUI : Boolean,
    CodeCoverageToolUI: String,
    CodeCoverageThresholdUI: Number,
    EnableCodeCoverageMiddle : Boolean,
    CodeCoverageToolMiddle : String,
    CodeCoverageThresholdMiddle: String,

    EnableCodeAnalysisUI : Boolean,
    CodeAnalysisToolUI: String,
    EnableCodeAnalysisMiddle : Boolean,
    CodeAnalysisToolMiddle : String,
        
    EnableSecAnalysisUI : Boolean,
    SecAnalysisToolUI: String,
    EnableSecAnalysisMiddle : Boolean,
    SecAnalysisToolMiddle : String,
    
    EnableCodeMetricsUI : Boolean,
    CodeMetricsToolUI : String,
    EnableCodeMetricsMiddle : Boolean,
    CodeMetricsToolMiddle : String,
    
    EnableRiskAnalysisUI : Boolean,
    EnableRiskAnalysisMiddle : Boolean,
    CoverageInputUI : String,
    MetricInputUI : String,
    CoverageInputMiddle : String,
    MetricInputMiddle : String,

    EnableSonarAnalysisUI  : Boolean,  
    EnableSonarAnalysisMiddle  : Boolean,   
    
    EnableBuildPackageUI : Boolean,
    EnableBuildPackageMiddle : Boolean,
    PackagingFormatUI : String,
    PackagingFormatMiddle : String,
    
    EnableDeployPackageUI: Boolean,
    EnableDeployPackageMT: Boolean, 
    
    EnableJenDeployPackageUI: Boolean,    
    EnableJenDeployPackageMiddle: Boolean

}, { collection: 'BuildDefinitionTemplate' });

//Build definition template model
var buildDefnTemplateModel = mongoose.model('BuildDefinitionTemplate', buildDefnTemplateSchema);
module.exports = buildDefnTemplateModel;
