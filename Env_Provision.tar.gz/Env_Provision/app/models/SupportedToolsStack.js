﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var SourceControls = new Schema({
    
    name: String,
    version: [{
            number: String
        }],

    inuse: String,

});
var Keyvalue = new Schema({
    
    name: String,
    version: [{
            number: String
        }],

    inuse: String,

});


//Supported Tool Stack schema
var supportedtoolsstackSchema = new Schema({
    SourceControl: [SourceControls],
    BuildServer: [Keyvalue],
    CodeArtifactory: [Keyvalue],
    QualityTool: [Keyvalue],
    CodeReviewtool: [Keyvalue],
    CompilerTool:[Keyvalue],


}, { collection: 'SupportedToolsStack' });

//Supported Tool Stack model
var supportedtoolsstackModel = mongoose.model('SupportedToolsStack', supportedtoolsstackSchema);
module.exports = supportedtoolsstackModel;


