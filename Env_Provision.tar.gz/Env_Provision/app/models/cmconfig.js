﻿var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//CM Configuration schema
var cmconfigSchema = new Schema({
    
    BuildActivityListUI : [{
            Name: String,
            DisplayText: String,
            Type: String
        }],
    BuildReportListUI : [{
            Link: String,
            Directory: String,
            Name: String,
            Text: String,
            DisplayText: String,
            Type: String
        }],
    BuildRiskListUI : [{
            Link: String,
            Directory: String,
            Name: String,
            Text: String,
            DisplayText: String,
            Type: String
        }],
    BuildItemListUI : [{
            Name: String,
            DisplayText: String,
            Value: String
        }],
    UnitTestActivityListUI : [{
            Name: String,
            DisplayText: String,
            Type: String
        }],
    UnitTestReportListUI : [{
            Link: String,
            Directory: String,
            Name: String,
            Text: String,
            DisplayText: String,
            Type: String
        }],
    UnitTestResultListUI : [{
            DisplayText: String,
            Text: String,
            Type: String,
            Application: String
        }],
    DeployInReleaseListUI: {
            ReleaseTemplate:String,
            Components: [{                    
                    Environment: String,
                    Name: String,
                    Tool: String
                }]
        },
    DeployUI : [{
            StgDisp: String,
            DeployActivityListUI : [{
                    Name: String,
                    DisplayText: String
                }],
            DeployPackageListUI : [{
                    Text: String,
                    Location: String
                }],
            DeployApprovalListUI : [{
                    Type: String,
                    Text: String
                }]

        }],
    DeployMid : [{}],
    DeployActivityListMiddle : [{
            Name: String,
            DisplayText: String
        }],
    DeployPackageListMiddle : [{
            Text: String,
            Location: String
        }],
    DeployApprovalListMiddle : [{
            Type: String,
            Text: String
        }],
    BuildActivityListMiddle : [{
            Name: String,
            DisplayText: String,
            Type: String
        }],
    BuildReportListMiddle : [{
            Link: String,
            Directory: String,
            Name: String,
            Text: String,
            DisplayText: String,
            Type: String
        }],
    BuildRiskListMiddle : [{
            Link: String,
            Directory: String,
            Name: String,
            Text: String,
            DisplayText: String,
            Type: String
        }],
    BuildItemListMiddle : [{
            DisplayText: String,
            Value: String
        }],
    UnitTestActivityListMiddle : [{
            Name: String,
            DisplayText: String,
            Type: String
        }],
    UnitTestReportListMiddle : [{
            Link: String,
            Directory: String,
            Name: String,
            Text: String,
            DisplayText: String,
            Type: String
        }],
    UnitTestResultListMiddle : [{
            DisplayText: String,
            Text: String,
            Type: String,
            Application: String
        }],   
    BuildServerUrl: String,
    ProjectCollectionUrl: String,
    DomainName: String,
    BuildReportPathUI : String, 
    BuildReportPathMiddle : String,
    TFSBuildDefinition: String,
    ProjectCollectionName: String,
    ProjectName: String,
    TFSUserID: String,
    TFSPassword: String,
    BuildServerTool: String,
    DeployServerTool: String,
    EnableRiskAnalysisUI: Boolean,
    EnableUnitTestUI: Boolean,
    EnableUnitTestMiddle: Boolean,
    ApplicationName: String,
    MonitorAppTier: Boolean,
    MonitorMiddleTier: Boolean,
    MonitorDataTier: Boolean,
    BuildServerName: String,
    BuildServerPort: String,
    BuildServerUserId: String,
    BuildServerPassword: String,
    DeployServerUrl: String,
    DeployServerPort: String,
    BuildServerDomain: String,
    DeployServerUserID: String,
    DeployServerPassword: String,
    DeploySecurityType: String,
    AllStagesList : [{
            id:Number,
            StgName: String,
            StageDetails: [{
                    id: Number,
                    StgName: String,
                    JobActivity: String,
                    StgDisplayText: String
                }],
            ReportDetails: [{
                    id: Number,
                    StgName: String,
                    CMReportType: String,
                    CMToolType: String,
                    CMReportLink: String,
                    CMReportDispText: String,
                    CMReportDirPath: String,
                    CMReportFileName: String,
                    CMReportCoverageInput: String,
                    CMReportCoverageTool: String,
                    CMReportMetricsInput: String,
                    CMReportMetricsTool: String
                }]
    }],
    DeployUdeployApplicationList: [{
        Application: [{
            Id: String,
            Name: String,
            Process: [{
                Id: String,
                Name: String
            }]
        }]
    }],
    DeployUdeployStageList: [{
        StgId: String,
        StgDisp: String,
        Activity: [{
            ResourceId: String,
            ResourceName: String,
            ComputerName: String,
            AgentId: String,
            AgentName: String,
            ComponentId: String,
            ComponentName: String,
            ComponentProcessId: String,
            ComponentProcessName: String,
            IsRegressionComponent: String,
            DisplayText: String
        }],
        Report: [{
            Link: String,
            Directory: String,
            Name: String,
            DisplayText: String
        }],
        Package: [{
            Text: String,
            Location: String
        }],
        Approval: [{
            Type: String,
            Text: String
        }]
    }]

}, { collection: 'cmconfig' });

//Build definition model
var cmconfigModel = mongoose.model('cmconfig', cmconfigSchema);
module.exports = cmconfigModel;
