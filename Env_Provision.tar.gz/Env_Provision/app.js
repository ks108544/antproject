﻿//file name : app.js
var express = require('express');
var app = express();                            //Create app with express
var path = require('path');
//var cors = require('cors');

process.env.NODE_ENV = 'development';                      //set node environment
var env = require('get-env')();
var loginfo = [];

//app.use(cors({ origin: 'http://localhost:1498' }));
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:1432');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});
if (env === 'dev' || env === 'development' || env === '') {
    var customlogger = require("./app/utils/logger.js");
    var constants = require('./config/serviceconstants.js');
} else if (env === 'prod' || env === 'production') {
    var customlogger = require("./dist/app/utils/logger.min.js");
    var constants = require('./config/serviceconstants.min.js');
}
if (constants.TRACE_ENABLED) {
loginfo = { message: "Setting the port", levelName: "trace" };
customlogger.trace({ loginfo: loginfo });
}
var port = process.env.PORT || 1337;                      // set the port
var port = 1337;
var favicon = require('serve-favicon');                   
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');                  //pull info from HTML Post

if (constants.TRACE_ENABLED) {
loginfo = { message: "Loading database config", levelName: "trace" };
customlogger.trace({ loginfo: loginfo });
}
var hostname = require('os').hostname().split('.').shift();  // get hostname
//var mongoose = require('mongoose');                         //refer mongoose for mongodb    

//logger.trace("Setting static files location");
//app.use(express.static(path.join(__dirname, 'client')));    //set the static files location /public/lib will be /lib for users

app.use(bodyParser.urlencoded({ extended: false }));        // parse application/x-www-form-urlencoded
app.use(bodyParser.json());                                 // parse application/json
app.use(cookieParser());
//app.use(require('stylus').middleware(path.join(__dirname, 'client')));
//app.use(require('morgan')({ "stream": logger.stream }));

// Configuring Passport
var passport = require('passport');
require('./config/passport')(passport);
var expressSession = require('express-session');
app.use(expressSession({
    secret: 'cookie_secret',
    cookie : {
        maxAge: 3600000
    },
    resave: true,
    saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());


module.exports = app;

if (env === 'dev' || env === 'development' || env === '') {
    app.use(express.static(path.join(__dirname, 'client')));    //set the static files location /public/lib will be /lib for users
    //app.use(require('stylus').middleware(path.join(__dirname, 'client')));
    var db = require('./config/database.js');                   //load the DB config
    require('./app/routes/route.js')(app, passport);


} else if (env === 'prod' || env === 'production') {
    app.use(express.static(path.join(__dirname, './dist/client'))); //set the static files location /public/lib will be /lib for users
    app.use(require('stylus').middleware(path.join(__dirname, './dist/client')));
    var db = require('./dist/config/database.min.js');              //load the DB config
    require('./dist/app/routes/route.min.js')(app, passport);
  
}

//logger.trace("Connecting database");
//mongoose.connect(db.url);
//DB Configuration
if (constants.TRACE_ENABLED) {
loginfo = { message: "database connection successful", levelName: "trace" };
customlogger.trace({ loginfo: loginfo });
}
// listen (start app with node app.js) 
app.listen(port);
if (constants.TRACE_ENABLED) {
loginfo = { message: "Listening on " + port, levelName: "trace" };
customlogger.trace({ loginfo: loginfo });
}
console.log("Listening on " + port);






