module.exports = function (grunt) {
    
   grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        
         jsvalidate: {
                options:{
                globals: {},
                esprimaOptions: {},
                verbose: false
                },
        app_target:{
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'app/',      // Src matches are relative to this path.
                        src: ['**/*.js'], // Actual pattern(s) to match.
                    },
                ],
        },
         client_target:{
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'client/',      // Src matches are relative to this path.
                        src: ['**/*.js','!libs/**'], // Actual pattern(s) to match.
                    },
                ],
        },

 config_target:{
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'config/',      // Src matches are relative to this path.
                        src: ['**/*.js'], // Actual pattern(s) to match.
                    },
                ],
        },
db_target:{
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'db/',      // Src matches are relative to this path.
                        src: ['**/*.js'], // Actual pattern(s) to match.
                    },
                ],
        }
},
        uglify: {
            first_target: {
                // Grunt will search for "**/*.js" under "app" when the "uglify" task
                // runs and build the appropriate src-dest file mappings then, so you
                // don't need to update the Gruntfile when files are added or removed.
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'app/',      // Src matches are relative to this path.
                        src: ['**/*.js'], // Actual pattern(s) to match.
                        dest: 'dist/app',   // Destination path prefix.
                        ext: '.min.js',   // Dest filepaths will have this extension.
                        extDot: 'first'   // Extensions in filenames begin after the first dot
                    },
                ],
            },

            second_target: {
                // Grunt will search for "**/*.js" under "client/" when the "uglify" task
                // runs and build the appropriate src-dest file mappings then, so you
                // don't need to update the Gruntfile when files are added or removed.
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'client/',      // Src matches are relative to this path.
                        src: ['**/*.js','!libs/**'], // Actual pattern(s) to match.
                        dest: 'dist/client',   // Destination path prefix.
                        ext: '.min.js',   // Dest filepaths will have this extension.
                        extDot: 'first'   // Extensions in filenames begin after the first dot
                    },
                ],
            },

            third_target: {
                // Grunt will search for "**/*.js" under "config/" when the "uglify" task
                // runs and build the appropriate src-dest file mappings then, so you
                // don't need to update the Gruntfile when files are added or removed.
                files: [
                    {
                        expand: true,     // Enable dynamic expansion.
                        cwd: 'config/',      // Src matches are relative to this path.
                        src: ['**/*.js'], // Actual pattern(s) to match.
                        dest: 'dist/config',   // Destination path prefix.
                        ext: '.min.js',   // Dest filepaths will have this extension.
                        extDot: 'first'   // Extensions in filenames begin after the first dot
                    },
                ],
            }
        },

        copy: {
            dist: {
                files: [
                    {
                        expand: true, 
                        src: ['client/Images/**'], 
                        dest: 'dist/'
                    },
                    {
                        expand: true, 
                        src: ['client/libs/**'], 
                        dest: 'dist/'
                    },
                    {
                        expand: true, 
                        src: ['db/*.js'], 
                        dest: 'dist/'
                    },
		    {
			expand: true,
			src: ['config/*.xml'],
			dest: 'dist/'
		     },	
                    {
                        expand: true, 
                        src: ['client/stylesheets/*.css'], 
                        dest: 'dist/'
                    },
                    {
                        expand: true, 
                        src: ['client/views/*.html'], 
                        dest: 'dist/'
                    },
                    {
                        expand: true, 
                        src: ['client/*.html'], 
                        dest: 'dist/'
                    },
                    {
                        expand: true,
                        src: ['app/utils/*.bat'],
                        dest: 'dist/'
                    },
                ],
            },

            prod: {
                files: [
                    {
                        expand: true, 
                        src: 'dist/**' ,
                        dest: 'prod/'
                    },
                    {
                        expand: true, 
                        src: ['*.js', '!Gruntfile.js'], 
                        dest: 'prod/'
                    },
                    {
                        expand: true, 
                        src: ['package.json'], 
                        dest: 'prod/'
                    }
                ],
            }
        },

        clean: {
            folder: ["prod/","dist/"] 
        },

        'string-replace': {
            inline: {
                files: {
                    'dist/client/index.html': 'client/index.html',
                    'dist/client/views/cmDashboard.html': 'client/views/cmDashboard.html',
                    'dist/client/views/Dashboard.html': 'client/views/Dashboard.html',
                    'dist/client/views/monitoringDashboard.html': 'client/views/monitoringDashboard.html'
                },
                options: {
                    replacements: [
                        {
                            pattern: '<!--start PROD imports',
                            replacement: '<!--start PROD imports-->'
                        },
                        {
                            pattern: 'end PROD imports-->',
                            replacement: '<!--end PROD imports-->'
                        },
                        {
                            pattern: '<!--start DEV imports-->',
                            replacement: '<!--start DEV imports'
                        },
                        {
                            pattern: '<!--end DEV imports-->',
                            replacement: 'end DEV imports-->'
                        }
                    ]
                }
            }
    	}    
   }); 
     //Load grunt tasks automatically    
    require('load-grunt-tasks')(grunt);
    
    grunt.registerTask('CIBuild', [
        'clean',
	'jsvalidate',
        'uglify',
        'copy:dist',
        'string-replace',
        'copy:prod'
    ]);
    
    grunt.registerTask('default', [
        'CIBuild'
    ]);

};
